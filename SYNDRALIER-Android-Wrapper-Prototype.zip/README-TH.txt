SYNDRALIER Android Wrapper — ต้นแบบสำหรับ Build/ทดสอบ

สถานะ: โปรเจกต์ต้นแบบ มีซอร์ส Android และไฟล์เกมครบแล้ว แต่ยังไม่ได้ Build APK หรือทดสอบกับ Vivo V15 Pro + เมาส์ Bluetooth จริง

สิ่งที่ต้นแบบพยายามทำ
- ใช้ Android Pointer Capture (API 26+) เพื่ออ่านการเคลื่อนที่เมาส์แบบ relative delta แทนตำแหน่งเคอร์เซอร์บนจอ
- ส่ง movement delta ให้ระบบกล้องของเกมเดิม
- ส่งสถานะปุ่มเมาส์จาก Android เข้า Input layer ของเกม
- ดักปุ่ม Back ของ Android แล้วส่ง Escape ให้เกม แทนการปิด Activity ทันที
- เก็บเกม HTML/CSS/JavaScript เดิมไว้ใน app/src/main/assets

ข้อจำกัดที่ต้องรู้
- ยังไม่รับประกันว่าเมาส์จะหมุน 360° ได้ทุกอุปกรณ์จนกว่าจะ Build และทดสอบจริง
- ต้องมีอินเทอร์เน็ตตอนเปิดเกม เพราะ Three.js โหลดจาก CDN
- หาก Build ไม่ผ่าน ต้องดู Log ของ GitHub Actions แล้วแก้ตาม error
- อย่าใช้ไฟล์นี้แทนไฟล์เกมหลัก หรือแจก APK ให้ผู้เล่นก่อนทดสอบ

Build ผ่าน GitHub Actions (ต้องอัปโหลดโปรเจกต์นี้เป็น repository)
1. แตก ZIP ให้เห็นไฟล์ settings.gradle, build.gradle, โฟลเดอร์ app และ .github อยู่ในระดับบนสุด
2. สร้าง repository ใหม่บน GitHub แล้วอัปโหลดไฟล์/โฟลเดอร์ทั้งหมดที่แตกออกมา (อย่าอัปโหลด ZIP นี้เป็นไฟล์เดียว)
3. เปิดแท็บ Actions ของ repository และอนุญาตให้รัน workflow หาก GitHub ขอให้เปิดใช้งาน Actions
4. เลือก “Build SYNDRALIER Android Wrapper APK” แล้วกด Run workflow
5. เมื่อสำเร็จ เปิด run ล่าสุด เลื่อนลงส่วน Artifacts แล้วดาวน์โหลด SYNDRALIER-Android-Wrapper-debug
6. แตก artifact แล้วติดตั้ง app-debug.apk บนมือถือ Android เพื่อทดสอบ

Package: com.syndralier.game.th
Version: 0.0.1-mouse-wrapper
