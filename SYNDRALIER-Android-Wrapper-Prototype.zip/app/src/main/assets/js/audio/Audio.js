// Audio : เสียงเอฟเฟกต์สังเคราะห์ด้วย WebAudio (ไม่ใช้ไฟล์เสียง) + เสียงลดตามระยะ
// เรียกผ่าน VX.sfx('ชื่อ', { pos, pitch }) — ถ้าเบราว์เซอร์ไม่รองรับ/ยังไม่ปลดล็อก จะเงียบไปเฉย ๆ
VX.Audio = (function () {
  let ctx = null, master = null, noiseBuf = null, vol = 0.6, listener = null;
  const last = {};

  function init() {
    if (ctx) return;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    try { ctx = new AC(); } catch (e) { ctx = null; return; }
    master = ctx.createGain(); master.gain.value = vol; master.connect(ctx.destination);
    noiseBuf = ctx.createBuffer(1, ctx.sampleRate, ctx.sampleRate);
    const d = noiseBuf.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
  }
  function resume() { init(); if (ctx && ctx.state === 'suspended') ctx.resume(); }

  function env(g, t0, dur, peak) {
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0002, peak), t0 + 0.008);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
  }
  function tone(f0, f1, dur, type, peak, delay) {
    const t0 = ctx.currentTime + (delay || 0), o = ctx.createOscillator(), g = ctx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(f0, t0);
    o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t0 + dur);
    env(g, t0, dur, peak);
    o.connect(g); g.connect(master);
    o.start(t0); o.stop(t0 + dur + 0.02);
  }
  function noise(dur, ftype, f0, f1, peak, delay) {
    const t0 = ctx.currentTime + (delay || 0), s = ctx.createBufferSource(), f = ctx.createBiquadFilter(), g = ctx.createGain();
    s.buffer = noiseBuf;
    f.type = ftype;
    f.frequency.setValueAtTime(f0, t0);
    f.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t0 + dur);
    env(g, t0, dur, peak);
    s.connect(f); f.connect(g); g.connect(master);
    s.start(t0, Math.random() * 0.5); s.stop(t0 + dur + 0.02);
  }

  // p = { g: ความดัง (ลดตามระยะแล้ว), pitch }
  const SFX = {
    swing:      (p) => noise(0.16, 'bandpass', 1000 * p.pitch, 300, 0.22 * p.g),
    hit:        (p) => { noise(0.1, 'lowpass', 900, 250, 0.35 * p.g); tone(160 * p.pitch, 60, 0.12, 'square', 0.18 * p.g); },
    crit:       (p) => { SFX.hit(p); tone(900, 1500, 0.16, 'triangle', 0.16 * p.g, 0.02); },
    mobHurt:    (p) => tone(340 * p.pitch, 150 * p.pitch, 0.16, 'sawtooth', 0.14 * p.g),
    mobDeath:   (p) => { tone(260 * p.pitch, 55, 0.45, 'sawtooth', 0.16 * p.g); noise(0.3, 'lowpass', 600, 120, 0.12 * p.g); },
    mobAttack:  (p) => { noise(0.12, 'lowpass', 700, 200, 0.3 * p.g); tone(120, 70, 0.1, 'square', 0.14 * p.g); },
    playerHurt: (p) => { tone(210, 85, 0.22, 'sawtooth', 0.2 * p.g); noise(0.14, 'lowpass', 500, 150, 0.18 * p.g); },
    shoot:      (p) => noise(0.14, 'highpass', 600, 2400, 0.15 * p.g),
    break:      (p) => noise(0.13, 'lowpass', 1100, 350, 0.3 * p.g),
    place:      (p) => { tone(220, 120, 0.07, 'triangle', 0.2 * p.g); noise(0.05, 'lowpass', 800, 300, 0.12 * p.g); },
    eat:        (p) => { noise(0.07, 'lowpass', 900, 500, 0.25 * p.g); noise(0.07, 'lowpass', 800, 450, 0.22 * p.g, 0.1); noise(0.07, 'lowpass', 850, 480, 0.2 * p.g, 0.2); },
    pickup:     (p) => tone(620, 960, 0.09, 'sine', 0.12 * p.g)
  };

  function play(name, o) {
    if (!ctx || ctx.state !== 'running') return;
    const fn = SFX[name];
    if (!fn) return;
    const now = ctx.currentTime;
    if (last[name] !== undefined && now - last[name] < 0.04) return;      // กันเสียงซ้อนถี่เกินไป
    o = o || {};
    let g = 1;
    if (o.pos && listener) {
      const l = listener(), d = Math.hypot(o.pos.x - l.x, o.pos.y - l.y, o.pos.z - l.z);
      if (d > 40) return;
      g = 1 / (1 + d * 0.12);
    }
    last[name] = now;
    fn({ g, pitch: o.pitch || 1 });
  }

  const api = {
    resume, play,
    setVolume(v) { vol = v; if (master) master.gain.value = v; },
    setListener(fn) { listener = fn; },
    register(name, fn) { SFX[name] = fn; }
  };
  VX.sfx = play;
  return api;
})();
