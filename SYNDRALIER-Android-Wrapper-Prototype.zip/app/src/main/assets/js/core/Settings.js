// Settings : การตั้งค่าทั้งหมดอยู่ในตารางเดียว (schema) — UI สร้างจากตารางนี้ เพิ่มตัวเลือกใหม่ = เพิ่มหนึ่งแถว + หนึ่ง handler
// เก็บลง localStorage (ใช้ร่วมทุกโลก) และนำไปใช้กับเกมทันทีที่เปลี่ยน
VX.Settings = (function () {
  const KEY = 'vx:settings';
  const GRAPHICS = ['renderDistance', 'loadExtra', 'fpsLimit', 'renderScale', 'shadows', 'particles', 'entityDistance', 'mobDensity'];
  const PRESETS = {
    low:     { renderDistance: 3, loadExtra: 1, fpsLimit: 30, renderScale: 0.6, shadows: 'off',  particles: 0.5, entityDistance: 24, mobDensity: 0.5 },
    medium:  { renderDistance: 4, loadExtra: 1, fpsLimit: 60, renderScale: 0.8, shadows: 'blob', particles: 0.5, entityDistance: 32, mobDensity: 1 },
    high:    { renderDistance: 6, loadExtra: 2, fpsLimit: 60, renderScale: 1,   shadows: 'blob', particles: 1,   entityDistance: 48, mobDensity: 1.5 },
    battery: { renderDistance: 3, loadExtra: 1, fpsLimit: 30, renderScale: 0.6, shadows: 'off',  particles: 0,   entityDistance: 20, mobDensity: 0.5 }
  };
  const schema = [
    { key: 'preset', label: 'พรีเซ็ตกราฟิก', type: 'select', options: [['low', 'ประหยัด'], ['medium', 'กลาง'], ['high', 'สูง'], ['battery', 'ประหยัดแบตฯ'], ['custom', 'กำหนดเอง']] },
    { key: 'renderDistance', label: 'ระยะมอง', type: 'range', min: 2, max: 10, step: 1, fmt: (v) => v + ' chunk' },
    { key: 'loadExtra', label: 'ระยะโหลดล่วงหน้า', type: 'range', min: 1, max: 3, step: 1, fmt: (v) => '+' + v },
    { key: 'fpsLimit', label: 'จำกัด FPS', type: 'select', options: [[30, '30'], [45, '45'], [60, '60'], [0, 'ไม่จำกัด']] },
    { key: 'renderScale', label: 'ความละเอียดภาพ', type: 'select', options: [[0.6, '60%'], [0.8, '80%'], [1, '100%']] },
    { key: 'shadows', label: 'เงา', type: 'select', options: [['off', 'ปิด'], ['blob', 'เงาใต้ตัว']] },
    { key: 'particles', label: 'อนุภาค', type: 'select', options: [[0, 'ปิด'], [0.5, 'น้อย'], [1, 'เต็ม']] },
    { key: 'entityDistance', label: 'ระยะแสดงมอน/ไอเทม', type: 'range', min: 16, max: 64, step: 8, fmt: (v) => v + ' บล็อก' },
    { key: 'mobDensity', label: 'จำนวนมอน', type: 'select', options: [[0.5, 'น้อย'], [1, 'ปกติ'], [1.5, 'มาก']] },
    { key: 'fov', label: 'FOV', type: 'range', min: 60, max: 100, step: 5, fmt: (v) => v + '°' },
    { key: 'lookSens', label: 'ความไวกล้อง', type: 'range', min: 0.5, max: 2, step: 0.1, fmt: (v) => v.toFixed(1) + '×' },
    { key: 'controls', label: 'ปุ่มควบคุม (คีย์บอร์ด / เมาส์)', type: 'button', action: 'controls' },
    { key: 'backGuard', label: 'กันปุ่ม Back ของ Android (คลิกขวาแล้วเด้งออก)', type: 'toggle' },
    { key: 'inlog', label: 'บันทึกเหตุการณ์ Input (ไว้ไล่บั๊ก)', type: 'button', action: 'inlog' },
    { key: 'volume', label: 'เสียง', type: 'range', min: 0, max: 100, step: 5, fmt: (v) => v + '%' },
    { key: 'uiScale', label: 'ขนาดปุ่มบนจอ', type: 'select', options: [[0.85, 'เล็ก'], [1, 'ปกติ'], [1.2, 'ใหญ่']] },
    { key: 'autoQuality', label: 'ลดคุณภาพอัตโนมัติเมื่อ FPS ตก', type: 'toggle' },
    { key: 'debugInfo', label: 'แสดงข้อมูล debug', type: 'toggle' }
  ];

  let values = {}, ctx = {}, base = { mouse: 0.0022, touch: 0.005 };
  const listeners = [];

  const handlers = {
    renderDistance() { if (ctx.onView) ctx.onView(); },
    loadExtra(v) { const g = ctx.getGame && ctx.getGame(); if (g) { g.world.loadExtra = v; g.world.lastCX = null; } },
    renderScale(v) { if (ctx.renderer) { ctx.renderer.setPixelRatio(ctx.basePR * v); if (ctx.resize) ctx.resize(); } },
    shadows(v) { VX.Config.SHADOWS = v === 'blob'; },
    particles(v) { VX.Config.PARTICLE_SCALE = v; },
    entityDistance(v) { VX.Config.ENTITY_DISTANCE = v; },
    mobDensity(v) { VX.Config.MOB_DENSITY = v; },
    fov(v) { if (ctx.camera) { ctx.camera.fov = v; ctx.camera.updateProjectionMatrix(); } },
    lookSens(v) { VX.Config.LOOK_SENS_MOUSE = base.mouse * v; VX.Config.LOOK_SENS_TOUCH = base.touch * v; },
    volume(v) { if (VX.Audio) VX.Audio.setVolume(v / 100); },
    uiScale(v) { if (typeof document !== 'undefined') document.documentElement.style.setProperty('--bs', v); },
    debugInfo(v) { const d = typeof document !== 'undefined' && document.getElementById('debug'); if (d) d.style.display = v ? 'block' : 'none'; }
  };
  const apply = (k) => { if (handlers[k]) { try { handlers[k](values[k]); } catch (e) { console.warn('setting', k, e); } } };

  function valid(def, v) {
    if (def.type === 'select') return def.options.some((o) => o[0] === v);
    if (def.type === 'range') return typeof v === 'number' && v >= def.min && v <= def.max;
    return typeof v === 'boolean';
  }
  function persist() { try { localStorage.setItem(KEY, JSON.stringify(values)); } catch (e) { /* ไม่มี localStorage ก็ไม่เป็นไร */ } }

  return {
    schema, PRESETS, GRAPHICS, actions: {},
    init(isTouch) {
      base = { mouse: VX.Config.LOOK_SENS_MOUSE, touch: VX.Config.LOOK_SENS_TOUCH };
      const preset = isTouch ? 'medium' : 'high';
      values = Object.assign({ preset, fov: 75, lookSens: 1, volume: 60, uiScale: 1, autoQuality: !!isTouch, debugInfo: true, backGuard: !!isTouch }, PRESETS[preset]);
      try {
        const s = JSON.parse(localStorage.getItem(KEY) || 'null');
        if (s) for (const d of schema) if (d.key in s && valid(d, s[d.key])) values[d.key] = s[d.key];
      } catch (e) { /* ใช้ค่าเริ่มต้น */ }
      this.applyAll();
    },
    bind(c) { ctx = c; this.applyAll(); },
    applyAll() { for (const d of schema) apply(d.key); },
    get(k) { return values[k]; },
    all() { return Object.assign({}, values); },
    onChange(fn) { listeners.push(fn); },
    set(key, v) {
      const def = schema.find((d) => d.key === key);
      if (!def || !valid(def, v)) return false;
      if (key === 'preset' && v !== 'custom') {
        values.preset = v; Object.assign(values, PRESETS[v]);
        GRAPHICS.forEach(apply);
      } else {
        values[key] = v;
        if (GRAPHICS.includes(key)) values.preset = 'custom';       // ปรับเองแล้ว = กำหนดเอง
        apply(key);
      }
      persist();
      listeners.forEach((fn) => fn(key, v));
      return true;
    },
    _setCtx(c) { ctx = c; }
  };
})();

// Perf : ตัวจำกัด FPS + ตัวลดคุณภาพอัตโนมัติ
VX.Perf = {
  shouldRender(now, last, limit) { return !limit || now - last >= 1000 / limit - 1.5; },
  Adaptive: class {
    constructor() { this.t = 0; this.f = 0; this.warm = 6; this.cool = 0; }
    reset() { this.t = 0; this.f = 0; this.warm = 6; }
    // เฉลี่ย FPS ทุก 3 วินาที (รอ 6 วินาทีแรกให้โลกโหลดก่อน) ถ้าต่ำกว่า 70% ของเป้า -> เรียก onLow (ห่างกันอย่างน้อย 10 วิ)
    update(dt, enabled, limit, onLow) {
      if (this.warm > 0) { this.warm -= dt; return; }
      this.cool = Math.max(0, this.cool - dt);
      this.t += dt; this.f++;
      if (this.t >= 3) {
        const fps = this.f / this.t, target = Math.min(limit || 60, 60);
        this.t = 0; this.f = 0;
        if (enabled && this.cool <= 0 && fps < target * 0.7) { this.cool = 10; onLow(fps); }
      }
    }
  }
};
