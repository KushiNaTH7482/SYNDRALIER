// Namespace กลาง ทุกโมดูลผูกอยู่ใต้ window.VX (เปิด index.html ตรง ๆ ได้ ไม่ต้องมีเซิร์ฟเวอร์)
window.VX = window.VX || {};
VX.sfx = function () {};        // ถูกแทนที่โดย Audio.js เมื่อโหลดเสร็จ (ไม่มีเสียง = ไม่ error)

VX.Config = {
  CHUNK_SIZE: 16,
  CHUNK_HEIGHT: 64,
  SEA_LEVEL: 22,
  RENDER_DISTANCE_DESKTOP: 6,   // หน่วยเป็น chunk (Phase 10 จะทำให้ปรับใน Settings)
  RENDER_DISTANCE_MOBILE: 4,
  GEN_BUDGET_MS: 5,             // เวลาสร้าง chunk สูงสุดต่อเฟรม
  MESH_PER_FRAME: 2,            // จำนวน mesh ที่สร้างต่อเฟรม
  PICKUP_RADIUS: 1.5,
  DROP_LIFETIME: 300,           // วินาทีก่อนไอเทมที่ตกพื้นหาย
  MAX_DROPS: 128,
  DAY_LENGTH: 600,              // 1 วันในเกม = 600 วินาที (10 นาที) กลางคืนครึ่งหนึ่ง
  START_TIME: 0.3,              // เริ่มเกมตอนเช้า
  MOB_CAP_DESKTOP: 28,          // จำนวนมอนสูงสุดในโลกพร้อมกัน
  MOB_CAP_MOBILE: 16,
  MOB_SPAWN_MIN: 20, MOB_SPAWN_MAX: 38, MOB_DESPAWN: 64,
  PARTICLE_SCALE: 1,            // 0 = ปิดอนุภาค (ตัวเลือก Graphics ใน Phase 10)
  ENTITY_DISTANCE: 48,          // ปรับได้ที่ Settings
  MOB_DENSITY: 1,
  SHADOWS: true,
  CRAFT_RADIUS: 5,              // ระยะที่นับว่า "อยู่ใกล้" Work Bench
  FOV: 75,
  PIXEL_RATIO_MAX: 1.5,
  LOOK_SENS_MOUSE: 0.0022,
  LOOK_SENS_TOUCH: 0.0050,
  PLAYER: {
    WIDTH: 0.6, HEIGHT: 1.8, CROUCH_HEIGHT: 1.5,
    EYE: 1.62, CROUCH_EYE: 1.32,
    WALK: 4.3, SPRINT: 5.8, CROUCH: 1.6,
    JUMP: 9.0, GRAVITY: 28.0, MAX_FALL: 50.0
  }
};
