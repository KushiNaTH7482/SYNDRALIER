// ChunkWorker : สร้าง chunk ใน Web Worker (ไม่บล็อกเธรดหลัก ลดอาการกระตุกตอนเดินสำรวจ)
// ใช้โค้ด Config/Noise/WorldGen ชุดเดียวกับเธรดหลัก จึงได้ chunk เหมือนกันทุกบิต ถ้า Worker ใช้ไม่ได้ จะ fallback เป็นสร้างบนเธรดหลักอัตโนมัติ
VX.ChunkWorker = class {
  constructor(worker) {
    this.w = worker; this.ok = false; this.failed = false;
    this.onChunk = null; this.onFail = null;
    worker.onmessage = (e) => {
      const m = e.data;
      if (m.ready) { this.ok = true; return; }
      if (this.onChunk) this.onChunk(m.cx, m.cz, new Uint8Array(m.buf));
    };
    worker.onerror = () => this.fail();
  }
  request(cx, cz) { this.w.postMessage({ cx, cz }); }
  fail() {
    if (this.failed) return;
    this.failed = true; this.ok = false;
    try { this.w.terminate(); } catch (e) { /* ignore */ }
    if (this.onFail) this.onFail();
  }
  dispose() { try { this.w.terminate(); } catch (e) { /* ignore */ } }

  static buildSource(parts, ids, seed) {
    return 'var window=self;self.VX=self.VX||{};\n' + parts.config + '\n' + parts.noise + '\n' +
      'var __IDS=' + JSON.stringify(ids) + ';VX.Blocks={byName:function(n){return{id:__IDS[n]};}};\n' + parts.worldgen + '\n' +
      'var __gen=VX.WorldGen.create(' + JSON.stringify(seed) + ');var __S=VX.Config.CHUNK_SIZE,__H=VX.Config.CHUNK_HEIGHT;\n' +
      'self.onmessage=function(e){var m=e.data;var c={cx:m.cx,cz:m.cz,data:new Uint8Array(__S*__H*__S),dirty:true};' +
      '__gen.generateChunk(c);self.postMessage({cx:m.cx,cz:m.cz,buf:c.data.buffer},[c.data.buffer]);};\n' +
      'self.postMessage({ready:true});';
  }

  static async fetchSources() {
    const get = async (name) => {
      const s = document.querySelector('script[src$="' + name + '"]');
      if (!s) throw new Error('script not found: ' + name);
      const r = await fetch(s.src);
      if (!r.ok) throw new Error('fetch failed: ' + name);
      return r.text();
    };
    return { config: await get('core/Config.js'), noise: await get('world/Noise.js'), worldgen: await get('world/WorldGen.js') };
  }

  // คืน instance หรือ null ถ้าสภาพแวดล้อมไม่รองรับ (file://, CSP, ไม่มี Worker ฯลฯ)
  static async create(seed) {
    try {
      if (typeof Worker === 'undefined' || typeof Blob === 'undefined' || typeof URL === 'undefined' || typeof fetch === 'undefined') return null;
      const ids = {};
      for (const b of VX.Blocks.all()) ids[b.name] = b.id;
      const code = VX.ChunkWorker.buildSource(await VX.ChunkWorker.fetchSources(), ids, seed);
      return new VX.ChunkWorker(new Worker(URL.createObjectURL(new Blob([code], { type: 'application/javascript' }))));
    } catch (e) { console.warn('ChunkWorker unavailable, generating on main thread:', e && e.message); return null; }
  }
};
