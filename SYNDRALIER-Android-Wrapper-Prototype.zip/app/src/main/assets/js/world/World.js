// World : streaming chunk รอบผู้เล่น (โหลด/ปลดโหลด), สร้าง mesh แบบจำกัดเวลาต่อเฟรม
// หมายเหตุ: การสร้าง chunk ทำแบบ time-sliced บน main thread (Web Worker ไว้ทำใน Phase 10)
VX.World = class {
  constructor(scene, seed) {
    this.scene = scene;
    this.seed = seed;
    this.gen = VX.WorldGen.create(seed);
    this.chunks = new Map();
    this.modified = new Map();       // chunk ที่ผู้เล่นแก้ไขแล้วถูก unload: key -> data (Phase 9 จะบันทึกลงเครื่อง)
    this.queue = [];
    this.loadExtra = 1;               // ระยะโหลด chunk ล่วงหน้านอกระยะมอง (ปรับได้ที่ Settings)
    this.worker = null; this.pending = new Set(); this.ready = [];
    this.saveDirty = new Set();       // chunk ที่ถูกแก้ไขตั้งแต่เซฟครั้งล่าสุด
    this.renderDistance = 4;
    this.lastCX = null; this.lastCZ = null;
    this.mats = {
      opaque: new THREE.MeshBasicMaterial({ map: VX.TextureAtlas.texture, vertexColors: true, alphaTest: 0.5 }),   // alphaTest = พืชตัดขอบ
      water: new THREE.MeshBasicMaterial({ map: VX.TextureAtlas.texture, vertexColors: true, transparent: true, opacity: 0.7, depthWrite: false })
    };
    VX.Lighting.patch(this.mats.opaque);
    VX.Lighting.patch(this.mats.water);
  }
  // ความสูงของแสงท้องฟ้าที่คอลัมน์ (x,z) : เซลล์ที่ y >= ค่านี้ได้รับแสงท้องฟ้าเต็ม
  skyHeight(x, z) {
    const S = VX.Config.CHUNK_SIZE;
    x = Math.floor(x); z = Math.floor(z);
    const c = this.getChunk(Math.floor(x / S), Math.floor(z / S));
    return c ? c.heightAt(x - c.cx * S, z - c.cz * S) : 0;
  }
  skyExposed(x, y, z) { return y >= this.skyHeight(x, z); }

  key(cx, cz) { return cx + ',' + cz; }
  getChunk(cx, cz) { return this.chunks.get(this.key(cx, cz)); }

  getBlock(x, y, z) {
    const S = VX.Config.CHUNK_SIZE;
    if (y < 0) return 3;
    if (y >= VX.Config.CHUNK_HEIGHT) return 0;
    x = Math.floor(x); y = Math.floor(y); z = Math.floor(z);
    const c = this.getChunk(Math.floor(x / S), Math.floor(z / S));
    return c ? c.get(x - c.cx * S, y, z - c.cz * S) : 0;
  }
  isSolid(x, y, z) { return VX.Blocks.isSolid(this.getBlock(x, y, z)); }
  isLoadedAt(x, z) {
    const S = VX.Config.CHUNK_SIZE;
    return !!this.getChunk(Math.floor(x / S), Math.floor(z / S));
  }

  setBlock(x, y, z, id) {
    const S = VX.Config.CHUNK_SIZE;
    if (y < 0 || y >= VX.Config.CHUNK_HEIGHT) return;
    const c = this.getChunk(Math.floor(x / S), Math.floor(z / S));
    if (!c) return;
    const lx = x - c.cx * S, lz = z - c.cz * S;
    c.set(lx, y, lz, id);
    c.modified = true; c.urgent = true; this.saveDirty.add(this.key(c.cx, c.cz));
    if (lx === 0) this.markUrgent(c.cx - 1, c.cz);
    if (lx === S - 1) this.markUrgent(c.cx + 1, c.cz);
    if (lz === 0) this.markUrgent(c.cx, c.cz - 1);
    if (lz === S - 1) this.markUrgent(c.cx, c.cz + 1);
  }
  markUrgent(cx, cz) { const c = this.getChunk(cx, cz); if (c) { c.dirty = true; c.urgent = true; } }

  // ---- Save/Load ----
  restoreModified(map) { for (const [k, data] of map) this.modified.set(k, data); }     // chunk ที่เคยแก้ไข จะถูกใช้แทนการสร้างใหม่ตอนโหลด
  takeSaveChunks() {
    const entries = [], keys = Array.from(this.saveDirty);
    for (const k of keys) {
      const c = this.chunks.get(k), data = c ? c.data : this.modified.get(k);
      if (data) entries.push({ k, data });
    }
    this.saveDirty.clear();
    return { entries, keys };
  }
  restoreSaveDirty(keys) { for (const k of keys) this.saveDirty.add(k); }

  setRenderDistance(r) { this.renderDistance = r; this.lastCX = null; }

  // ---- สร้าง chunk ใน Web Worker (ถ้ามี) ----
  attachWorker(w) {
    this.worker = w;
    w.onChunk = (cx, cz, data) => this.ready.push([cx, cz, data]);
    w.onFail = () => { this.pending.clear(); this.lastCX = null; };    // Worker พัง : กลับไปสร้างบนเธรดหลัก
  }

  loadChunk(cx, cz) {
    const c = new VX.Chunk(cx, cz), k = this.key(cx, cz), saved = this.modified.get(k);
    if (saved) { c.data = saved; c.modified = true; this.modified.delete(k); }
    else this.gen.generateChunk(c);
    this.chunks.set(k, c);
    return c;
  }
  unload(c) {
    const k = this.key(c.cx, c.cz);
    if (c.modified) this.modified.set(k, c.data);
    c.disposeMesh();
    this.chunks.delete(k);
  }

  rescan(cx, cz) {
    const R = this.renderDistance, G = R + this.loadExtra, U = (G + 1) * (G + 1);
    for (const c of Array.from(this.chunks.values())) {
      const dx = c.cx - cx, dz = c.cz - cz;
      if (dx * dx + dz * dz > U) this.unload(c);
    }
    const q = [];
    for (let dz = -G; dz <= G; dz++) for (let dx = -G; dx <= G; dx++) {
      const d2 = dx * dx + dz * dz;
      if (d2 <= G * G && !this.getChunk(cx + dx, cz + dz) && !this.pending.has(this.key(cx + dx, cz + dz))) q.push([cx + dx, cz + dz, d2]);
    }
    q.sort((a, b) => a[2] - b[2]);
    this.queue = q;
  }

  // build mesh เฉพาะ chunk ที่ข้างเคียง 4 ด้านถูกสร้างแล้ว (กันหน้าบล็อกที่ไม่จำเป็นตามขอบ)
  meshPass(cx, cz, max, R) {
    const R2 = R * R, cand = [];
    for (const c of this.chunks.values()) {
      if (!c.dirty) continue;
      const dx = c.cx - cx, dz = c.cz - cz, d2 = dx * dx + dz * dz;
      if (d2 > R2 && !c.urgent) continue;
      if (!(this.getChunk(c.cx + 1, c.cz) && this.getChunk(c.cx - 1, c.cz) &&
            this.getChunk(c.cx, c.cz + 1) && this.getChunk(c.cx, c.cz - 1))) continue;
      cand.push([c, d2 - (c.urgent ? 1e6 : 0)]);
    }
    cand.sort((a, b) => a[1] - b[1]);
    let n = 0;
    for (const [c] of cand) {
      if (!c.urgent && n >= max) break;
      if (!c.urgent) n++;
      c.urgent = false;
      for (const m of c.buildMesh(this, this.mats)) this.scene.add(m);
    }
  }

  // โหลดแบบ synchronous ตอนเริ่มเกม เพื่อให้ผู้เล่นไม่ตกก่อน chunk พร้อม
  preload(x, z, r) {
    const S = VX.Config.CHUNK_SIZE, cx = Math.floor(x / S), cz = Math.floor(z / S), G = r + 1;
    for (let dz = -G; dz <= G; dz++) for (let dx = -G; dx <= G; dx++)
      if (dx * dx + dz * dz <= G * G && !this.getChunk(cx + dx, cz + dz)) this.loadChunk(cx + dx, cz + dz);
    this.meshPass(cx, cz, Infinity, r);
    this.lastCX = null;
  }

  update(px, pz) {
    const C = VX.Config, S = C.CHUNK_SIZE;
    const cx = Math.floor(px / S), cz = Math.floor(pz / S);
    if (cx !== this.lastCX || cz !== this.lastCZ) { this.lastCX = cx; this.lastCZ = cz; this.rescan(cx, cz); }
    // รับ chunk ที่ Worker สร้างเสร็จ (ทิ้งอันที่ผู้เล่นเดินห่างไปแล้ว)
    const G = this.renderDistance + this.loadExtra;
    while (this.ready.length) {
      const r = this.ready.shift(), k = this.key(r[0], r[1]);
      this.pending.delete(k);
      const dx = r[0] - cx, dz = r[1] - cz;
      if (this.chunks.has(k) || dx * dx + dz * dz > (G + 1) * (G + 1)) continue;
      const c = new VX.Chunk(r[0], r[1]); c.data = r[2];
      this.chunks.set(k, c);
    }
    if (this.modified.size) {                                    // chunk ที่เคยแก้ไข : โหลดจากเซฟทันที ไม่เข้าคิว Worker
      this.queue = this.queue.filter((q) => {
        const k = this.key(q[0], q[1]);
        if (this.modified.has(k) && !this.chunks.has(k)) { this.loadChunk(q[0], q[1]); return false; }
        return true;
      });
    }
    if (this.worker && this.worker.ok) {
      while (this.queue.length && this.pending.size < 3) {
        const q = this.queue.shift(), k = this.key(q[0], q[1]);
        if (this.chunks.has(k) || this.pending.has(k)) continue;
        if (this.modified.has(k)) { this.loadChunk(q[0], q[1]); continue; }     // chunk ที่เคยแก้ไข : โหลดจากเซฟ ไม่ต้องสร้าง
        this.pending.add(k); this.worker.request(q[0], q[1]);
      }
    } else {
      const t0 = performance.now();
      while (this.queue.length) {
        const q = this.queue.shift();
        if (!this.getChunk(q[0], q[1]) && !this.pending.has(this.key(q[0], q[1]))) this.loadChunk(q[0], q[1]);
        if (performance.now() - t0 > C.GEN_BUDGET_MS) break;
      }
    }
    this.meshPass(cx, cz, C.MESH_PER_FRAME, this.renderDistance);
  }
};
