// Voxel raycast (Amanatides-Woo DDA) : คืนบล็อกแรกที่ชน + ทิศหน้าที่ชน (normal)
VX.Raycast = {
  // ray เจอกล่องเล็กในช่อง (x,y,z) หรือไม่ : คืนระยะ t หรือ -1
  boxHit(o, d, x, y, z, b) {
    const org = [o.x, o.y, o.z], dir = [d.x, d.y, d.z], mn = [x + b[0], y + b[1], z + b[2]], mx = [x + b[3], y + b[4], z + b[5]];
    let t0 = 0, t1 = Infinity;
    for (let a = 0; a < 3; a++) {
      if (Math.abs(dir[a]) < 1e-9) { if (org[a] < mn[a] || org[a] > mx[a]) return -1; continue; }
      let a0 = (mn[a] - org[a]) / dir[a], a1 = (mx[a] - org[a]) / dir[a];
      if (a0 > a1) { const t = a0; a0 = a1; a1 = t; }
      t0 = Math.max(t0, a0); t1 = Math.min(t1, a1);
      if (t0 > t1) return -1;
    }
    return t0;
  },
  cast(world, o, d, max) {
    let x = Math.floor(o.x), y = Math.floor(o.y), z = Math.floor(o.z);
    const sx = Math.sign(d.x), sy = Math.sign(d.y), sz = Math.sign(d.z);
    const tDx = sx ? Math.abs(1 / d.x) : Infinity;
    const tDy = sy ? Math.abs(1 / d.y) : Infinity;
    const tDz = sz ? Math.abs(1 / d.z) : Infinity;
    let tMx = sx > 0 ? (x + 1 - o.x) * tDx : sx < 0 ? (o.x - x) * tDx : Infinity;
    let tMy = sy > 0 ? (y + 1 - o.y) * tDy : sy < 0 ? (o.y - y) * tDy : Infinity;
    let tMz = sz > 0 ? (z + 1 - o.z) * tDz : sz < 0 ? (o.z - z) * tDz : Infinity;
    let nx = 0, ny = 0, nz = 0;
    for (;;) {
      const b = world.getBlock(x, y, z);
      if (b !== 0) {
        const def = VX.Blocks.get(b);
        if (!def.liquid) {                                  // ข้ามน้ำ
          if (!def.box) return { x, y, z, nx, ny, nz };
          const t = VX.Raycast.boxHit(o, d, x, y, z, def.box);          // บล็อกเล็ก : ต้องเล็งโดนตัวก้อนจริง ๆ ไม่ใช่แค่ช่อง
          if (t >= 0 && t <= max) return { x, y, z, nx, ny, nz };
        }
      }
      let t;
      if (tMx < tMy && tMx < tMz) { x += sx; t = tMx; tMx += tDx; nx = -sx; ny = 0; nz = 0; }
      else if (tMy < tMz) { y += sy; t = tMy; tMy += tDy; nx = 0; ny = -sy; nz = 0; }
      else { z += sz; t = tMz; tMz += tDz; nx = 0; ny = 0; nz = -sz; }
      if (t > max) return null;
    }
  }
};
