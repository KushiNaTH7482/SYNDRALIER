// Seeded Perlin noise (2D/3D) + fbm  : seed เดิม = ผลลัพธ์เดิมเสมอ
VX.Noise = (function () {
  function rng(a) {
    return function () {
      a |= 0; a = a + 0x6D2B79F5 | 0;
      let t = Math.imul(a ^ a >>> 15, 1 | a);
      t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
      return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
  }
  const fade = (t) => t * t * t * (t * (t * 6 - 15) + 10);
  const lerp = (a, b, t) => a + (b - a) * t;
  function g2(h, x, y) {
    switch (h & 7) {
      case 0: return x + y; case 1: return -x + y; case 2: return x - y; case 3: return -x - y;
      case 4: return x; case 5: return -x; case 6: return y; default: return -y;
    }
  }
  function g3(h, x, y, z) {
    h &= 15;
    const u = h < 8 ? x : y, v = h < 4 ? y : (h === 12 || h === 14 ? x : z);
    return ((h & 1) ? -u : u) + ((h & 2) ? -v : v);
  }

  function create(seed) {
    const r = rng(seed), p = [], perm = new Uint8Array(512);
    for (let i = 0; i < 256; i++) p[i] = i;
    for (let i = 255; i > 0; i--) { const j = Math.floor(r() * (i + 1)); const t = p[i]; p[i] = p[j]; p[j] = t; }
    for (let i = 0; i < 512; i++) perm[i] = p[i & 255];

    function noise2(x, y) {
      const X = Math.floor(x), Y = Math.floor(y);
      x -= X; y -= Y;
      const xi = X & 255, yi = Y & 255, u = fade(x), v = fade(y);
      const aa = perm[perm[xi] + yi], ab = perm[perm[xi] + yi + 1];
      const ba = perm[perm[xi + 1] + yi], bb = perm[perm[xi + 1] + yi + 1];
      return lerp(lerp(g2(aa, x, y), g2(ba, x - 1, y), u), lerp(g2(ab, x, y - 1), g2(bb, x - 1, y - 1), u), v);
    }
    function noise3(x, y, z) {
      const X = Math.floor(x), Y = Math.floor(y), Z = Math.floor(z);
      x -= X; y -= Y; z -= Z;
      const xi = X & 255, yi = Y & 255, zi = Z & 255;
      const u = fade(x), v = fade(y), w = fade(z);
      const A = perm[xi] + yi, AA = perm[A] + zi, AB = perm[A + 1] + zi;
      const B = perm[xi + 1] + yi, BA = perm[B] + zi, BB = perm[B + 1] + zi;
      return lerp(
        lerp(lerp(g3(perm[AA], x, y, z), g3(perm[BA], x - 1, y, z), u),
             lerp(g3(perm[AB], x, y - 1, z), g3(perm[BB], x - 1, y - 1, z), u), v),
        lerp(lerp(g3(perm[AA + 1], x, y, z - 1), g3(perm[BA + 1], x - 1, y, z - 1), u),
             lerp(g3(perm[AB + 1], x, y - 1, z - 1), g3(perm[BB + 1], x - 1, y - 1, z - 1), u), v), w);
    }
    function fbm2(x, y, oct) {
      let a = 1, f = 1, s = 0, n = 0;
      for (let i = 0; i < oct; i++) { s += noise2(x * f, y * f) * a; n += a; a *= 0.5; f *= 2; }
      return s / n;
    }
    return { noise2, noise3, fbm2 };
  }
  return { create };
})();
