// Chunk : เก็บบล็อก 16x64x16 + สร้าง mesh (face culling) แยกชั้นทึบกับน้ำ
VX.Chunk = (function () {
  const S = VX.Config.CHUNK_SIZE, H = VX.Config.CHUNK_HEIGHT;

  const FACES = [
    { dir: [1, 0, 0],  part: 'side',   shade: 0.6, c: [[1,0,0],[1,1,0],[1,1,1],[1,0,1]] },
    { dir: [-1, 0, 0], part: 'side',   shade: 0.6, c: [[0,0,1],[0,1,1],[0,1,0],[0,0,0]] },
    { dir: [0, 1, 0],  part: 'top',    shade: 1.0, c: [[0,1,0],[0,1,1],[1,1,1],[1,1,0]] },
    { dir: [0, -1, 0], part: 'bottom', shade: 0.5, c: [[0,0,1],[0,0,0],[1,0,0],[1,0,1]] },
    { dir: [0, 0, 1],  part: 'side',   shade: 0.8, c: [[1,0,1],[1,1,1],[0,1,1],[0,0,1]] },
    { dir: [0, 0, -1], part: 'side',   shade: 0.8, c: [[0,0,0],[0,1,0],[1,1,0],[1,0,0]] }
  ];
  const CORNER_UV = [[0, 0], [0, 1], [1, 1], [1, 0]];
  const newBuf = () => ({ pos: [], nor: [], uvs: [], col: [], ind: [], v: 0 });

  function toMesh(b, material, x, z, order) {
    if (!b.v) return null;
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(b.pos, 3));
    g.setAttribute('normal', new THREE.Float32BufferAttribute(b.nor, 3));
    g.setAttribute('uv', new THREE.Float32BufferAttribute(b.uvs, 2));
    g.setAttribute('color', new THREE.Float32BufferAttribute(b.col, 3));
    g.setIndex(b.ind);
    const m = new THREE.Mesh(g, material);
    m.position.set(x, 0, z);
    m.renderOrder = order;
    return m;
  }

  class Chunk {
    constructor(cx, cz) {
      this.cx = cx; this.cz = cz;
      this.data = new Uint8Array(S * H * S);
      this.meshes = [];
      this.dirty = true;       // ต้อง build mesh ใหม่
      this.urgent = false;     // แก้ไขโดยผู้เล่น: build ทันทีในเฟรมนี้
      this.modified = false;   // ผู้เล่นแก้ไขแล้ว (ต้องเก็บ ไม่ทิ้งตอน unload)
    }
    idx(x, y, z) { return (y * S + z) * S + x; }
    get(x, y, z) {
      if (x < 0 || x >= S || y < 0 || y >= H || z < 0 || z >= S) return 0;
      return this.data[this.idx(x, y, z)];
    }
    set(x, y, z, id) { this.data[this.idx(x, y, z)] = id; this.dirty = true; this.hm = null; }

    // heightmap แสงท้องฟ้า : y ของบล็อกทึบสูงสุดในคอลัมน์ + 1 (ใบไม้/น้ำ/อากาศไม่บังแสง)
    heightAt(lx, lz) {
      if (!this.hm) {
        const hm = this.hm = new Uint8Array(S * S);
        for (let z = 0; z < S; z++) for (let x = 0; x < S; x++) {
          let y = H - 1;
          while (y >= 0 && VX.Blocks.get(this.data[this.idx(x, y, z)]).transparent) y--;
          hm[z * S + x] = y + 1;
        }
      }
      return this.hm[lz * S + lx];
    }

    // คืน array ของ mesh [ทึบ, น้ำ] (บางตัวอาจไม่มี)
    buildMesh(world, mats) {
      const O = newBuf(), W = newBuf();
      const wx0 = this.cx * S, wz0 = this.cz * S;
      for (let y = 0; y < H; y++) for (let z = 0; z < S; z++) for (let x = 0; x < S; x++) {
        const id = this.data[this.idx(x, y, z)];
        if (!id) continue;
        const def = VX.Blocks.get(id), b = def.liquid ? W : O;
        if (def.shape === 'cross') {                                // พืชไขว้ : สองแผ่นทแยง วาดทั้งสองด้าน
          const h = def.cross, u = def.faceUV.side, sky = world.skyExposed(wx0 + x, y, wz0 + z) ? 1 : 0, blk = def.light / 15;
          const planes = [[0.1, 0.1, 0.9, 0.9], [0.9, 0.1, 0.1, 0.9]];
          for (const p of planes) for (let side = 0; side < 2; side++) {
            const co = [[p[0], 0, p[1]], [p[0], h, p[1]], [p[2], h, p[3]], [p[2], 0, p[3]]];
            for (let k = 0; k < 4; k++) {
              b.pos.push(x + co[k][0], y + co[k][1], z + co[k][2]);
              b.nor.push(0, 1, 0);
              b.uvs.push(CORNER_UV[k][0] ? u[2] : u[0], CORNER_UV[k][1] ? u[3] : u[1]);
              b.col.push(1, sky, blk);
            }
            if (side === 0) b.ind.push(b.v, b.v + 1, b.v + 2, b.v, b.v + 2, b.v + 3);
            else b.ind.push(b.v, b.v + 2, b.v + 1, b.v, b.v + 3, b.v + 2);
            b.v += 4;
          }
          continue;
        }
        if (def.box) {                                              // บล็อกเล็กไม่เต็มช่อง : วาดครบทุกหน้า
          const bx = def.box, sky = world.skyExposed(wx0 + x, y, wz0 + z) ? 1 : 0, blk = def.light / 15;
          for (const f of FACES) {
            const u = def.faceUV[f.part];
            for (let k = 0; k < 4; k++) {
              b.pos.push(x + bx[0] + f.c[k][0] * (bx[3] - bx[0]), y + bx[1] + f.c[k][1] * (bx[4] - bx[1]), z + bx[2] + f.c[k][2] * (bx[5] - bx[2]));
              b.nor.push(f.dir[0], f.dir[1], f.dir[2]);
              b.uvs.push(CORNER_UV[k][0] ? u[2] : u[0], CORNER_UV[k][1] ? u[3] : u[1]);
              b.col.push(f.shade, sky, blk);
            }
            b.ind.push(b.v, b.v + 1, b.v + 2, b.v, b.v + 2, b.v + 3);
            b.v += 4;
          }
          continue;
        }
        for (const f of FACES) {
          const fx = wx0 + x + f.dir[0], fy = y + f.dir[1], fz = wz0 + z + f.dir[2];
          const nid = world.getBlock(fx, fy, fz);
          const nd = VX.Blocks.get(nid);
          if (!(nd.transparent && nid !== id)) continue;   // face culling
          const u = def.faceUV[f.part];
          const sky = world.skyExposed(fx, fy, fz) ? 1 : 0, blk = Math.max(def.light, nd.light) / 15;
          for (let k = 0; k < 4; k++) {
            b.pos.push(x + f.c[k][0], y + f.c[k][1], z + f.c[k][2]);
            b.nor.push(f.dir[0], f.dir[1], f.dir[2]);
            b.uvs.push(CORNER_UV[k][0] ? u[2] : u[0], CORNER_UV[k][1] ? u[3] : u[1]);
            b.col.push(f.shade, sky, blk);
          }
          b.ind.push(b.v, b.v + 1, b.v + 2, b.v, b.v + 2, b.v + 3);
          b.v += 4;
        }
      }
      this.disposeMesh();
      this.dirty = false;
      const a = toMesh(O, mats.opaque, wx0, wz0, 0), w = toMesh(W, mats.water, wx0, wz0, 1);
      if (a) this.meshes.push(a);
      if (w) this.meshes.push(w);
      return this.meshes;
    }
    disposeMesh() {
      for (const m of this.meshes) { if (m.parent) m.parent.remove(m); m.geometry.dispose(); }
      this.meshes = [];
    }
  }
  Chunk.FACES = FACES; Chunk.CORNER_UV = CORNER_UV;
  return Chunk;
})();
