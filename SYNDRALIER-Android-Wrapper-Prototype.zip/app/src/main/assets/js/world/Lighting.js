// Lighting : แสงต่อ vertex = ความสว่างหน้า (r) x [แสงท้องฟ้า (g) ตามเวลากลางวัน หรือแสงจากบล็อก (b)]
// ค่า g/b ถูกอบลง mesh ตอนสร้าง chunk ส่วนความสว่างของกลางวัน/กลางคืนปรับด้วย uniform ตัวเดียว (ไม่ต้อง rebuild mesh)
VX.Lighting = {
  uDay: { value: 1 },       // 0.12 (กลางคืน) .. 1 (กลางวัน)
  uMin: { value: 0.2 },     // แสงต่ำสุด (ในถ้ำ/ที่มืดสนิท)
  patch(mat) {
    const self = this;
    mat.onBeforeCompile = (sh) => {
      sh.uniforms.uDay = self.uDay;
      sh.uniforms.uMin = self.uMin;
      sh.fragmentShader = 'uniform float uDay;\nuniform float uMin;\n' + sh.fragmentShader.replace(
        '#include <color_fragment>',
        'diffuseColor.rgb *= vColor.r * (uMin + (1.0 - uMin) * max(vColor.g * uDay, vColor.b));');
    };
  }
};
