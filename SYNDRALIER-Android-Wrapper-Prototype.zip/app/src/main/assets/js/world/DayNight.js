// DayNight : เวลาในเกม, ดวงอาทิตย์/ดวงจันทร์/ดาว, สีท้องฟ้า, ความสว่างของโลก
// time: 0 = เที่ยงคืน, 0.25 = พระอาทิตย์ขึ้น, 0.5 = เที่ยงวัน, 0.75 = พระอาทิตย์ตก
// Mob Spawner (Phase 7) ใช้ isNight / on('night'|'day') ได้โดยตรง
VX.DayNight = class {
  constructor(scene, camera) {
    this.scene = scene; this.camera = camera;
    this.length = VX.Config.DAY_LENGTH;
    this.time = VX.Config.START_TIME;
    this.day = 1;
    this.listeners = {};
    this.sky = new THREE.Color();
    this.sinElev = 1; this.daylight = 1; this.isNight = false; this.phase = 'day';
    this.NIGHT = new THREE.Color(0x0a0f2a); this.DAY = new THREE.Color(0x87ceeb); this.DUSK = new THREE.Color(0xf08a50);
    this.dir = new THREE.Vector3();
    this.PRESETS = [['เช้า', 0.28], ['เที่ยง', 0.5], ['เย็น', 0.72], ['เที่ยงคืน', 0.0]];
    this.presetIdx = 0;

    const tex = (draw) => {
      const c = document.createElement('canvas'); c.width = c.height = 64;
      draw(c.getContext('2d'));
      const t = new THREE.CanvasTexture(c); t.magFilter = t.minFilter = THREE.NearestFilter; return t;
    };
    const sunTex = tex((g) => { g.fillStyle = '#ffe58a'; g.fillRect(8, 8, 48, 48); g.fillStyle = '#fffbe0'; g.fillRect(18, 18, 28, 28); });
    const moonTex = tex((g) => {
      g.fillStyle = '#d9dde8'; g.fillRect(10, 10, 44, 44);
      g.fillStyle = '#aeb4c4'; g.fillRect(18, 18, 10, 10); g.fillRect(36, 30, 12, 12); g.fillRect(22, 40, 8, 8);
    });
    const mk = (t) => {
      const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: t, fog: false, depthWrite: false, transparent: true }));
      s.scale.set(34, 34, 1); s.renderOrder = -10; s.frustumCulled = false; scene.add(s); return s;
    };
    this.sun = mk(sunTex); this.moon = mk(moonTex);

    const N = 350, p = new Float32Array(N * 3);
    for (let i = 0; i < N; i++) {                      // ดาวกระจายบนครึ่งทรงกลม
      const u = Math.random() * 2 - 1, a = Math.random() * Math.PI * 2, r = Math.sqrt(1 - u * u);
      p[i * 3] = Math.cos(a) * r * 220; p[i * 3 + 1] = u * 220; p[i * 3 + 2] = Math.sin(a) * r * 220;
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(p, 3));
    this.starMat = new THREE.PointsMaterial({ color: 0xffffff, size: 2, sizeAttenuation: false, transparent: true, opacity: 0, fog: false, depthWrite: false });
    this.stars = new THREE.Points(g, this.starMat);
    this.stars.frustumCulled = false; this.stars.renderOrder = -11;
    scene.add(this.stars);
    this.update(0);
  }

  on(evt, fn) { (this.listeners[evt] = this.listeners[evt] || []).push(fn); }
  emit(evt) { (this.listeners[evt] || []).forEach((fn) => fn(this)); }

  setTime(t) { this.time = ((t % 1) + 1) % 1; this.update(0); }
  cyclePreset() {                                   // ปุ่มทดสอบ : เช้า -> เที่ยง -> เย็น -> เที่ยงคืน
    this.presetIdx = (this.presetIdx + 1) % this.PRESETS.length;
    this.setTime(this.PRESETS[this.presetIdx][1]);
    return this.PRESETS[this.presetIdx][0];
  }
  clock() {
    const m = Math.floor(this.time * 1440), h = Math.floor(m / 60) % 24;
    return (h < 10 ? '0' : '') + h + ':' + (m % 60 < 10 ? '0' : '') + (m % 60);
  }

  update(dt) {
    if (dt > 0) {
      this.time += dt / this.length;
      if (this.time >= 1) { this.time -= 1; this.day++; this.emit('newday'); }
    }
    const a = (this.time - 0.25) * Math.PI * 2, s = Math.sin(a);
    this.sinElev = s;
    const t = Math.max(0, Math.min(1, (s + 0.12) / 0.4));
    this.daylight = t * t * (3 - 2 * t);

    const was = this.isNight;
    this.isNight = s < -0.08;
    if (was !== this.isNight) this.emit(this.isNight ? 'night' : 'day');
    this.phase = this.isNight ? 'night' : s < 0.2 ? (this.time < 0.5 ? 'dawn' : 'dusk') : 'day';

    const tw = Math.max(0, 1 - Math.abs(s) / 0.22);                    // ช่วงขอบฟ้า : โทนส้ม
    this.sky.copy(this.NIGHT).lerp(this.DAY, this.daylight).lerp(this.DUSK, tw * 0.55);
    VX.Lighting.uDay.value = 0.12 + 0.88 * this.daylight;

    // ตำแหน่งบนท้องฟ้า (ตามกล้อง)
    this.dir.set(Math.cos(a), Math.sin(a), 0.25).normalize();
    const c = this.camera.position;
    this.sun.position.set(c.x + this.dir.x * 200, c.y + this.dir.y * 200, c.z + this.dir.z * 200);
    this.moon.position.set(c.x - this.dir.x * 200, c.y - this.dir.y * 200, c.z - this.dir.z * 200);
    this.sun.visible = s > -0.05;
    this.moon.visible = s < 0.05;
    this.sun.material.color.setRGB(1, 1 - tw * 0.35, 1 - tw * 0.6);
    this.stars.position.copy(c);
    this.stars.rotation.z = a;
    this.starMat.opacity = Math.max(0, 1 - this.daylight * 1.6);
    this.stars.visible = this.starMat.opacity > 0.01;
  }

  serialize() { return { time: this.time, day: this.day }; }
  deserialize(d) { this.time = d.time; this.day = d.day; this.update(0); }
};
