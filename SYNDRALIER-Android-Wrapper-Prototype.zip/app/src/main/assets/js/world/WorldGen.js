// World Generation : procedural จาก seed (biome, ภูเขา, ทะเล, ถ้ำ, แร่, ต้นไม้)
// generateChunk() เป็นฟังก์ชันที่ผลลัพธ์ขึ้นกับ seed + พิกัดเท่านั้น จึงสร้างซ้ำได้เหมือนเดิม
VX.WorldGen = (function () {
  const C = VX.Config, S = C.CHUNK_SIZE, H = C.CHUNK_HEIGHT, SEA = C.SEA_LEVEL;
  const smooth = (a, b, x) => { const t = Math.max(0, Math.min(1, (x - a) / (b - a))); return t * t * (3 - 2 * t); };

  function create(seed) {
    const N = VX.Noise.create(seed);
    const id = (n) => VX.Blocks.byName(n).id;
    const GRASS = id('grass'), DIRT = id('dirt'), STONE = id('stone'), SAND = id('sand'), WOOD = id('wood'),
      LEAVES = id('leaves'), GRAVEL = id('gravel'), WATER = id('water'), COAL = id('coal_ore'),
      IRON = id('iron_ore'), COPPER = id('copper_ore'), GOLD = id('gold_ore'), DIAMOND = id('diamond_ore'), SNOW = id('snow');

    function hash(x, y, z, s) {
      let h = (x * 374761393 + y * 668265263 + z * 1274126177 + s * 2246822519 + seed * 3266489917) | 0;
      h = Math.imul(h ^ (h >>> 13), 1274126177);
      h ^= h >>> 16;
      return (h >>> 0) / 4294967296;
    }

    // ความสูงและ biome ของคอลัมน์ (x,z)
    function columnInfo(x, z) {
      const cont = N.fbm2(x * 0.006, z * 0.006, 4) * 2.2;
      const hills = N.fbm2(x * 0.03 + 500, z * 0.03 + 500, 3) * 2.2;
      const mm = smooth(0.15, 0.55, N.fbm2(x * 0.004 + 900, z * 0.004 + 900, 3) * 2.2);
      let h = SEA + 3 + cont * 9 + hills * 3.5 + mm * (14 + (hills * 0.5 + 0.5) * 14);
      h = Math.floor(Math.min(H - 3, Math.max(3, h)));
      const temp = N.fbm2(x * 0.003 + 1300, z * 0.003 + 1300, 2) * 2.2;
      const humid = N.fbm2(x * 0.004 + 1700, z * 0.004 + 1700, 2) * 2.2;
      let biome;
      if (mm > 0.45 && h > SEA + 14) biome = 'mountains';
      else if (temp < -0.3) biome = 'snow';
      else if (temp > 0.3 && humid < 0.1) biome = 'desert';
      else if (humid > 0.15) biome = 'forest';
      else biome = 'plains';
      return { h, biome };
    }

    function blockAt(info, y, x, z) {
      const h = info.h, depth = h - y, b = info.biome;
      if (b === 'mountains') {
        if (depth === 0) return h > SEA + 26 ? SNOW : (hash(x, y, z, 7) < 0.08 ? GRAVEL : STONE);
        return STONE;
      }
      if (h <= SEA + 1) return depth <= 3 ? (h < SEA - 3 ? GRAVEL : SAND) : STONE;   // ชายหาด/ก้นทะเล
      if (b === 'desert') return depth <= 3 ? SAND : STONE;
      if (b === 'snow') return depth === 0 ? SNOW : depth <= 3 ? DIRT : STONE;
      return depth === 0 ? GRASS : depth <= 3 ? DIRT : STONE;
    }

    const ROCK = id('rock'), TUFT = id('tuft'), FIBER_GRASS = id('fiber_grass'), FERN = id('fern');
    // [หญ้าสั้น, หญ้า Fiber, เฟิร์น] โอกาสต่อคอลัมน์ ตาม biome (บนพื้นหญ้า/หิมะเท่านั้น)
    const PLANT_P = { plains: [0.14, 0.035, 0.01], forest: [0.1, 0.03, 0.06], snow: [0.02, 0, 0.03], mountains: [0.015, 0.005, 0.02] };
    const ROCK_P = { plains: 0.02, forest: 0.015, snow: 0.015, desert: 0.012, mountains: 0.035 };    // โอกาสมีหินก้อนเล็กต่อคอลัมน์

    function isCave(x, y, z) {
      const a = N.noise3(x * 0.045, y * 0.07, z * 0.045);
      if (Math.abs(a) > 0.08) return false;
      const b = N.noise3(x * 0.045 + 71, y * 0.07 + 31, z * 0.045 + 17);
      return Math.abs(b) < 0.08;
    }

    // แร่เกิดเป็นกลุ่มเล็ก ๆ (cell 2x2x2 ที่สุ่มติดแล้วเติม ~70%)
    function oreAt(x, y, z) {
      const cx = x >> 1, cy = y >> 1, cz = z >> 1;
      if (y < 14 && hash(cx, cy, cz, 11) < 0.0035 && hash(x, y, z, 12) < 0.6) return DIAMOND;
      if (y < 22 && hash(cx, cy, cz, 13) < 0.006 && hash(x, y, z, 14) < 0.7) return GOLD;
      if (y < 40 && hash(cx, cy, cz, 15) < 0.012 && hash(x, y, z, 16) < 0.7) return IRON;
      if (y < 48 && hash(cx, cy, cz, 19) < 0.016 && hash(x, y, z, 20) < 0.7) return COPPER;
      if (y < 52 && hash(cx, cy, cz, 17) < 0.02 && hash(x, y, z, 18) < 0.7) return COAL;
      return 0;
    }

    function generateChunk(chunk) {
      const cx0 = chunk.cx * S, cz0 = chunk.cz * S, d = chunk.data, P = 2, E = S + 2 * P;
      const ext = new Array(E * E);
      for (let z = 0; z < E; z++) for (let x = 0; x < E; x++) ext[z * E + x] = columnInfo(cx0 + x - P, cz0 + z - P);

      for (let z = 0; z < S; z++) for (let x = 0; x < S; x++) {
        const info = ext[(z + P) * E + x + P], wx = cx0 + x, wz = cz0 + z;
        for (let y = 0; y <= info.h; y++) {
          let b = blockAt(info, y, wx, wz);
          if (y > 2 && y < info.h - 3) {
            if (isCave(wx, y, wz)) b = 0;
            else if (b === STONE) b = oreAt(wx, y, wz) || STONE;
          }
          d[(y * S + z) * S + x] = b;
        }
        for (let y = info.h + 1; y <= SEA; y++) d[(y * S + z) * S + x] = WATER;
        if (info.h > SEA + 1 && info.h < H - 3) {
          const ci = ((info.h + 1) * S + z) * S + x;
          if (hash(wx, 0, wz, 60) < ROCK_P[info.biome]) d[ci] = ROCK;
          else {
            const top = d[(info.h * S + z) * S + x], pp = PLANT_P[info.biome];
            if (pp && (top === GRASS || top === SNOW)) {
              const r = hash(wx, 0, wz, 61);
              if (r < pp[0]) d[ci] = TUFT; else if (r < pp[0] + pp[1]) d[ci] = FIBER_GRASS; else if (r < pp[0] + pp[1] + pp[2]) d[ci] = FERN;
            }
          }
        }
      }

      // ต้นไม้ (ตรวจคอลัมน์ข้าง chunk ด้วย เพื่อให้ใบไม้ข้ามขอบ chunk ได้)
      const put = (wx, y, wz, b, onlyAir) => {
        const lx = wx - cx0, lz = wz - cz0;
        if (lx < 0 || lx >= S || lz < 0 || lz >= S || y < 0 || y >= H) return;
        const i = (y * S + lz) * S + lx;
        if (onlyAir && d[i] !== 0) return;
        d[i] = b;
      };
      for (let ez = 0; ez < E; ez++) for (let ex = 0; ex < E; ex++) {
        const info = ext[ez * E + ex], wx = cx0 + ex - P, wz = cz0 + ez - P;
        const p = info.biome === 'forest' ? 0.03 : info.biome === 'plains' ? 0.004 : info.biome === 'snow' ? 0.006 : 0;
        if (!p || info.h <= SEA + 1 || info.h > H - 12 || hash(wx, 0, wz, 50) >= p) continue;
        const th = 4 + Math.floor(hash(wx, 0, wz, 51) * 2), topY = info.h + th;
        for (let dy = -1; dy <= 1; dy++) {
          const r = dy < 1 ? 2 : 1;
          for (let dz = -r; dz <= r; dz++) for (let dx = -r; dx <= r; dx++) {
            const corner = Math.abs(dx) === r && Math.abs(dz) === r;
            if (corner && (r === 1 || hash(wx + dx, topY + dy, wz + dz, 52) < 0.5)) continue;
            put(wx + dx, topY + dy, wz + dz, LEAVES, true);
          }
        }
        for (let y = info.h + 1; y <= topY; y++) put(wx, y, wz, WOOD, false);
      }
      chunk.dirty = true;
    }

    // หาจุดเกิดบนบก (ไม่ใช่ภูเขา/ทะเล) ใกล้ (0,0)
    function spawnPoint() {
      for (let r = 0; r < 600; r += 8) {
        const n = r ? 8 : 1;
        for (let a = 0; a < n; a++) {
          const x = Math.floor(Math.cos(a * Math.PI / 4) * r), z = Math.floor(Math.sin(a * Math.PI / 4) * r);
          const info = columnInfo(x, z);
          if (info.h > SEA + 2 && info.h < SEA + 14 && info.biome !== 'mountains' && hash(x, 0, z, 50) >= 0.04)
            return { x: x + 0.5, y: info.h + 1, z: z + 0.5 };
        }
      }
      return { x: 0.5, y: Math.max(columnInfo(0, 0).h, SEA) + 1, z: 0.5 };
    }

    return { seed, columnInfo, generateChunk, spawnPoint };
  }
  return { create };
})();
