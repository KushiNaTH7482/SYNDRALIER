// พฤติกรรมพื้นฐาน : idle, wander, chase, attack, ranged, flee, hurt, dead
// พารามิเตอร์ของแต่ละมอนอ่านจาก mob.type.ai (ดู MobTypes.js)
(function () {
  const rand = (a, b) => a + Math.random() * (b - a);
  const reg = VX.AI.register.bind(VX.AI);

  reg('idle', {
    enter(m) { m.stop(); m._wait = rand(1, 3.5); },
    update(m, dt, sm) {
      m.stop();
      if (m.tryDetect()) return;                      // Detect player
      if (sm.time > m._wait) sm.set('wander');
    }
  });

  reg('wander', {
    enter(m) {
      m._wt = rand(3, 6); m._goal = null;
      for (let i = 0; i < 8 && !m._goal; i++) {        // เลือกจุดหมายที่ไม่ใช่ขอบหน้าผา/น้ำ
        const a = Math.random() * Math.PI * 2, d = rand(3, 7), dx = Math.cos(a), dz = Math.sin(a);
        if (m.safeAhead(dx, dz)) m._goal = { x: m.pos.x + dx * d, z: m.pos.z + dz * d };
      }
    },
    update(m, dt, sm) {
      if (m.tryDetect()) return;
      if (!m._goal || sm.time > m._wt || Math.hypot(m._goal.x - m.pos.x, m._goal.z - m.pos.z) < 0.6) { sm.set('idle'); return; }
      m.walkToward(m._goal.x, m._goal.z, m.type.speed);
    }
  });

  reg('chase', {
    update(m, dt, sm) {
      const ai = m.type.ai, d = m.distToPlayer(), p = m.mgr.player;
      if (p.dead || d > ai.lose || (m.type.hostility === 'neutral' && m.aggro <= 0)) { sm.set('idle'); return; }
      if (d <= ai.range && m.cool <= 0) { sm.set('attack'); return; }
      if (d > ai.range * 0.8) m.walkToward(p.pos.x, p.pos.z, ai.chaseSpeed);
      else { m.stop(); m.face(p.pos.x, p.pos.z); }
    }
  });

  reg('attack', {                                      // เตรียมตี (windup) -> ตี -> พัก
    enter(m) { m.stop(); m._hit = false; },
    update(m, dt, sm) {
      const ai = m.type.ai, p = m.mgr.player;
      m.stop(); m.face(p.pos.x, p.pos.z);
      if (!m._hit && sm.time >= ai.windup) {
        m._hit = true; m.cool = ai.cooldown;
        if (!p.dead && m.distToPlayer() <= ai.range + 0.5 && p.damage(ai.damage, m.pos)) VX.sfx('mobAttack', { pos: m.pos });
      }
      if (sm.time >= ai.windup + 0.35) sm.set('chase');
    }
  });

  // ศัตรูระยะไกล : ขยับ (รักษาระยะ) หรือ "เล็ง" อย่างใดอย่างหนึ่ง — ตอนเล็งต้องหยุดนิ่ง (เห็นยกแขน) แล้วค่อยยิง
  // จึงเป็นจังหวะให้ผู้เล่นวิ่งเข้าไปตีหรือหลบได้ ไม่ใช่เดินถอยไปยิงไปตลอด
  reg('ranged', {
    enter(m) { m._charge = 0; },
    update(m, dt, sm) {
      const ai = m.type.ai, p = m.mgr.player, d = m.distToPlayer();
      if (p.dead || d > ai.lose) { sm.set('idle'); return; }

      if (m._charge > 0) {                               // กำลังเล็ง : หยุดนิ่งและหันหาผู้เล่น
        m.stop(); m.face(p.pos.x, p.pos.z);
        m._charge -= dt;
        if (m._charge <= 0) {
          m._charge = 0; m.cool = ai.cooldown;
          if (d <= ai.maxRange + 4 && m.lineOfSight()) m.mgr.shoot(m);
        }
        return;
      }
      if (d < ai.minRange) m.walkAway(p.pos.x, p.pos.z, ai.retreatSpeed || ai.chaseSpeed);
      else if (d > ai.maxRange) m.walkToward(p.pos.x, p.pos.z, ai.chaseSpeed);
      else { m.stop(); m.face(p.pos.x, p.pos.z); }
      if (m.cool <= 0 && d <= ai.maxRange + 2 && d >= ai.minRange * 0.6 && m.lineOfSight()) m._charge = ai.aimTime || 0.7;
    }
  });

  reg('flee', {
    enter(m) { m._ft = rand(4, 6); },
    update(m, dt, sm) {
      const p = m.mgr.player;
      m.walkAway(p.pos.x, p.pos.z, m.type.ai.fleeSpeed || m.type.speed * 2.5);
      if (sm.time > m._ft) sm.set('idle');
    }
  });

  reg('hurt', {                                        // Take damage : ชะงักสั้น ๆ ขณะแรงกระเด็น (Knockback) ทำงาน
    enter(m) { m.stop(); m.hurtT = 0.3; },
    update(m, dt, sm) {
      m.stop();
      if (m.hurtT <= 0) sm.set(m.type.ai.onHurt || 'idle');
    }
  });

  reg('dead', {
    enter(m) { m.stop(); m.deathT = 0; },
    update(m, dt) { m.stop(); m.deathT += dt; if (m.deathT > 0.9) m.remove = true; }
  });
})();
