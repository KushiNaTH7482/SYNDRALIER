// StateMachine : AI ทุกตัวใช้ตัวนี้ — state คือ object { enter, update, exit } ลงทะเบียนใน VX.AI
// เพิ่มพฤติกรรมใหม่ = VX.AI.register('ชื่อ', {...}) แล้วอ้างชื่อใน MobTypes ไม่ต้องแก้ Mob.js
VX.AI = { states: {}, register(name, def) { this.states[name] = def; } };

VX.StateMachine = class {
  constructor(owner, initial) {
    this.owner = owner; this.name = null; this.cur = null; this.time = 0;
    this.set(initial);
  }
  set(name) {
    const next = VX.AI.states[name];
    if (!next) throw new Error('Unknown AI state: ' + name);
    if (this.cur && this.cur.exit) this.cur.exit(this.owner, this);
    this.name = name; this.cur = next; this.time = 0;
    if (next.enter) next.enter(this.owner, this);
  }
  update(dt) {
    this.time += dt;
    if (this.cur.update) this.cur.update(this.owner, dt, this);
  }
};
