// Interaction : เล็งบล็อก (raycast), ขุดแบบกดค้าง (ดรอปไอเทม), วางบล็อกจาก Hotbar, ทิ้งไอเทม
VX.Interaction = class {
  constructor(world, player, camera, input, scene, inventory, items, blueprints, mobs, fx) {
    this.world = world; this.player = player; this.camera = camera; this.input = input;
    this.inv = inventory; this.items = items;
    this.blueprints = blueprints || null;
    this.mobs = mobs || null;
    this.fx = fx || null;
    this.atkCd = 0; this.atkMax = 1; this.hitT = 0; this.mining = false;
    this.crosshair = document.getElementById('crosshair');
    this.atkBar = document.getElementById('atk-bar');
    this.onStation = null;
    this.REACH = 5;
    this.target = null;
    this.progress = 0; this.key = null; this.cooldown = 0;
    this.dir = new THREE.Vector3();

    const geo = new THREE.EdgesGeometry(new THREE.BoxGeometry(1.004, 1.004, 1.004));
    this.box = new THREE.LineSegments(geo, new THREE.LineBasicMaterial({ color: 0x000000 }));
    this.box.visible = false;
    scene.add(this.box);

    this.barWrap = document.getElementById('mine-bar');
    this.bar = this.barWrap.firstElementChild;

    input.onSelect = (i) => inventory.select(i);
    input.onCycle = (d) => inventory.cycle(d);
    input.onDrop = () => this.dropSelected();
  }

  update(dt) {
    const cam = this.camera;
    cam.updateMatrixWorld();
    cam.getWorldDirection(this.dir);
    const t = this.target = VX.Raycast.cast(this.world, cam.position, this.dir, this.REACH);
    const tdef = t ? VX.Blocks.get(this.world.getBlock(t.x, t.y, t.z)) : null;

    // มอนอยู่ใกล้กว่าบล็อกที่เล็ง = โจมตีมอนแทนการขุด
    const cs = this.combat();
    const mh = this.mobs ? this.mobs.raycast(cam.position, this.dir, cs.reach, 0.12) : null;
    let mobFirst = false;
    if (mh) {
      if (!t) mobFirst = true;
      else mobFirst = mh.dist < Math.hypot(cam.position.x - (t.x + 0.5), cam.position.y - (t.y + 0.5), cam.position.z - (t.z + 0.5)) - 0.5;
    }
    this.atkCd = Math.max(0, this.atkCd - dt);

    if (t && !mobFirst) {
      const td = VX.Blocks.get(this.world.getBlock(t.x, t.y, t.z)), bx = td.box;
      this.box.visible = true;
      if (bx) {                                           // กรอบเล็งพอดีกับบล็อกเล็ก
        this.box.position.set(t.x + (bx[0] + bx[3]) / 2, t.y + (bx[1] + bx[4]) / 2, t.z + (bx[2] + bx[5]) / 2);
        this.box.scale.set(bx[3] - bx[0] + 0.01, bx[4] - bx[1] + 0.01, bx[5] - bx[2] + 0.01);
      } else { this.box.position.set(t.x + 0.5, t.y + 0.5, t.z + 0.5); this.box.scale.set(1, 1, 1); }
    }
    else this.box.visible = false;

    this.cooldown = Math.max(0, this.cooldown - dt);
    if (this.input.consumePlace()) this.place();

    // ขุด: เวลาขึ้นกับ hardness (ตอนนี้ใช้มือเปล่า ระบบเครื่องมือมาใน Phase 5)
    if (this.input.breaking && mobFirst) {
      if (this.atkCd === 0) this.attackMob(mh.mob, mh.dist, cs);
      this.progress = 0; this.key = null;
    } else if (this.input.breaking && t && t.y > 0 && this.cooldown === 0 && this.canMine(tdef)) {
      const key = t.x + ',' + t.y + ',' + t.z;
      if (key !== this.key) { this.key = key; this.progress = 0; }
      const def = VX.Blocks.get(this.world.getBlock(t.x, t.y, t.z));
      this.progress += dt / Math.max(0.1, this.breakTime(def));
      this.bar.style.background = this.canHarvest(def) ? '#fff' : '#e55';
      if (this.progress >= 1) {
        this.breakBlock(t, def);
        this.progress = 0; this.key = null; this.cooldown = 0.2;
      }
    } else { this.progress = 0; this.key = null; }

    this.barWrap.style.display = this.progress > 0 ? 'block' : 'none';
    this.bar.style.width = (this.progress * 100) + '%';
    this.mining = this.progress > 0;

    // UI การต่อสู้ : แถบชาร์จคูลดาวน์, ครอสแฮร์แดงเมื่อเล็งมอน/โดนมอน
    this.hitT = Math.max(0, this.hitT - dt);
    this.atkBar.style.display = this.atkCd > 0 ? 'block' : 'none';
    this.atkBar.firstElementChild.style.width = (100 * (1 - this.atkCd / this.atkMax)) + '%';
    this.crosshair.classList.toggle('mob', mobFirst);
    this.crosshair.classList.toggle('hit', this.hitT > 0);
  }

  // สถิติการต่อสู้ของสิ่งที่ถืออยู่ (อาวุธ/เครื่องมือ/มือเปล่า)
  combat() {
    const h = this.heldTool(), C = VX.Items.COMBAT;
    if (!h) return { dmg: 1, cd: C.hand.cd, kb: C.hand.kb, reach: C.hand.reach };
    const c = C[h.item.tool.type];
    return { dmg: h.item.tool.damage, cd: c.cd, kb: c.kb, reach: c.reach };
  }

  // โจมตีมอน : ดาเมจตามอาวุธ, คริติคอล x1.5 ถ้าโจมตีขณะกำลังตกลงมา, วิ่งแล้วตีแรงกระเด็นเพิ่ม 50%
  attackMob(mob, dist, cs) {
    cs = cs || this.combat();
    const p = this.player, h = this.heldTool();
    const crit = p.vel.y < -1.5 && !p.onGround && !p.swimming;
    const kb = cs.kb * (p.sprinting ? 1.5 : 1);
    if (!mob.damage(cs.dmg * (crit ? 1.5 : 1), p.pos, kb)) return false;
    this.atkCd = this.atkMax = cs.cd;
    if (p.addExhaust) p.addExhaust(0.1);
    if (h) this.wearTool(h.item.tool.type === 'sword' ? 1 : 2);
    VX.sfx('swing'); VX.sfx(crit ? 'crit' : 'hit', { pos: mob.pos });
    if (this.fx) {
      this.fx.view.swing(Math.min(0.4, cs.cd * 0.7));
      const d = dist || 1, c = this.camera.position;
      this.fx.particles.hit(c.x + this.dir.x * d, c.y + this.dir.y * d, c.z + this.dir.z * d, crit);
    }
    this.hitT = 0.15;
    return true;
  }

  // ---- กฎการขุด : เครื่องมือที่ถือใน Hotbar ----
  heldTool() {
    const s = this.inv.selectedStack(), it = s && VX.Items.get(s.id);
    return it && it.tool ? { stack: s, item: it } : null;
  }
  matches(def) { const h = this.heldTool(); return !!(h && def.tool && h.item.tool.type === def.tool); }
  // บล็อกแบบ toolOnly (เช่นหญ้า Fiber) มือเปล่าทำลายไม่ได้ ต้องถือเครื่องมือที่ถูกชนิด
  canMine(def) { return !(def.toolOnly && !this.canHarvest(def)); }
  canHarvest(def) {
    if (!def.needsTool) return true;
    const h = this.heldTool();
    return !!(h && def.tool && h.item.tool.type === def.tool && h.item.tool.tier >= (def.minTier || 0));
  }
  breakTime(def) {
    const sp = this.matches(def) ? this.heldTool().item.tool.speed : 1;
    return def.hardness * (this.canHarvest(def) ? 1.5 : 5) / sp;
  }
  wearTool(amount) {
    const h = this.heldTool();
    if (!h) return;
    h.stack.dur -= amount || (h.item.tool.type === 'sword' ? 2 : 1);
    if (h.stack.dur <= 0) this.inv.slots[this.inv.selected] = null;   // เครื่องมือพัง
    this.inv.touch();
  }

  breakBlock(t, def) {
    const harvest = this.canHarvest(def);
    VX.sfx('break', { pos: { x: t.x + 0.5, y: t.y + 0.5, z: t.z + 0.5 } });
    if (this.player.addExhaust) this.player.addExhaust(0.005);
    if (this.fx) {
      const tex = def.tex && (def.tex.side || def.tex.top);
      this.fx.particles.chips(t.x + 0.5, t.y + 0.5, t.z + 0.5, tex ? VX.TextureAtlas.avgColor(tex) : [0.5, 0.5, 0.5]);
    }
    this.world.setBlock(t.x, t.y, t.z, 0);
    this.wearTool();
    if (!harvest) return;
    const cx = t.x + 0.5, cy = t.y + 0.4, cz = t.z + 0.5;
    const spawn = (name, n) => {
      const it = VX.Items.byName(name);
      if (it && n > 0) this.items.spawn(it.id, n, cx, cy, cz, (Math.random() - 0.5) * 2, 2.5, (Math.random() - 0.5) * 2, 0.5, it.durability);
    };
    if (def.drop) { const r = def.dropCount; spawn(def.drop, r[0] + Math.floor(Math.random() * (r[1] - r[0] + 1))); }
    for (const e of def.extraDrops) if (Math.random() < e.chance) spawn(e.item, Array.isArray(e.count) ? e.count[0] + Math.floor(Math.random() * (e.count[1] - e.count[0] + 1)) : (e.count || 1));
    if (this.blueprints) for (const name of this.blueprints.rollDiscovery(def.name)) spawn(name, 1);
  }

  // วางบล็อกจากไอเทมที่ถืออยู่ใน Hotbar (ไอเทมที่ไม่ใช่บล็อกวางไม่ได้)
  place() {
    const t = this.target, stack = this.inv.selectedStack();
    if (t) {                                   // คลิกขวาที่ Work Bench = เปิดหน้า Crafting (ย่อตัวเพื่อวางบล็อกชิดแทน)
      const td = VX.Blocks.get(this.world.getBlock(t.x, t.y, t.z));
      if (td.benchTier && this.onStation && !this.input.crouch) { this.onStation(td); return; }
    }
    if (stack) {                                           // กินอาหารที่ถืออยู่ (ถ้ายังไม่อิ่ม)
      const f = VX.Items.get(stack.id).food;
      if (f && this.player.hunger < this.player.maxHunger) {
        this.player.eat(f); this.inv.takeFromSlot(this.inv.selected, 1);
        VX.sfx('eat'); if (this.fx) this.fx.view.swing(0.35);
        return;
      }
    }
    if (!t || !stack || (!t.nx && !t.ny && !t.nz)) return;
    const item = VX.Items.get(stack.id);
    if (!item.blockId) return;
    const x = t.x + t.nx, y = t.y + t.ny, z = t.z + t.nz;
    if (y < 0 || y >= VX.Config.CHUNK_HEIGHT) return;
    const g = this.world.getBlock(x, y, z);
    const gd = VX.Blocks.get(g);
    if (g !== 0 && !gd.liquid && !gd.replaceable) return;   // วางทับน้ำ/หินก้อนเล็กได้
    const def = VX.Blocks.get(item.blockId);
    if (def.solid && this.player.overlapsBlock(x, y, z)) return;
    this.world.setBlock(x, y, z, def.id);
    this.inv.takeFromSlot(this.inv.selected, 1);
    VX.sfx('place');
    if (this.fx) this.fx.view.swing(0.2);
  }

  dropSelected() {
    const s = this.inv.takeFromSlot(this.inv.selected, 1);
    if (s) this.dropStack(s);
  }
  // โยนไอเทมไปข้างหน้าผู้เล่น (หน่วงการเก็บ 1.5 วิ ไม่ให้ดูดกลับทันที)
  dropStack(stack) {
    const cam = this.camera, d = new THREE.Vector3();
    cam.getWorldDirection(d);
    const p = cam.position;
    this.items.spawn(stack.id, stack.count, p.x + d.x * 0.4, p.y - 0.3 + d.y * 0.4, p.z + d.z * 0.4,
      d.x * 4, d.y * 4 + 1.5, d.z * 4, 1.5, stack.dur);
  }
};
