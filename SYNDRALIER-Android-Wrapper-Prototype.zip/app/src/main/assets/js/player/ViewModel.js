// ViewModel : ของที่ถืออยู่มุมขวาล่างของจอ (บล็อก/ไอคอนเครื่องมือ/มือเปล่า) + แอนิเมชันฟัน ขุด วาง สลับของ เดิน
// ปรับท่าถือได้ที่ POSE ด้านล่าง
VX.ViewModel = class {
  constructor(scene, camera, inventory, items) {
    this.inv = inventory; this.items = items;
    this.root = new THREE.Group();
    camera.add(this.root); scene.add(camera);        // camera ต้องอยู่ใน scene เพื่อให้ลูกของมันถูกวาด
    this.curId = -1; this.holder = null; this.kind = 'hand';
    this.swingT = 0; this.swingDur = 0.3; this.equip = 0; this.t = 0;
    this.blockMat = new THREE.MeshBasicMaterial({ map: VX.TextureAtlas.texture, vertexColors: true, depthTest: false });
    VX.Lighting.patch(this.blockMat);
    this.armMat = new THREE.MeshBasicMaterial({ color: new THREE.Color('#c9956b'), depthTest: false });
    this.spriteMats = {};
    this.plane = new THREE.PlaneGeometry(0.5, 0.5);
    this.arm = new THREE.BoxGeometry(0.14, 0.14, 0.6);
  }

  static get POSE() {
    return {
      block: { p: [0.5, -0.46, -0.85], r: [0.2, -0.6, 0.0] },
      tool:  { p: [0.5, -0.4, -0.75], r: [0.3, -0.5, -0.45] },
      hand:  { p: [0.4, -0.42, -0.7], r: [0.35, 0.2, 0.0] }
    };
  }

  swing(dur) { this.swingDur = dur || 0.3; this.swingT = this.swingDur; }

  rebuild(stack) {
    if (this.holder) { this.root.remove(this.holder); this.holder = null; }
    let mesh;
    const it = stack && VX.Items.get(stack.id);
    if (!it) { mesh = new THREE.Mesh(this.arm, this.armMat); this.kind = 'hand'; }
    else if (it.blockId) {
      mesh = new THREE.Mesh(this.items.cubeGeo(VX.Blocks.get(it.blockId)), this.blockMat);
      mesh.scale.set(1.7, 1.7, 1.7); this.kind = 'block';
    } else {
      if (!this.spriteMats[it.id]) {
        const t = new THREE.CanvasTexture(VX.Icons.canvas(it.id));
        t.magFilter = t.minFilter = THREE.NearestFilter;
        this.spriteMats[it.id] = new THREE.MeshBasicMaterial({ map: t, transparent: true, alphaTest: 0.2, side: THREE.DoubleSide, depthTest: false });
      }
      mesh = new THREE.Mesh(this.plane, this.spriteMats[it.id]); this.kind = 'tool';
    }
    mesh.renderOrder = 1000;
    this.holder = mesh; this.root.add(mesh);
    this.curId = stack ? stack.id : 0;
    this.equip = 1;
  }

  // st = { moving, mining, dead }
  update(dt, st) {
    const stack = this.inv.selectedStack(), id = stack ? stack.id : 0;
    if (id !== this.curId) this.rebuild(stack);
    this.root.visible = !st.dead;
    this.t += dt;
    this.equip = Math.max(0, this.equip - dt / 0.25);
    if (this.swingT > 0) this.swingT = Math.max(0, this.swingT - dt);
    else if (st.mining) this.swing(0.35);                        // ขุดต่อเนื่อง = ฟันวนซ้ำ

    const P = VX.ViewModel.POSE[this.kind];
    const k = this.swingT > 0 ? 1 - this.swingT / this.swingDur : 0, a = this.swingT > 0 ? Math.sin(k * Math.PI) : 0;
    const bob = st.moving ? 1 : 0;
    this.root.position.set(P.p[0] + Math.cos(this.t * 5) * 0.008 * bob,
      P.p[1] + Math.sin(this.t * 10) * 0.012 * bob + a * 0.06 - this.equip * 0.45, P.p[2] - a * 0.18);
    this.root.rotation.set(P.r[0] - a * 1.25, P.r[1] + a * 0.3, P.r[2] + a * 0.6);

    const b = 0.25 + 0.75 * ((VX.Lighting.uDay.value - 0.12) / 0.88);     // มืดลงตอนกลางคืน
    this.armMat.color.setScalar(b);
    for (const id2 in this.spriteMats) this.spriteMats[id2].color.setScalar(b);
  }
};
