// Input Layer : รวมคีย์บอร์ด / เมาส์ (Pointer Events) / จอยสติ๊กและปุ่มบนมือถือ ให้ Player อ่านจากที่เดียว
// - เกมอ่านปุ่มผ่าน "คำสั่ง" (VX.Bindings) ไม่ผูกกับ click/keycode ตรง ๆ
// - เมาส์: Mouse0/1/2 มาจาก pointerdown/pointerup ของปุ่มนั้น ๆ โดยตรงเท่านั้น (ไม่มี history/popstate/Back เกี่ยวข้อง)
// - กล้องหมุนจาก movementX/movementY ของเมาส์เท่านั้น (ไม่เคยคำนวณจากตำแหน่ง cursor)
// - ไม่มี Pointer Lock -> โหมดเมาส์อิสระ: ใช้ movement จริงเหมือนกัน เมาส์หยุด = กล้องหยุด
const BUTTON_BIT = [1, 4, 2, 8, 16];          // ลำดับ e.button (ซ้าย,กลาง,ขวา,ข้าง1,ข้าง2) -> บิตใน e.buttons
VX.Input = class {
  constructor(canvas) {
    this.canvas = canvas;
    this.isTouch = ('ontouchstart' in window) || navigator.maxTouchPoints > 0;
    this.mode = this.isTouch ? 'touch' : 'mouse';           // อุปกรณ์ชี้ที่ใช้อยู่ตอนนี้
    this.keys = {}; this.mouse = {};
    this.stick = { x: 0, y: 0 };      // จาก MobileControls (y บวก = เดินหน้า)
    this.touchJump = false; this.touchCrouch = false; this.sprintToggle = false; this.touchBreak = false;
    this.onSprintChange = null;
    this.lookX = 0; this.lookY = 0;   // สะสมเป็นเรเดียนระหว่างเฟรม
    this.placeQueued = false;
    this.freeLook = false;            // true = ไม่มี pointer lock ใช้โหมดเมาส์อิสระ
    this.dbgText = '-'; this.lockErr = '';
    this.guardDepth = 0; this._hs = 0; this.backCount = 0; this.onBackSwallowed = null;
    this.onSelect = null; this.onCycle = null; this.onDrop = null; this.onInventory = null; this.onCraft = null; this.onPause = null;
    // ตะขอที่ main.js/Overlay กำหนดให้
    this.canPlay = () => false;       // กำลังเล่นอยู่จริง (ไม่พัก ไม่เปิดกระเป๋า/คราฟต์)
    this.guardActive = () => false;   // อยู่ในเกมแล้ว -> ดักเหตุการณ์ของระบบ (เมนูคลิกขวา ปุ่มข้าง ฯลฯ)
    this.onEscape = null; this.onModeChange = null; this.onMouseDown = null;

    const isField = (t) => !!(t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT' || t.isContentEditable));
    const inUI = (t) => !!(t && t.closest && t.closest('#overlay, input, select, textarea, button, label'));
    const locked = () => document.pointerLockElement === canvas;

    // ---- คีย์บอร์ด ----
    window.addEventListener('keydown', (e) => {
      if (isField(e.target) || VX.Bindings.capturing) return;                   // พิมพ์ชื่อโลก/seed ได้ตามปกติ
      const code = VX.Bindings.normalize(e);
      this.keys[code] = true;
      this.topUpGuard();
      if (this.guardActive() && (VX.Bindings.actionsFor(code).length || /^Digit[1-9]$/.test(code))) e.preventDefault();
      if (e.repeat) return;
      this.dbgText = 'key ' + code;
      if (/^Digit[1-9]$/.test(code) && this.onSelect) this.onSelect(+code.slice(5) - 1);
      if (code === 'Escape' && this.freeLook && this.onEscape) this.onEscape();
      for (const a of VX.Bindings.actionsFor(code)) this.fire(a);
    });
    window.addEventListener('keyup', (e) => { this.keys[VX.Bindings.normalize(e)] = false; });
    window.addEventListener('blur', () => this.releaseAll());

    // ---- เมาส์/ปากกา/นิ้ว ผ่าน Pointer Events ----
    document.addEventListener('pointerdown', (e) => {
      if (e.pointerType === 'touch') { this.setMode('touch'); this.topUpGuard(); return; }
      if (e.pointerType !== 'mouse') return;
      this.setMode('mouse');
      this.dbgText = 'mouse down b' + e.button + ' buttons=' + e.buttons;
      if (e.button === 0) this.topUpGuard();                  // เติมประวัติกันออกเฉพาะคลิกซ้าย/คีย์/นิ้ว — คลิกขวาไม่แตะ history
      VX.InputLog.add('pointerdown mouse b' + e.button + ' buttons=' + e.buttons + ' target=' + ((e.target && e.target.tagName) || '?'));
      const onGame = locked() || e.target === canvas || e.target === document.body;
      if (this.guardActive() && !inUI(e.target)) e.preventDefault();             // กันเมนูระบบ/ปุ่มข้าง/ลากรูป
      if (!onGame) return;                                                       // คลิกบนปุ่ม/เมนู ไม่นับเป็นการกระทำในเกม
      // Android wrapper: ask the native View to capture the mouse after a real in-game click.
      // This supplies relative movement even when the physical cursor reaches a screen edge.
      if (window.SyndralierNative && this.guardActive() && !inUI(e.target)) {
        try { window.SyndralierNative.requestCapture(); } catch (_) { /* wrapper optional */ }
      }
      this.mouse[e.button] = true;
      for (const a of VX.Bindings.actionsFor('Mouse' + e.button)) if (a !== 'attack') this.fire(a);
      if (this.onMouseDown) this.onMouseDown(e);
    }, true);
    const up = (e) => { if (e.pointerType === 'mouse') { this.mouse[e.button] = false; this.dbgText = 'mouse up b' + e.button; VX.InputLog.add('pointerup mouse b' + e.button); } };
    document.addEventListener('pointerup', up, true);
    document.addEventListener('pointercancel', (e) => { if (e.pointerType === 'mouse') this.mouse = {}; }, true);
    document.addEventListener('pointermove', (e) => {
      if (e.pointerType !== 'mouse') return;
      this.setMode('mouse');
      if (typeof e.buttons === 'number') {                   // กันสถานะค้าง : ถ้าระบบบอกว่าปุ่มนั้นไม่ได้กดอยู่แล้ว (เช่นปล่อยนอกหน้าต่าง) ให้เคลียร์ทันที
        for (const b in this.mouse) if (this.mouse[b] && !(e.buttons & BUTTON_BIT[b])) this.mouse[b] = false;
      }
      if (!this.canPlay() || !(locked() || this.freeLook)) return;
      if (this.freeLook && this.isDown('clutch')) return;       // ค้างปุ่ม clutch = ย้ายเมาส์กลับกลางจอโดยกล้องไม่หมุน (ใช้เมื่อไม่มี Pointer Lock แล้วเมาส์ชนขอบจอ)
      this.addLook((e.movementX || 0) * VX.Config.LOOK_SENS_MOUSE, (e.movementY || 0) * VX.Config.LOOK_SENS_MOUSE);
    }, true);
    // เมนูคลิกขวา / auxclick (กลาง, ปุ่มข้าง) / ลากรูป : ปิดระหว่างเล่น เพื่อไม่ให้ Android/WebView ตีความเป็นคำสั่งระบบ
    for (const type of ['contextmenu', 'auxclick', 'dragstart'])
      document.addEventListener(type, (e) => {
        const block = this.guardActive() && !isField(e.target);
        if (type !== 'dragstart') VX.InputLog.add(type + ' b' + e.button + (block ? ' (blocked)' : ' (allowed)'));
        if (block) e.preventDefault();
      }, true);
    document.addEventListener('wheel', (e) => {
      if (!this.guardActive() || !this.canPlay()) return;
      if (this.onCycle) this.onCycle(e.deltaY > 0 ? 1 : -1);
      e.preventDefault();
    }, { passive: false });

    // Android native mouse bridge. The wrapper calls these with relative deltas and physical button states.
    // Native mouse buttons are handled here only while the wrapper has captured the pointer.
    window.__syndralierNativeMouseMove = (dx, dy) => {
      if (!this.canPlay() || !Number.isFinite(dx) || !Number.isFinite(dy)) return;
      this.setMode('mouse');
      if (this.freeLook && this.isDown('clutch')) return;
      this.addLook(dx * VX.Config.LOOK_SENS_MOUSE, dy * VX.Config.LOOK_SENS_MOUSE);
    };
    window.__syndralierNativeMouseButton = (button, down) => {
      if (!Number.isInteger(button) || button < 0 || button > 4) return;
      this.setMode('mouse');
      if (down) {
        this.mouse[button] = true;
        for (const a of VX.Bindings.actionsFor('Mouse' + button)) if (a !== 'attack') this.fire(a);
      } else {
        this.mouse[button] = false;
      }
      this.dbgText = 'native mouse ' + (down ? 'down' : 'up') + ' b' + button;
    };
    window.__syndralierNativeKey = (code, down) => {
      if (typeof code !== 'string') return;
      this.keys[code] = !!down;
      if (down && code === 'Escape' && !this.keys.__escapeHandled) {
        this.keys.__escapeHandled = true;
        if (this.freeLook && this.onEscape) this.onEscape();
        else if (this.canPlay() && this.onPause) this.onPause();
      }
      if (!down) delete this.keys.__escapeHandled;
      if (down) {
        if (/^Digit[1-9]$/.test(code) && this.onSelect) this.onSelect(+code.slice(5) - 1);
        for (const a of VX.Bindings.actionsFor(code)) this.fire(a);
      }
    };

    // ---- บันทึกเหตุการณ์ระดับระบบ (ใช้ไล่หาสาเหตุที่เกมหลุด) ----
    VX.InputLog.add('start touch=' + this.isTouch + ' PointerEvent=' + (typeof PointerEvent !== 'undefined') + ' lockApi=' + !!canvas.requestPointerLock + ' ua=' + ((navigator.userAgent || '').slice(0, 70)));
    for (const t of ['pagehide', 'pageshow', 'blur', 'focus', 'online']) window.addEventListener(t, () => VX.InputLog.add('window ' + t));
    document.addEventListener('visibilitychange', () => VX.InputLog.add('visibility=' + document.visibilityState));
    document.addEventListener('freeze', () => VX.InputLog.add('page freeze'));
    document.addEventListener('pointerlockchange', () => VX.InputLog.add('pointerlockchange locked=' + locked()));
    document.addEventListener('pointerlockerror', () => VX.InputLog.add('pointerlockerror'));
    window.addEventListener('beforeunload', (e) => {
      VX.InputLog.add('beforeunload');
      // ถ้าประวัติหลอกหมดและ Back พาออกจากหน้า : ให้เบราว์เซอร์ถามก่อน (ปุ่ม "บันทึกและออก" ปิดตัวนี้เองด้วย __vxLeaving)
      if (this.backGuardOn() && this.guardActive() && !window.__vxLeaving) { e.preventDefault(); e.returnValue = ''; }
    });
  }

  // ---- ปุ่ม Back ของระบบ (Android) : "กันไม่ให้ออกจากหน้า" อย่างเดียว ไม่เกี่ยวกับปุ่มเมาส์ ----
  // Mouse2 ยังมาจาก pointerdown ของปุ่ม 2 โดยตรงเท่านั้น — popstate ไม่สร้างคำสั่งใด ๆ ทั้งสิ้น
  // เติมประวัติหลอกเฉพาะตอนมี user gesture (กด/แตะ/พิมพ์) เพราะ Chrome ข้ามประวัติที่เพิ่มโดยไม่มี gesture
  backGuardOn() { return !!(VX.Settings && VX.Settings.get && VX.Settings.get('backGuard')); }
  armBackGuard() {
    if (!this.backGuardOn()) return;
    if (!this._backArmed) { this._backArmed = true; window.addEventListener('popstate', () => this.onBackPressed()); }
    this.topUpGuard();
  }
  topUpGuard() {
    if (!this._backArmed || !this.backGuardOn() || !this.guardActive()) return;
    try { while (this.guardDepth < 10) { history.pushState({ vx: ++this._hs }, '', location.href); this.guardDepth++; } } catch (e) { /* ignore */ }
  }
  onBackPressed() {
    this.backCount++;
    this.guardDepth = Math.max(0, this.guardDepth - 1);
    this.dbgText = 'BACK swallowed (no action)';
    VX.InputLog.add('popstate: system Back swallowed, guard depth=' + this.guardDepth);
    if (this.onBackSwallowed) this.onBackSwallowed();
  }

  // ---- โหมดอุปกรณ์ชี้ ----
  setMode(m) {
    if (this.mode === m) return;
    this.mode = m;
    if (this.isTouch) document.body.classList.toggle('mouse-mode', m === 'mouse');     // เมาส์จริงบนมือถือ : ซ่อนจอยสติ๊ก/โซนลาก
    if (this.onModeChange) this.onModeChange(m);
  }

  fire(a) {
    if (a === 'place') { if (this.canPlay()) this.placeQueued = true; }
    else if (a === 'inventory') { if (this.onInventory) this.onInventory(); }
    else if (a === 'craft') { if (this.onCraft) this.onCraft(); }
    else if (a === 'drop') { if (this.canPlay() && this.onDrop) this.onDrop(); }
  }

  releaseAll() { this.keys = {}; this.mouse = {}; }

  isDown(a) {
    for (const c of VX.Bindings.get(a)) {
      if (!c) continue;
      if (c.indexOf('Mouse') === 0) { if (this.mouse[+c.slice(5)]) return true; } else if (this.keys[c]) return true;
    }
    return false;
  }

  addLook(dx, dy) { this.lookX += dx; this.lookY += dy; }
  consumeLook() { const r = { x: this.lookX, y: this.lookY }; this.lookX = this.lookY = 0; return r; }

  get breaking() { return this.isDown('attack') || this.touchBreak; }
  consumePlace() { const p = this.placeQueued; this.placeQueued = false; return p; }

  get jump() { return this.isDown('jump') || this.touchJump; }
  get crouch() { return this.isDown('crouch') || this.touchCrouch; }
  get sprint() { return this.isDown('sprint') || this.sprintToggle; }

  stopSprint() {
    if (this.sprintToggle) { this.sprintToggle = false; if (this.onSprintChange) this.onSprintChange(false); }
  }

  // คืนค่า {x: ขวา, y: หน้า} ขนาดไม่เกิน 1
  getMove() {
    let x = (this.isDown('right') ? 1 : 0) - (this.isDown('left') ? 1 : 0) + this.stick.x;
    let y = (this.isDown('forward') ? 1 : 0) - (this.isDown('back') ? 1 : 0) + this.stick.y;
    const len = Math.hypot(x, y);
    if (len < 0.12) return { x: 0, y: 0 };    // deadzone
    if (len > 1) { x /= len; y /= len; }
    return { x, y };
  }

  debugLine() {
    return 'input ' + this.mode + (this.freeLook ? ' free-look' : '') + ' lock=' + (document.pointerLockElement === this.canvas ? 'yes' : 'no') +
      ' lockApi=' + (this.canvas.requestPointerLock ? 'yes' : 'no') + (this.lockErr ? ' err=' + this.lockErr : '') +
      ' back=' + this.backCount + '/' + this.guardDepth + ' | ' + this.dbgText;
  }
};
