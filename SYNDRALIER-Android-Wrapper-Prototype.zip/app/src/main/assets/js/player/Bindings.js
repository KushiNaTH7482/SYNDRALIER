// Bindings : ตารางปุ่มควบคุม (คีย์บอร์ด + ปุ่มเมาส์) ตั้งค่าใหม่ได้ เก็บใน localStorage
// ชื่อปุ่ม: คีย์บอร์ดใช้ KeyboardEvent.code เช่น 'KeyW' 'Space' | เมาส์ใช้ 'Mouse'+เลขปุ่มตามมาตรฐานเบราว์เซอร์
//   0 = ซ้าย, 1 = กลาง, 2 = ขวา, 3/4 = ปุ่มข้าง (ย้อนกลับ/ไปข้างหน้า)
VX.Bindings = (function () {
  const KEY = 'vx:keys';
  const ACTIONS = [
    { id: 'forward', label: 'เดินหน้า', def: ['KeyW'] },
    { id: 'back', label: 'เดินถอยหลัง', def: ['KeyS'] },
    { id: 'left', label: 'เดินซ้าย', def: ['KeyA'] },
    { id: 'right', label: 'เดินขวา', def: ['KeyD'] },
    { id: 'jump', label: 'กระโดด / ว่ายขึ้น', def: ['Space'] },
    { id: 'sprint', label: 'วิ่ง', def: ['ControlLeft'] },
    { id: 'crouch', label: 'ย่อตัว', def: ['ShiftLeft'] },
    { id: 'attack', label: 'ขุด / โจมตี (กดค้างได้)', def: ['Mouse0'] },
    { id: 'place', label: 'วาง / ใช้ / กิน', def: ['Mouse2'] },
    { id: 'inventory', label: 'กระเป๋า', def: ['KeyE'] },
    { id: 'craft', label: 'คราฟต์', def: ['KeyC'] },
    { id: 'drop', label: 'ทิ้งไอเทม', def: ['KeyQ'] },
    { id: 'clutch', label: 'ค้างไว้ = ย้ายเมาส์โดยกล้องไม่หมุน (โหมดไม่มี Pointer Lock)', def: ['KeyZ'] }
  ];
  const RESERVED = /^(Escape|Digit[1-9])$/;                 // Esc = พัก, 1-9 = เลือกช่อง Hotbar (แก้ไม่ได้)
  const VALID = /^(Key[A-Z]|Digit\d|Numpad\w+|Arrow\w+|Space|Tab|Enter|Backspace|Delete|Insert|Home|End|PageUp|PageDown|Backquote|Minus|Equal|Bracket\w+|Backslash|Semicolon|Quote|Comma|Period|Slash|(Shift|Control|Alt)(Left|Right)|F\d{1,2}|Mouse[0-9])$/;

  let map = {};
  const defaults = () => { const m = {}; for (const a of ACTIONS) m[a.id] = [a.def[0] || '', a.def[1] || '']; return m; };
  const persist = () => { try { localStorage.setItem(KEY, JSON.stringify(map)); } catch (e) { /* ไม่มี localStorage ก็ใช้ได้แค่ในเซสชันนี้ */ } };

  function load() {
    map = defaults();
    try {
      const s = JSON.parse(localStorage.getItem(KEY) || 'null');
      if (s) for (const a of ACTIONS) {
        const v = s[a.id];
        if (Array.isArray(v) && v.length === 2 && v.every((x) => x === '' || (typeof x === 'string' && VALID.test(x) && !RESERVED.test(x))) && (v[0] || v[1])) map[a.id] = [v[0], v[1]];
      }
    } catch (e) { /* ใช้ค่าเริ่มต้น */ }
    // ปุ่มซ้ำกันข้ามคำสั่ง (ข้อมูลเสีย) -> กลับค่าเริ่มต้น
    const seen = new Set();
    for (const a of ACTIONS) for (const c of map[a.id]) if (c) { if (seen.has(c)) { map = defaults(); return; } seen.add(c); }
  }

  const NAMES = { Space: 'Space', ControlLeft: 'Ctrl ซ้าย', ControlRight: 'Ctrl ขวา', ShiftLeft: 'Shift ซ้าย', ShiftRight: 'Shift ขวา', AltLeft: 'Alt ซ้าย', AltRight: 'Alt ขวา',
    Mouse0: 'คลิกซ้าย', Mouse1: 'คลิกกลาง', Mouse2: 'คลิกขวา', Mouse3: 'ปุ่มข้าง 1', Mouse4: 'ปุ่มข้าง 2', Backquote: '`', Minus: '-', Equal: '=' };
  function label(code) {
    if (!code) return '—';
    if (NAMES[code]) return NAMES[code];
    return code.replace(/^Key/, '').replace(/^Digit/, '').replace(/^Arrow/, '↔ ').replace(/^Numpad/, 'Num ');
  }

  // ชื่อปุ่มจาก KeyboardEvent (เผื่อ Android/IME ที่ส่ง code ว่างหรือ 'Unidentified')
  function normalize(e) {
    if (e.code && e.code !== 'Unidentified') return e.code;
    const k = e.key || '';
    if (k.length === 1) {
      if (/[a-z]/i.test(k)) return 'Key' + k.toUpperCase();
      if (/[0-9]/.test(k)) return 'Digit' + k;
      if (k === ' ') return 'Space';
    }
    return { Shift: 'ShiftLeft', Control: 'ControlLeft', Alt: 'AltLeft', Escape: 'Escape', Enter: 'Enter', Tab: 'Tab', Backspace: 'Backspace',
      ArrowUp: 'ArrowUp', ArrowDown: 'ArrowDown', ArrowLeft: 'ArrowLeft', ArrowRight: 'ArrowRight' }[k] || k;
  }

  load();
  return {
    ACTIONS, capturing: false, label, normalize, load,
    get(a) { return map[a].slice(); },
    has(a, code) { return !!code && map[a].indexOf(code) >= 0; },
    actionsFor(code) { return ACTIONS.filter((a) => map[a.id].indexOf(code) >= 0).map((a) => a.id); },
    // ผูกปุ่ม : ถ้าปุ่มนี้ใช้กับคำสั่งอื่นอยู่ จะถูกย้ายมา (คำสั่งเดิมที่เสียปุ่มจนว่างจะได้ปุ่มเดิมของช่องนี้แทน)
    bind(a, slot, code) {
      if (!map[a] || !VALID.test(code) || RESERVED.test(code)) return { ok: false, reason: 'reserved' };
      const old = map[a][slot], moved = [];
      for (const o of ACTIONS) if (o.id !== a) for (let i = 0; i < 2; i++) if (map[o.id][i] === code) {
        map[o.id][i] = '';
        if (!map[o.id][0] && !map[o.id][1]) map[o.id][0] = old || o.def[0];        // ห้ามเหลือคำสั่งที่ไม่มีปุ่ม
        moved.push(o.id);
      }
      if (map[a][1 - slot] === code) map[a][1 - slot] = '';
      map[a][slot] = code;
      if (!map[a][0]) { map[a][0] = map[a][1]; map[a][1] = ''; }
      persist();
      return { ok: true, moved };
    },
    clear(a, slot) {
      if (!map[a] || !map[a][1 - slot]) return false;                         // ต้องเหลืออย่างน้อย 1 ปุ่ม
      map[a][slot] = '';
      if (!map[a][0]) { map[a][0] = map[a][1]; map[a][1] = ''; }
      persist();
      return true;
    },
    reset() { map = defaults(); persist(); }
  };
})();
