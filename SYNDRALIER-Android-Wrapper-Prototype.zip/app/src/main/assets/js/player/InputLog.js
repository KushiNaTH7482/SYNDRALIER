// InputLog : บันทึกเหตุการณ์ Input/ระบบ ล่าสุด เก็บลง localStorage ทุกครั้งที่เกิดเหตุการณ์ (รอดแม้เกมถูกปิดกะทันหัน)
// เปิดอ่านได้ที่ ตั้งค่า > บันทึกเหตุการณ์ Input — ใช้ไล่หาสาเหตุเวลาเกมเด้งออก (เช่นคลิกขวาแล้วหลุด)
VX.InputLog = (function () {
  const KEY = 'vx:inlog', PREV = 'vx:inlog.prev', MAX = 70;
  let lines = [];
  const t0 = (typeof performance !== 'undefined') ? performance.now() : 0;
  try { const old = localStorage.getItem(KEY); if (old) localStorage.setItem(PREV, old); } catch (e) { /* ไม่มี localStorage */ }
  function save() { try { localStorage.setItem(KEY, JSON.stringify(lines)); } catch (e) { /* ignore */ } }
  return {
    add(msg) {
      lines.push('+' + ((performance.now() - t0) / 1000).toFixed(1) + 's ' + msg);
      if (lines.length > MAX) lines.shift();
      save();
    },
    current() { return lines.slice(); },
    previous() { try { return JSON.parse(localStorage.getItem(PREV) || '[]'); } catch (e) { return []; } }
  };
})();
