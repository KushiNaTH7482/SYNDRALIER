// Player : first-person controller (เดิน วิ่ง กระโดด ย่อ แรงโน้มถ่วง และ collision แบบ AABB)
VX.Player = class {
  constructor(world, camera, input) {
    this.world = world; this.camera = camera; this.input = input;
    this.P = VX.Config.PLAYER;
    this.pos = new THREE.Vector3();
    this.vel = new THREE.Vector3();
    this.yaw = 0; this.pitch = 0;
    this.onGround = false;
    this.crouching = false;
    this.sprinting = false;
    this.swimming = false; this.hitWall = false;
    this.maxHealth = 20; this.health = 20;
    this.invuln = 0; this.kbTime = 0; this.sinceHurt = 0; this.regenT = 0;
    this.dead = false; this.deadT = 0;
    this.maxHunger = 20; this.hunger = 20; this.sat = 5; this.exhaust = 0; this.starveT = 0;
    this.onDeath = null; this.onHurt = null;
    this.height = this.P.HEIGHT;
    this.eye = this.P.EYE;
    this.spawnPoint = { x: 0, y: 20, z: 0 };
    camera.rotation.order = 'YXZ';
  }

  addExhaust(n) { this.exhaust += n; }
  eat(food) {
    this.hunger = Math.min(this.maxHunger, this.hunger + food.hunger);
    this.sat = Math.min(this.hunger, this.sat + food.sat);
  }
  // ระบบหิว : พลังงานที่ใช้ทำให้ saturation แล้ว hunger ลด | อิ่ม (>=18) ฟื้นเลือด | หิวสุด เสียเลือดทีละ 1 (เหลือ 1 ไม่ตาย)
  tickSurvival(dt) {
    this.sinceHurt += dt;
    if (this.exhaust >= 4) {
      this.exhaust -= 4;
      if (this.sat > 0) this.sat = Math.max(0, this.sat - 1); else this.hunger = Math.max(0, this.hunger - 1);
    }
    if (this.hunger >= 18 && this.health < this.maxHealth) {
      this.regenT += dt; this.starveT = 0;
      if (this.regenT >= 4) { this.regenT = 0; this.health = Math.min(this.maxHealth, this.health + 1); this.exhaust += 0.6; }
    } else if (this.hunger <= 0) {
      this.starveT += dt; this.regenT = 0;
      if (this.starveT >= 4) {
        this.starveT = 0;
        if (this.health > 1) { this.health -= 1; this.sinceHurt = 0; if (this.onHurt) this.onHurt(1); }
      }
    } else { this.regenT = 0; this.starveT = 0; }
  }

  // รับความเสียหาย : from = ตำแหน่งต้นทาง (ใช้คำนวณแรงกระเด็น) คืน true ถ้าโดนจริง
  damage(amount, from) {
    if (this.dead || this.invuln > 0) return false;
    this.health = Math.max(0, this.health - amount);
    this.invuln = 0.6; this.sinceHurt = 0; this.regenT = 0;
    if (from) {
      const dx = this.pos.x - from.x, dz = this.pos.z - from.z, d = Math.hypot(dx, dz) || 1;
      this.vel.x = dx / d * 6; this.vel.z = dz / d * 6; this.vel.y = Math.max(this.vel.y, 4.5);
      this.onGround = false; this.kbTime = 0.25;
    }
    if (this.onHurt) this.onHurt(amount);
    if (this.health <= 0) { this.dead = true; this.deadT = 0; if (this.onDeath) this.onDeath(this.pos); }
    return true;
  }
  respawn() {
    this.dead = false; this.health = this.maxHealth; this.invuln = 2; this.sinceHurt = 0;
    this.hunger = this.maxHunger; this.sat = 5; this.exhaust = 0; this.starveT = 0;
    this.spawn(this.spawnPoint);
    this.camera.rotation.z = 0;
  }

  spawn(p) {
    this.spawnPoint = p;
    this.pos.set(p.x, p.y, p.z);
    this.vel.set(0, 0, 0);
  }

  // บล็อกที่ (bx,by,bz) ทับกล่องผู้เล่นอยู่หรือไม่
  overlapsBlock(bx, by, bz) {
    const hw = this.P.WIDTH / 2, p = this.pos;
    return p.x - hw < bx + 1 && p.x + hw > bx &&
           p.y < by + 1 && p.y + this.height > by &&
           p.z - hw < bz + 1 && p.z + hw > bz;
  }

  // กล่องของผู้เล่นชนกับบล็อกแข็งหรือไม่
  collides(px, py, pz, h) {
    const hw = this.P.WIDTH / 2, e = 1e-4;
    const x0 = Math.floor(px - hw + e), x1 = Math.floor(px + hw - e);
    const y0 = Math.floor(py + e), y1 = Math.floor(py + h - e);
    const z0 = Math.floor(pz - hw + e), z1 = Math.floor(pz + hw - e);
    for (let y = y0; y <= y1; y++) for (let z = z0; z <= z1; z++) for (let x = x0; x <= x1; x++)
      if (this.world.isSolid(x, y, z)) return true;
    return false;
  }

  // เลื่อนทีละแกน ถ้าชนให้ดันกลับไปชิดผิวบล็อก
  moveAxis(axis, d) {
    if (d === 0) return;
    const p = this.pos, hw = this.P.WIDTH / 2, h = this.height, e = 1e-4;
    const old = p[axis];
    p[axis] += d;
    if (!this.collides(p.x, p.y, p.z, h)) {
      // ย่อตัวอยู่บนพื้น: ห้ามเดินตกขอบ
      if (axis !== 'y' && this.crouching && this.onGround && !this.collides(p.x, p.y - 0.6, p.z, h)) {
        p[axis] = old; this.vel[axis] = 0;
      }
      return;
    }
    if (axis === 'y') {
      if (d < 0) { p.y = Math.floor(p.y) + 1; this.onGround = true; }
      else p.y = Math.floor(p.y + h) - h - e;
      this.vel.y = 0;
    } else if (d > 0) {
      p[axis] = Math.floor(p[axis] + hw) - hw - e; this.vel[axis] = 0; this.hitWall = true;
    } else {
      p[axis] = Math.floor(p[axis] - hw) + 1 + hw + e; this.vel[axis] = 0; this.hitWall = true;
    }
  }

  update(dt) {
    const P = this.P, inp = this.input;
    dt = Math.min(dt, 0.1);
    this.invuln = Math.max(0, this.invuln - dt);

    if (this.dead) {                                   // ตาย : รอ 2 วินาทีแล้วเกิดใหม่ที่จุดเกิด
      this.deadT += dt;
      inp.consumeLook();
      this.camera.position.set(this.pos.x, this.pos.y + 0.4, this.pos.z);
      this.camera.rotation.set(this.pitch, this.yaw, 0.9);
      if (this.deadT > 2) this.respawn();
      return false;
    }
    this.tickSurvival(dt);

    // กล้อง
    const l = inp.consumeLook();
    this.yaw -= l.x;
    this.pitch -= l.y;
    const lim = Math.PI / 2 - 0.01;
    this.pitch = Math.max(-lim, Math.min(lim, this.pitch));
    if (!this.world.isLoadedAt(this.pos.x, this.pos.z)) dt = 0;   // รอ chunk โหลดก่อนจึงเริ่มตก

    // ย่อตัว (ลุกได้เมื่อไม่มีบล็อกขวางหัว)
    if (inp.crouch && !this.crouching) { this.crouching = true; this.height = P.CROUCH_HEIGHT; }
    else if (!inp.crouch && this.crouching && !this.collides(this.pos.x, this.pos.y, this.pos.z, P.HEIGHT)) {
      this.crouching = false; this.height = P.HEIGHT;
    }

    // ว่ายน้ำ : ตรวจที่กลางลำตัว
    this.swimming = VX.Blocks.get(this.world.getBlock(this.pos.x, this.pos.y + 0.5, this.pos.z)).liquid;

    const wall = this.hitWall; this.hitWall = false;           // ชนผนังเฟรมก่อนหน้าหรือไม่ (ใช้ตอนปีนขึ้นจากน้ำ)

    // ทิศการเดิน
    const mv = inp.getMove();
    const moving = Math.hypot(mv.x, mv.y) > 0;
    if (!(mv.y > 0.1)) inp.stopSprint();
    this.sprinting = inp.sprint && mv.y > 0.1 && !this.crouching && this.hunger > 6;   // หิวมากวิ่งไม่ได้
    const speed = (this.crouching ? P.CROUCH : this.sprinting ? P.SPRINT : P.WALK) * (this.swimming ? 0.6 : 1);
    const sy = Math.sin(this.yaw), cy = Math.cos(this.yaw);
    const tx = (cy * mv.x - sy * mv.y) * speed;
    const tz = (-sy * mv.x - cy * mv.y) * speed;

    if (this.kbTime > 0) {                             // แรงกระเด็น : ไม่ให้ปุ่มเดินหักล้างทันที
      this.kbTime -= dt;
      const f = Math.max(0, 1 - 3 * dt); this.vel.x *= f; this.vel.z *= f;
    } else {
      const acc = (this.onGround ? 60 : 20) * dt;
      this.vel.x += Math.max(-acc, Math.min(acc, tx - this.vel.x));
      this.vel.z += Math.max(-acc, Math.min(acc, tz - this.vel.z));
    }

    // ปีนขึ้นจากน้ำ : ใกล้ผิวน้ำ + ดันชิดขอบฝั่ง + กดกระโดด -> ดีดตัวขึ้นข้ามขอบสูง 1 บล็อก
    if (this.swimming && inp.jump && wall && !VX.Blocks.get(this.world.getBlock(this.pos.x, this.pos.y + 1.2, this.pos.z)).liquid) {
      this.vel.y = Math.max(this.vel.y, 10); this.exhaust += 0.05;
    }
    if (inp.jump && this.onGround && !this.swimming) { this.vel.y = P.JUMP; this.onGround = false; this.exhaust += this.sprinting ? 0.2 : 0.05; }

    const px0 = this.pos.x, pz0 = this.pos.z;
    // physics แบ่ง step ย่อย กันทะลุบล็อก
    const steps = Math.max(1, Math.ceil(dt / (1 / 60)));
    const sdt = dt / steps;
    for (let i = 0; i < steps; i++) {
      if (this.swimming) {
        this.vel.y -= 8 * sdt;
        this.vel.y *= Math.max(0, 1 - 3 * sdt);
        if (inp.jump) this.vel.y += 20 * sdt;
      } else {
        this.vel.y = Math.max(-P.MAX_FALL, this.vel.y - P.GRAVITY * sdt);
      }
      this.onGround = false;
      this.moveAxis('x', this.vel.x * sdt);
      this.moveAxis('z', this.vel.z * sdt);
      this.moveAxis('y', this.vel.y * sdt);
    }


    const moved = Math.hypot(this.pos.x - px0, this.pos.z - pz0);      // ใช้พลังงานตามระยะทางที่เคลื่อนที่จริง
    if (this.sprinting) this.exhaust += 0.1 * moved; else if (this.swimming) this.exhaust += 0.01 * moved;

    // ตำแหน่งตา (ปรับความสูงนุ่ม ๆ ตอนย่อ/ลุก)
    const eyeT = this.crouching ? P.CROUCH_EYE : P.EYE;
    this.eye += (eyeT - this.eye) * Math.min(1, dt * 15);
    this.camera.position.set(this.pos.x, this.pos.y + this.eye, this.pos.z);
    this.camera.rotation.set(this.pitch, this.yaw, 0);
    return moving;
  }
};
