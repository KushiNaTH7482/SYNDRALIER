// Mob : เอนทิตีมอน (physics + collision AABB + สุขภาพ + State Machine)
VX.Mob = class {
  constructor(mgr, type, x, y, z) {
    this.mgr = mgr; this.type = type; this.world = mgr.world;
    this.w = type.size[0]; this.h = type.size[1];
    this.pos = new THREE.Vector3(x, y, z);
    this.vel = new THREE.Vector3();
    this.wish = { x: 0, z: 0 };
    this.yaw = Math.random() * Math.PI * 2; this.desiredYaw = this.yaw;
    this.health = type.health;
    this.onGround = false; this.blocked = false;
    this.age = 0; this.cool = 1; this.aggro = 0; this.hurtT = 0; this.invuln = 0; this.flash = 0;
    this.dead = false; this.remove = false; this.deathT = 0;
    this.anim = 0; this.bar = null; this.barT = 0;
    this.model = VX.MobModels.build(type);
    mgr.scene.add(this.model.group);
    this.sm = new VX.StateMachine(this, 'idle');
  }

  // ---- ตัวช่วยสำหรับ AI ----
  stop() { this.wish.x = this.wish.z = 0; }
  face(x, z) { this.desiredYaw = Math.atan2(x - this.pos.x, z - this.pos.z); }
  walkToward(x, z, speed) {
    const dx = x - this.pos.x, dz = z - this.pos.z, d = Math.hypot(dx, dz);
    if (d < 0.05) { this.stop(); return; }
    this.wish.x = dx / d * speed; this.wish.z = dz / d * speed;
    this.desiredYaw = Math.atan2(dx, dz);
  }
  walkAway(x, z, speed) { this.walkToward(this.pos.x * 2 - x, this.pos.z * 2 - z, speed); }
  distToPlayer() {
    const p = this.mgr.player.pos;
    return Math.hypot(p.x - this.pos.x, p.y + 0.9 - (this.pos.y + this.h * 0.5), p.z - this.pos.z);
  }
  lineOfSight() {
    const p = this.mgr.player.pos, w = this.world;
    const ox = this.pos.x, oy = this.pos.y + this.h * 0.85, oz = this.pos.z;
    const dx = p.x - ox, dy = p.y + 1.4 - oy, dz = p.z - oz, d = Math.hypot(dx, dy, dz), n = Math.ceil(d / 0.5);
    for (let i = 1; i < n; i++) if (w.isSolid(ox + dx * i / n, oy + dy * i / n, oz + dz * i / n)) return false;
    return true;
  }
  sees() {                                          // Detect player
    const ai = this.type.ai, p = this.mgr.player;
    if (!ai.detect || p.dead) return false;
    const r = ai.detect * (p.crouching ? 0.6 : 1);   // ย่องอยู่ ศัตรูเห็นได้ใกล้ขึ้น
    return this.distToPlayer() <= r && this.lineOfSight();
  }
  attackState() { return this.type.ai.ranged ? 'ranged' : 'chase'; }
  tryDetect() {
    if (!this.sees()) return false;
    this.aggro = 14;
    this.sm.set(this.attackState());
    return true;
  }
  safeAhead(dx, dz) {                               // ข้างหน้าไม่ใช่หน้าผาลึก/น้ำ
    const x = this.pos.x + dx * (this.w / 2 + 0.8), z = this.pos.z + dz * (this.w / 2 + 0.8), yf = Math.floor(this.pos.y);
    if (VX.Blocks.get(this.world.getBlock(x, yf, z)).liquid) return false;
    for (let k = 1; k <= 3; k++) if (this.world.isSolid(x, yf - k, z)) return !VX.Blocks.get(this.world.getBlock(x, yf - k + 1, z)).liquid;
    return false;
  }

  // ---- Take damage / Knockback / Death ----
  damage(amount, from, knock) {
    if (this.dead || this.invuln > 0) return false;
    this.health -= amount; this.invuln = 0.35; this.flash = 0.25;
    this.showBar();
    VX.sfx('mobHurt', { pos: this.pos, pitch: 1.5 - this.h * 0.35 });
    const dx = this.pos.x - from.x, dz = this.pos.z - from.z, d = Math.hypot(dx, dz) || 1, k = knock === undefined ? 6 : knock;
    this.vel.x = dx / d * k; this.vel.z = dz / d * k; this.vel.y = 4.5; this.onGround = false;
    if (this.health <= 0) { this.die(); return true; }
    if (this.type.hostility === 'neutral') this.aggro = 14;
    this.sm.set('hurt');
    return true;
  }
  die() {
    this.dead = true; this.health = 0;
    this.drawBar();
    VX.sfx('mobDeath', { pos: this.pos, pitch: 1.5 - this.h * 0.35 });
    this.sm.set('dead');
    const it = this.mgr.items;
    for (const d of this.type.drops || []) {
      if (Math.random() > d.chance) continue;
      const n = d.min + Math.floor(Math.random() * (d.max - d.min + 1)), item = VX.Items.byName(d.item);
      if (n > 0 && it) it.spawn(item.id, n, this.pos.x, this.pos.y + this.h * 0.6, this.pos.z,
        (Math.random() - 0.5) * 2, 3, (Math.random() - 0.5) * 2, 0.5, 0);
    }
    if (this.mgr.onDeath) this.mgr.onDeath(this);
  }

  // แถบเลือดเหนือหัว (แสดง 3 วินาทีหลังถูกตี)
  showBar() {
    if (!this.bar) {
      const c = document.createElement('canvas'); c.width = 64; c.height = 8;
      this.barCtx = c.getContext('2d');
      this.barTex = new THREE.CanvasTexture(c);
      this.barTex.magFilter = this.barTex.minFilter = THREE.NearestFilter;
      this.bar = new THREE.Sprite(new THREE.SpriteMaterial({ map: this.barTex, transparent: true, depthWrite: false }));
      this.bar.scale.set(0.9, 0.11, 1);
      this.mgr.scene.add(this.bar);
    }
    this.drawBar(); this.barT = 3;
  }
  drawBar() {
    if (!this.bar) return;
    const r = Math.max(0, this.health / this.type.health), g = this.barCtx;
    g.fillStyle = '#111'; g.fillRect(0, 0, 64, 8);
    g.fillStyle = r > 0.35 ? '#46c846' : '#e03a3a'; g.fillRect(1, 1, 62 * r, 6);
    this.barTex.needsUpdate = true;
  }

  // ---- physics ----
  collides(px, py, pz) {
    const hw = this.w / 2, e = 1e-4;
    const x0 = Math.floor(px - hw + e), x1 = Math.floor(px + hw - e), z0 = Math.floor(pz - hw + e), z1 = Math.floor(pz + hw - e);
    const y0 = Math.floor(py + e), y1 = Math.floor(py + this.h - e);
    for (let y = y0; y <= y1; y++) for (let z = z0; z <= z1; z++) for (let x = x0; x <= x1; x++)
      if (this.world.isSolid(x, y, z)) return true;
    return false;
  }
  moveAxis(axis, d) {
    if (!d) return;
    const p = this.pos, hw = this.w / 2, e = 1e-4;
    p[axis] += d;
    if (!this.collides(p.x, p.y, p.z)) return;
    if (axis === 'y') {
      if (d < 0) { p.y = Math.floor(p.y) + 1; this.onGround = true; } else p.y = Math.floor(p.y + this.h) - this.h - e;
      this.vel.y = 0;
    } else {
      p[axis] = d > 0 ? Math.floor(p[axis] + hw) - hw - e : Math.floor(p[axis] - hw) + 1 + hw + e;
      this.vel[axis] = 0; this.blocked = true;
    }
  }

  update(dt) {
    dt = Math.min(dt, 0.1);
    this.age += dt;
    this.cool = Math.max(0, this.cool - dt);
    this.invuln = Math.max(0, this.invuln - dt);
    this.hurtT = Math.max(0, this.hurtT - dt);
    this.aggro = Math.max(0, this.aggro - dt);
    this.flash = Math.max(0, this.flash - dt);
    if (!this.world.isLoadedAt(this.pos.x, this.pos.z)) return;      // chunk ยังไม่โหลด : หยุดนิ่ง

    this.wish.x = this.wish.z = 0;
    this.sm.update(dt);

    const inWater = VX.Blocks.get(this.world.getBlock(this.pos.x, this.pos.y + this.h * 0.4, this.pos.z)).liquid;
    if (this.hurtT > 0 || this.dead) {                               // แรงกระเด็น : ลดความเร็วลงเอง
      const f = Math.max(0, 1 - (this.onGround ? 6 : 1) * dt); this.vel.x *= f; this.vel.z *= f;
    } else {
      const acc = (this.onGround ? 40 : 8) * dt;
      this.vel.x += Math.max(-acc, Math.min(acc, this.wish.x - this.vel.x));
      this.vel.z += Math.max(-acc, Math.min(acc, this.wish.z - this.vel.z));
    }
    if (this.blocked && this.onGround && !this.dead && (this.wish.x || this.wish.z)) this.vel.y = 8.4;   // กระโดดข้ามบล็อก 1 ชั้น
    this.blocked = false;

    const steps = Math.max(1, Math.ceil(dt / (1 / 60))), sdt = dt / steps;
    for (let i = 0; i < steps; i++) {
      if (inWater) { this.vel.y += (2 - this.vel.y) * Math.min(1, 4 * sdt); }
      else this.vel.y = Math.max(-40, this.vel.y - 28 * sdt);
      this.onGround = false;
      this.moveAxis('x', this.vel.x * sdt);
      this.moveAxis('z', this.vel.z * sdt);
      this.moveAxis('y', this.vel.y * sdt);
    }

    // หมุนตัวนุ่ม ๆ
    let dy = this.desiredYaw - this.yaw;
    dy = Math.atan2(Math.sin(dy), Math.cos(dy));
    this.yaw += dy * Math.min(1, dt * 10);

    // โมเดล
    const sp = Math.hypot(this.vel.x, this.vel.z);
    this.anim += sp * dt * 4.5;
    const g = this.model.group;
    g.position.copy(this.pos);
    g.rotation.y = this.yaw;
    this.model.animate(sp, this.anim, this);
    if (this.sm.name === 'attack') {                                 // แอนิเมชันโจมตี : พุ่งเข้าหา + ยกแขน
      const ai = this.type.ai, k = Math.min(1, this.sm.time / (ai.windup + 0.35)), s = Math.sin(k * Math.PI);
      g.position.x += Math.sin(this.yaw) * s * 0.3; g.position.z += Math.cos(this.yaw) * s * 0.3;
      if (this.model.arms && this.type.model.armsForward) for (const a of this.model.arms) a.rotation.x = -1.35 - s * 0.9;
    }
    if (this._charge > 0 && this.model.arms) for (const a of this.model.arms) a.rotation.x = -1.5;     // ท่าเล็ง : ยกแขนเห็นชัดว่ากำลังจะยิง
    if (this.bar) {
      this.barT -= dt;
      this.bar.visible = this.barT > 0 && !this.dead;
      this.bar.position.set(this.pos.x, this.pos.y + this.h + 0.35, this.pos.z);
    }
    g.rotation.z = this.dead ? Math.min(1, this.deathT / 0.4) * Math.PI / 2 : 0;
    const f = this.flash > 0;
    if (f !== this._flash) { this._flash = f; VX.MobModels.setHurt(this.model, f); }
  }

  dispose() {
    this.mgr.scene.remove(this.model.group);
    if (this.bar) { this.mgr.scene.remove(this.bar); this.barTex.dispose(); this.bar.material.dispose(); }
  }
};
