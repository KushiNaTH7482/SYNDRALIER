// MobModels : สร้างโมเดลบล็อกให้มอน (ขา/แขนแกว่งตามความเร็ว) ไม่ใช้ asset ภายนอก
// ใช้ vertex color (shade,1,0) + Lighting.patch เพื่อให้มืด/สว่างตามเวลาเหมือนโลก
VX.MobModels = (function () {
  const mats = {}, geos = {};
  let hurtMat = null;
  const SHADE = [0.6, 0.6, 1, 0.5, 0.8, 0.8];

  function mat(color) {
    if (!mats[color]) { mats[color] = new THREE.MeshBasicMaterial({ color: new THREE.Color(color), vertexColors: true }); VX.Lighting.patch(mats[color]); }
    return mats[color];
  }
  function hurt() {
    if (!hurtMat) { hurtMat = new THREE.MeshBasicMaterial({ color: new THREE.Color('#ff3b3b'), vertexColors: true }); VX.Lighting.patch(hurtMat); }
    return hurtMat;
  }
  function geo(w, h, l, pivotTop) {
    const k = [w, h, l, pivotTop].join();
    if (geos[k]) return geos[k];
    const g = new THREE.BoxGeometry(w, h, l);
    if (pivotTop) g.translate(0, -h / 2, 0);
    const c = new Float32Array(g.attributes.position.count * 3);
    for (let f = 0; f < 6; f++) for (let v = 0; v < 4; v++) { const i = (f * 4 + v) * 3; c[i] = SHADE[f]; c[i + 1] = 1; c[i + 2] = 0; }
    g.setAttribute('color', new THREE.BufferAttribute(c, 3));
    return (geos[k] = g);
  }
  function part(model, w, h, l, color, x, y, z, pivotTop) {
    const m = new THREE.Mesh(geo(w, h, l, pivotTop), mat(color));
    m.position.set(x, y, z);
    m.userData.mat = m.material;
    model.group.add(m); model.parts.push(m);
    return m;
  }

  const builders = {
    quad(s) {
      const M = { group: new THREE.Group(), parts: [], legs: [] }, c = s.colors;
      const by = s.legH + s.body[1] / 2;
      part(M, s.body[0], s.body[1], s.body[2], c.body, 0, by, 0);
      const hy = s.legH + s.body[1] * 0.8, hz = s.body[2] / 2 + s.head[2] / 2 - 0.05;
      part(M, s.head[0], s.head[1], s.head[2], c.head, 0, hy, hz);
      for (const sx of [-1, 1]) part(M, 0.07, 0.07, 0.03, c.eye, sx * s.head[0] * 0.25, hy + s.head[1] * 0.1, hz + s.head[2] / 2 + 0.01);
      for (const [sx, sz] of [[-1, 1], [1, -1], [1, 1], [-1, -1]])        // ขาหน้า-หลังสลับกัน
        M.legs.push(part(M, s.legW, s.legH, s.legW, c.leg, sx * (s.body[0] / 2 - s.legW / 2), s.legH, sz * (s.body[2] / 2 - s.legW / 2), true));
      for (const e of s.extras || []) part(M, e[0], e[1], e[2], e[3], e[4], e[5], e[6]);
      M.animate = (speed, t) => { const a = Math.min(1, speed / 2) * 0.8; M.legs.forEach((l, i) => { l.rotation.x = Math.sin(t + (i % 2 ? Math.PI : 0)) * a; }); };
      return M;
    },
    humanoid(s) {
      const M = { group: new THREE.Group(), parts: [], legs: [], arms: [] }, c = s.colors;
      part(M, 0.5, 0.5, 0.5, c.skin, 0, 1.55, 0);
      for (const sx of [-1, 1]) part(M, 0.08, 0.08, 0.03, c.eye, sx * 0.12, 1.58, 0.26);
      part(M, 0.5, 0.7, 0.28, c.shirt, 0, 0.95, 0);
      for (const sx of [-1, 1]) {
        M.arms.push(part(M, 0.2, 0.7, 0.2, c.skin, sx * 0.35, 1.3, 0, true));
        M.legs.push(part(M, 0.24, 0.6, 0.24, c.pants, sx * 0.13, 0.6, 0, true));
      }
      M.animate = (speed, t) => {
        const a = Math.min(1, speed / 2) * 0.9;
        M.legs[0].rotation.x = Math.sin(t) * a; M.legs[1].rotation.x = -Math.sin(t) * a;
        if (s.armsForward) { M.arms[0].rotation.x = M.arms[1].rotation.x = -1.35 + Math.sin(t * 0.5) * 0.06; }
        else { M.arms[0].rotation.x = -Math.sin(t) * a * 0.8; M.arms[1].rotation.x = Math.sin(t) * a * 0.8; }
      };
      return M;
    }
  };

  return {
    build(type) {
      const b = builders[type.model.kind];
      if (!b) throw new Error('Unknown model kind ' + type.model.kind);
      return b(type.model);
    },
    setHurt(model, on) { for (const m of model.parts) m.material = on ? hurt() : m.userData.mat; },
    register(kind, fn) { builders[kind] = fn; }
  };
})();
