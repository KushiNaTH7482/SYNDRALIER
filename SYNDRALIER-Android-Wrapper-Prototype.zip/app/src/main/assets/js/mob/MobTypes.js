// MobTypes : ข้อมูลมอนสเตอร์ทั้งหมด (ข้อมูลล้วน) เพิ่มมอนใหม่ = register() อีกอัน
//   hostility: passive | neutral | hostile
//   spawn: { biomes, time: 'day'|'night'|'any', caves, group:[min,max], weight }
VX.MobTypes = (function () {
  const types = new Map();
  function register(t) {
    if (types.has(t.id)) throw new Error('Duplicate mob ' + t.id);
    for (const d of t.drops || []) if (!VX.Items.byName(d.item)) throw new Error('Mob ' + t.id + ': unknown drop ' + d.item);
    for (const k of ['idle', 'wander', 'hurt', 'dead', t.ai.onHurt]) if (k && !VX.AI.states[k]) throw new Error('Mob ' + t.id + ': unknown state ' + k);
    types.set(t.id, t);
    return t;
  }
  const all = () => Array.from(types.values());

  // สัตว์ใจเย็น : วิ่งหนีเมื่อถูกทำร้าย
  register({
    id: 'hopper', label: 'Hopper', hostility: 'passive', health: 6, size: [0.45, 0.55], speed: 1.4,
    model: { kind: 'quad', body: [0.34, 0.3, 0.5], head: [0.28, 0.26, 0.28], legW: 0.1, legH: 0.2,
      colors: { body: '#b9916a', head: '#c9a37b', leg: '#a07c55', eye: '#222222' },
      extras: [[0.07, 0.24, 0.05, '#b9916a', -0.08, 0.72, 0.18], [0.07, 0.24, 0.05, '#b9916a', 0.08, 0.72, 0.18],
               [0.12, 0.12, 0.1, '#f2f2f2', 0, 0.38, -0.3]] },
    ai: { onHurt: 'flee', fleeSpeed: 3.6 },
    drops: [{ item: 'hide', min: 1, max: 1, chance: 1 }, { item: 'meat', min: 1, max: 2, chance: 1 }],
    spawn: { biomes: ['plains', 'forest', 'snow'], time: 'day', group: [2, 4], weight: 5 }
  });

  // สัตว์เป็นกลาง : ไม่ทำร้ายใครจนกว่าจะถูกตี แล้วไล่กัด
  register({
    id: 'tusker', label: 'Tusker', hostility: 'neutral', health: 14, size: [0.9, 1.0], speed: 1.3,
    model: { kind: 'quad', body: [0.7, 0.62, 1.0], head: [0.5, 0.5, 0.5], legW: 0.2, legH: 0.38,
      colors: { body: '#6b4a3a', head: '#7a5644', leg: '#4d3328', eye: '#111111' },
      extras: [[0.07, 0.07, 0.22, '#f5f0dc', -0.17, 0.5, 0.72], [0.07, 0.07, 0.22, '#f5f0dc', 0.17, 0.5, 0.72]] },
    ai: { onHurt: 'chase', chaseSpeed: 3.8, range: 1.6, windup: 0.35, cooldown: 1.1, damage: 3, lose: 22 },
    drops: [{ item: 'hide', min: 1, max: 2, chance: 1 }, { item: 'meat', min: 1, max: 3, chance: 1 }],
    spawn: { biomes: ['plains', 'forest', 'mountains'], time: 'day', group: [1, 2], weight: 3 }
  });

  // ศัตรูระยะประชิด : ซอมบี้
  register({
    id: 'rotwalker', label: 'Rotwalker', hostility: 'hostile', health: 20, size: [0.6, 1.8], speed: 1.2,
    model: { kind: 'humanoid', armsForward: true,
      colors: { skin: '#5f8f4b', shirt: '#3b5f8a', pants: '#3a3a6e', eye: '#1a1a1a' } },
    ai: { detect: 16, lose: 28, chaseSpeed: 3.2, range: 1.5, windup: 0.4, cooldown: 1.2, damage: 3, onHurt: 'chase' },
    drops: [{ item: 'bone', min: 0, max: 1, chance: 0.5 }, { item: 'fiber', min: 1, max: 2, chance: 0.6 }],
    spawn: { biomes: ['plains', 'forest', 'desert', 'snow', 'mountains'], time: 'night', caves: true, group: [1, 3], weight: 5 }
  });

  // ศัตรูระยะไกล : ยิงกระสุนและรักษาระยะ
  register({
    id: 'slinger', label: 'Bone Slinger', hostility: 'hostile', health: 14, size: [0.6, 1.8], speed: 1.1,
    model: { kind: 'humanoid', armsForward: false,
      colors: { skin: '#d8d4c0', shirt: '#cfcbb6', pants: '#9d9985', eye: '#c02020' } },
    ai: { detect: 20, lose: 30, ranged: true, minRange: 6, maxRange: 14, chaseSpeed: 2.8, retreatSpeed: 2.0, aimTime: 0.8, cooldown: 2.0,
          projectileDamage: 2.5, projectileSpeed: 12, onHurt: 'ranged' },
    drops: [{ item: 'bone', min: 1, max: 2, chance: 1 }, { item: 'stick', min: 0, max: 2, chance: 0.6 }],
    spawn: { biomes: ['plains', 'forest', 'desert', 'snow', 'mountains'], time: 'night', caves: true, group: [1, 2], weight: 3 }
  });

  return { register, get: (id) => types.get(id), all };
})();
