// MobManager : spawn/despawn, อัปเดตมอนทั้งหมด, กระสุน, raycast หามอนที่ผู้เล่นเล็ง
// กฎเกิด : สัตว์ (passive/neutral) เกิดตอนกลางวันตาม biome | ศัตรูเกิดบนพื้นดินเฉพาะกลางคืน และในถ้ำได้ทุกเวลา
VX.MobManager = class {
  constructor(scene, world, player, items, dayNight) {
    this.scene = scene; this.world = world; this.player = player; this.items = items; this.dn = dayNight;
    this.mobs = []; this.projectiles = [];
    this.spawnT = 0; this.onDeath = null;
    const C = VX.Config;
    this.baseCap = C.MOB_CAP_DESKTOP;              // main.js ปรับเป็น MOB_CAP_MOBILE บนมือถือ
    this.pGeo = new THREE.BoxGeometry(0.14, 0.14, 0.14);
    this.pMat = new THREE.MeshBasicMaterial({ color: new THREE.Color('#e8e4d0') });
  }

  get cap() { return Math.max(2, Math.round(this.baseCap * VX.Config.MOB_DENSITY)); }    // จำนวนมอนสูงสุด ตามตัวเลือก "จำนวนมอน"

  count(h) { let n = 0; for (const m of this.mobs) if (!m.dead && (!h || m.type.hostility === h)) n++; return n; }

  spawnMob(type, x, y, z) {
    const m = new VX.Mob(this, type, x, y, z);
    this.mobs.push(m);
    return m;
  }

  // ---- Spawning ----
  eligible(biome, cave) {
    const night = this.dn.isNight, out = [];
    for (const t of VX.MobTypes.all()) {
      const s = t.spawn;
      if (cave) { if (!s.caves) continue; }
      else {
        if (!s.biomes.includes(biome)) continue;
        if (s.time === 'day' && night) continue;
        if (s.time === 'night' && !night) continue;
      }
      const cap = t.hostility === 'hostile' ? Math.ceil(this.cap * 0.6) : Math.ceil(this.cap * 0.7);
      if (this.count(t.hostility) >= cap) continue;
      out.push(t);
    }
    return out;
  }
  pick(list) {
    let sum = 0; for (const t of list) sum += t.spawn.weight;
    let r = Math.random() * sum;
    for (const t of list) { r -= t.spawn.weight; if (r <= 0) return t; }
    return list[list.length - 1];
  }
  freeAt(x, y, z, type) {                       // ที่ยืนว่างพอสำหรับมอนตัวนี้
    const w = this.world, cells = Math.ceil(type.size[1]);
    if (!w.isSolid(x, y - 1, z) || VX.Blocks.get(w.getBlock(x, y - 1, z)).liquid) return false;
    for (let k = 0; k < cells; k++) { const b = w.getBlock(x, y + k, z); if (b !== 0 && !VX.Blocks.get(b).replaceable) return false; }     // หญ้า/หินก้อนเล็กไม่ขวางการเกิด
    return true;
  }
  trySpawn() {
    if (this.count() >= this.cap) return;
    const p = this.player.pos, C = VX.Config, w = this.world;
    const ed = C.ENTITY_DISTANCE, dmin = Math.min(C.MOB_SPAWN_MIN, ed * 0.7), dmax = Math.max(dmin + 4, Math.min(C.MOB_SPAWN_MAX, ed * 1.2));
    const a = Math.random() * Math.PI * 2, d = dmin + Math.random() * (dmax - dmin);
    const x = Math.floor(p.x + Math.cos(a) * d), z = Math.floor(p.z + Math.sin(a) * d);
    if (!w.isLoadedAt(x, z)) return;
    const h = w.skyHeight(x, z), biome = w.gen.columnInfo(x, z).biome;

    let list, y;
    if (Math.random() < 0.3 && h > 14) {                                  // ถ้ำ/ใต้ดิน
      y = 4 + Math.floor(Math.random() * (h - 9));
      if (w.skyExposed(x, y, z)) return;
      list = this.eligible(biome, true);
    } else {
      y = h;
      list = this.eligible(biome, false);
    }
    if (!list.length) return;
    const type = this.pick(list);
    if (!this.freeAt(x, y, z, type)) return;
    if (Math.abs(p.y - y) > 24) return;

    const g = type.spawn.group, n = g[0] + Math.floor(Math.random() * (g[1] - g[0] + 1));
    for (let i = 0; i < n; i++) {
      const gx = i ? x + Math.floor(Math.random() * 5) - 2 : x, gz = i ? z + Math.floor(Math.random() * 5) - 2 : z;
      let gy = y;
      if (i) { const hh = w.skyHeight(gx, gz); gy = Math.abs(hh - y) <= 2 ? hh : y; }
      if (this.freeAt(gx, gy, gz, type) && this.count() < this.cap) this.spawnMob(type, gx + 0.5, gy, gz + 0.5);
    }
  }

  // ---- Projectiles ----
  shoot(m) {
    const p = this.player.pos, G = 8, speed = m.type.ai.projectileSpeed || 15;
    const ox = m.pos.x, oy = m.pos.y + m.h * 0.85, oz = m.pos.z;
    const dx = p.x - ox, dy = p.y + 1.2 - oy, dz = p.z - oz, d = Math.hypot(dx, dz) || 1, t = Math.max(0.1, d / speed);
    VX.sfx('shoot', { pos: m.pos });
    const mesh = new THREE.Mesh(this.pGeo, this.pMat);
    this.scene.add(mesh);
    this.projectiles.push({
      mesh, pos: new THREE.Vector3(ox, oy, oz), age: 0, dmg: m.type.ai.projectileDamage,
      vel: new THREE.Vector3(dx / d * speed, (dy + 0.5 * G * t * t) / t, dz / d * speed), G
    });
  }
  updateProjectiles(dt) {
    const pl = this.player, w = this.world;
    for (let i = this.projectiles.length - 1; i >= 0; i--) {
      const q = this.projectiles[i];
      let dead = false;
      const steps = Math.ceil(dt / 0.04), sdt = dt / steps;
      for (let s = 0; s < steps && !dead; s++) {
        q.vel.y -= q.G * sdt;
        q.pos.x += q.vel.x * sdt; q.pos.y += q.vel.y * sdt; q.pos.z += q.vel.z * sdt;
        if (w.isSolid(q.pos.x, q.pos.y, q.pos.z)) dead = true;
        else if (!pl.dead && Math.abs(q.pos.x - pl.pos.x) < 0.45 && Math.abs(q.pos.z - pl.pos.z) < 0.45 &&
                 q.pos.y > pl.pos.y - 0.1 && q.pos.y < pl.pos.y + pl.height + 0.1) { pl.damage(q.dmg, q.pos); dead = true; }
      }
      q.age += dt;
      q.mesh.position.copy(q.pos);
      if (dead || q.age > 5) { this.scene.remove(q.mesh); this.projectiles.splice(i, 1); }
    }
  }

  // ---- ผู้เล่นเล็งมอน : ray vs AABB (slab test) คืน { mob, dist } ใกล้สุด ----
  raycast(o, d, max, margin) {
    const mg = margin || 0;
    let best = null;
    for (const m of this.mobs) {
      if (m.dead) continue;
      const hw = m.w / 2 + mg, mn = [m.pos.x - hw, m.pos.y - mg, m.pos.z - hw], mx = [m.pos.x + hw, m.pos.y + m.h + mg, m.pos.z + hw];
      const org = [o.x, o.y, o.z], dir = [d.x, d.y, d.z];
      let t0 = 0, t1 = max, ok = true;
      for (let a = 0; a < 3 && ok; a++) {
        if (Math.abs(dir[a]) < 1e-9) { if (org[a] < mn[a] || org[a] > mx[a]) ok = false; }
        else {
          let a0 = (mn[a] - org[a]) / dir[a], a1 = (mx[a] - org[a]) / dir[a];
          if (a0 > a1) { const t = a0; a0 = a1; a1 = t; }
          t0 = Math.max(t0, a0); t1 = Math.min(t1, a1);
          if (t0 > t1) ok = false;
        }
      }
      if (ok && (!best || t0 < best.dist)) best = { mob: m, dist: t0 };
    }
    return best;
  }

  update(dt) {
    const p = this.player.pos, C = VX.Config;
    for (let i = this.mobs.length - 1; i >= 0; i--) {
      const m = this.mobs[i], ed = C.ENTITY_DISTANCE;
      const d = Math.hypot(m.pos.x - p.x, m.pos.z - p.z);
      if (m.dead || d <= ed * 1.6) m.update(dt);                 // ไกลเกิน : หยุดคิด/เคลื่อนที่ เพื่อประหยัด CPU
      m.model.group.visible = d <= ed;                           // ไกลกว่าระยะแสดง : ไม่วาด
      if (d > ed && m.bar) m.bar.visible = false;
      let gone = m.remove || d > Math.max(40, ed * 2);
      if (!gone && !m.dead && m.type.hostility === 'hostile' && !this.dn.isNight && d > 14 &&      // เช้าแล้ว ศัตรูบนพื้นดินค่อย ๆ หายไป
          this.world.skyExposed(m.pos.x, m.pos.y + 1, m.pos.z) && Math.random() < dt * 0.15) gone = true;
      if (gone) { m.dispose(); this.mobs.splice(i, 1); }
    }
    this.updateProjectiles(dt);
    this.spawnT += dt;
    if (this.spawnT > 0.8) { this.spawnT = 0; for (let k = 0; k < 3; k++) this.trySpawn(); }
  }
};
