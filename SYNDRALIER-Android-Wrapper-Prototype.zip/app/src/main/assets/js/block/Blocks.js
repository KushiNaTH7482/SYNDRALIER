// Block Registry : เพิ่มบล็อกใหม่ด้วยการเรียก register() บรรทัดเดียว
// ฟิลด์เสริม: needsTool/minTier (ต้องใช้เครื่องมือถึงจะได้ของ), dropCount [min,max],
//            extraDrops [{item, chance, count}], benchTier (บล็อกนี้เป็น Work Bench ระดับใด)
VX.Blocks = (function () {
  const byId = [], byName = {};

  function register(def) {
    const b = Object.assign({
      id: 0, name: '', label: null, tex: null,
      hardness: 1, tool: null, needsTool: false, minTier: 0,
      drop: null, dropCount: [1, 1], extraDrops: [], benchTier: 0,
      shape: null, toolOnly: false,                      // shape 'cross' = พืชไขว้สองแผ่น | toolOnly = ต้องมีเครื่องมือที่ถูกชนิดเท่านั้นถึงจะตัดได้ (มือเปล่าไม่ทำลาย)
      box: null, replaceable: false, noItem: false,        // box = [x0,y0,z0,x1,y1,z1] บล็อกเล็กไม่เต็มช่อง, replaceable = วางบล็อกทับได้, noItem = ไม่มีไอเทมของตัวเอง
      solid: true, transparent: false, liquid: false, light: 0, sound: 'stone'
    }, def);
    if (byId[b.id]) throw new Error('Duplicate block id ' + b.id);
    if (b.tex) {
      const t = b.tex;
      b.faceUV = {
        top: VX.TextureAtlas.uv(t.top || t.side),
        side: VX.TextureAtlas.uv(t.side || t.top),
        bottom: VX.TextureAtlas.uv(t.bottom || t.side || t.top)
      };
    }
    byId[b.id] = b;
    byName[b.name] = b;
    return b;
  }

  register({ id: 0, name: 'air', solid: false, transparent: true });
  register({ id: 1, name: 'grass', tex: { top: 'grass_top', side: 'grass_side', bottom: 'dirt' }, hardness: 0.6, tool: 'shovel', drop: 'dirt',
            extraDrops: [], sound: 'grass' });
  register({ id: 2, name: 'dirt', tex: { side: 'dirt' }, hardness: 0.5, tool: 'shovel', drop: 'dirt', sound: 'gravel' });
  register({ id: 3, name: 'stone', tex: { side: 'stone' }, hardness: 1.5, tool: 'pickaxe', drop: 'stone_chunk', dropCount: [1, 2], sound: 'stone' });
  register({ id: 4, name: 'sand', tex: { side: 'sand' }, hardness: 0.5, tool: 'shovel', drop: 'sand', sound: 'sand' });
  register({ id: 5, name: 'wood', tex: { top: 'wood_top', side: 'wood_side' }, hardness: 2.0, tool: 'axe', drop: 'wood', sound: 'wood' });
  register({ id: 6, name: 'leaves', tex: { side: 'leaves' }, hardness: 0.2, transparent: true,
            extraDrops: [{ item: 'stick', chance: 0.6, count: [1, 2] }, { item: 'sapling', chance: 0.12 }], sound: 'grass' });
  register({ id: 7, name: 'gravel', tex: { side: 'gravel' }, hardness: 0.6, tool: 'shovel', drop: 'gravel', sound: 'gravel' });
  register({ id: 8, name: 'water', tex: { side: 'water' }, hardness: 100, solid: false, transparent: true, liquid: true, sound: 'water' });
  register({ id: 9, name: 'coal_ore', tex: { side: 'coal_ore' }, hardness: 3, tool: 'pickaxe', needsTool: true, minTier: 0, drop: 'coal', dropCount: [1, 3], sound: 'stone' });
  register({ id: 10, name: 'iron_ore', tex: { side: 'iron_ore' }, hardness: 3, tool: 'pickaxe', needsTool: true, minTier: 1, drop: 'iron', dropCount: [1, 2], sound: 'stone' });
  register({ id: 11, name: 'gold_ore', tex: { side: 'gold_ore' }, hardness: 3, tool: 'pickaxe', needsTool: true, minTier: 2, drop: 'gold', sound: 'stone' });
  register({ id: 12, name: 'diamond_ore', tex: { side: 'diamond_ore' }, hardness: 3, tool: 'pickaxe', needsTool: true, minTier: 3, drop: 'diamond', sound: 'stone' });
  register({ id: 13, name: 'snow', tex: { top: 'snow', side: 'snow_side', bottom: 'dirt' }, hardness: 0.2, tool: 'shovel', drop: 'snow', sound: 'snow' });
  register({ id: 14, name: 'cobblestone', tex: { side: 'cobblestone' }, hardness: 2, tool: 'pickaxe', needsTool: true, drop: 'cobblestone', sound: 'stone' });
  register({ id: 15, name: 'work_bench_1', label: 'Work Bench (Tier 1)', tex: { top: 'bench1_top', side: 'bench1_side', bottom: 'bench1_top' },
            hardness: 2, tool: 'axe', drop: 'work_bench_1', benchTier: 1, sound: 'wood' });
  register({ id: 16, name: 'work_bench_2', label: 'Work Bench (Tier 2)', tex: { top: 'bench2_top', side: 'bench2_side', bottom: 'bench2_top' },
            hardness: 2.5, tool: 'axe', drop: 'work_bench_2', benchTier: 2, sound: 'wood' });
  register({ id: 17, name: 'copper_ore', tex: { side: 'copper_ore' }, hardness: 3, tool: 'pickaxe', needsTool: true, minTier: 0, drop: 'copper', dropCount: [1, 2], sound: 'stone' });

  // หินก้อนเล็กบนพื้น : เดินทะลุได้ ใช้มือเปล่าเก็บได้ทันที ได้เศษหิน
  register({ id: 18, name: 'rock', label: 'Small Rock', tex: { side: 'stone' }, hardness: 0.1, solid: false, transparent: true,
             box: [0.32, 0, 0.32, 0.68, 0.2, 0.68], replaceable: true, noItem: true, drop: 'stone_chunk', dropCount: [1, 2], sound: 'stone' });

  // หญ้าตามพื้น 3 ชนิด (เดินทะลุได้) — กล่อง box ใช้สำหรับเล็ง/ไฮไลต์
  const plant = { solid: false, transparent: true, shape: 'cross', replaceable: true, noItem: true, sound: 'grass' };
  register(Object.assign({ id: 19, name: 'tuft', label: 'Grass Tuft', tex: { side: 'grass_tuft' }, hardness: 0.05, box: [0.12, 0, 0.12, 0.88, 0.6, 0.88], cross: 0.65 }, plant));
  register(Object.assign({ id: 20, name: 'fiber_grass', label: 'Fiber Grass', tex: { side: 'fiber_grass' }, hardness: 0.1, box: [0.12, 0, 0.12, 0.88, 0.8, 0.88], cross: 0.85,
    tool: 'knife', needsTool: true, toolOnly: true, drop: 'fiber', dropCount: [1, 2] }, plant));            // ต้องใช้มีดตัดเท่านั้นถึงจะได้ Fiber
  register(Object.assign({ id: 21, name: 'fern', label: 'Fern', tex: { side: 'fern' }, hardness: 0.05, box: [0.12, 0, 0.12, 0.88, 0.7, 0.88], cross: 0.75 }, plant));

  return {
    register,
    list: () => byId.filter((b) => b && b.id > 0 && !b.liquid),
    all: () => byId.filter((b) => b && b.id > 0),            // รวมน้ำด้วย (ใช้ส่งให้ Worker)
    get: (id) => byId[id] || byId[0],
    byName: (n) => byName[n],
    isSolid: (id) => (byId[id] || byId[0]).solid
  };
})();
