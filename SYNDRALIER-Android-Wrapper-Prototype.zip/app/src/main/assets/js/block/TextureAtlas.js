// สร้าง texture atlas แบบ procedural ด้วย canvas (ต้นฉบับ ไม่ใช้ไฟล์ภายนอก)
VX.TextureAtlas = (function () {
  const TILE = 16, COLS = 8;
  const names = ['grass_top', 'grass_side', 'dirt', 'stone', 'sand', 'wood_side', 'wood_top', 'leaves',
                 'gravel', 'water', 'coal_ore', 'iron_ore', 'gold_ore', 'diamond_ore', 'snow', 'snow_side', 'cobblestone',
                 'copper_ore', 'bench1_top', 'bench1_side', 'bench2_top', 'bench2_side',
                 'grass_tuft', 'fiber_grass', 'fern'];

  function rng(a) {
    return function () {
      a |= 0; a = a + 0x6D2B79F5 | 0;
      let t = Math.imul(a ^ a >>> 15, 1 | a);
      t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
      return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
  }
  function shade(c, r, v) { const d = (r() - 0.5) * v; return [c[0] + d, c[1] + d, c[2] + d]; }

  const GREEN = [90, 165, 62], DIRT = [121, 85, 58], STONE = [128, 128, 132], SNOW = [240, 244, 248];
  const SPOTS = [[3, 3], [10, 2], [6, 8], [12, 11], [2, 12], [9, 13]];
  function ore(color) {
    return (x, y, r) => {
      for (const s of SPOTS) if (x >= s[0] && x <= s[0] + 1 && y >= s[1] && y <= s[1] + 1) return shade(color, r, 16);
      return shade(STONE, r, 24);
    };
  }
  const painters = {
    grass_top: (x, y, r) => shade(GREEN, r, 22),
    grass_side: (x, y, r) => y < 4 ? shade(GREEN, r, 22) : shade(DIRT, r, 20),
    dirt: (x, y, r) => shade(DIRT, r, 20),
    stone: (x, y, r) => shade(STONE, r, 24),
    sand: (x, y, r) => shade([219, 207, 142], r, 12),
    wood_side: (x, y, r) => shade(x % 4 === 0 ? [86, 62, 40] : [104, 76, 46], r, 8),
    wood_top: (x, y, r) => {
      const ring = Math.floor(Math.max(Math.abs(x - 7.5), Math.abs(y - 7.5))) % 2;
      return shade(ring ? [150, 118, 60] : [122, 92, 52], r, 8);
    },
    leaves: (x, y, r) => shade(r() < 0.25 ? [34, 84, 30] : [56, 122, 44], r, 10),
    gravel: (x, y, r) => shade(r() < 0.35 ? [108, 104, 100] : [150, 146, 140], r, 14),
    water: (x, y, r) => shade([48, 98, 205], r, 10),
    coal_ore: ore([30, 30, 34]),
    iron_ore: ore([212, 168, 132]),
    gold_ore: ore([244, 208, 60]),
    diamond_ore: ore([80, 230, 230]),
    snow: (x, y, r) => shade(SNOW, r, 8),
    snow_side: (x, y, r) => y < 4 ? shade(SNOW, r, 8) : shade(DIRT, r, 20),
    cobblestone: (x, y, r) => { const l = (x % 8 === 0 || y % 8 === 0 || (x + 4) % 8 === 0 && y > 7); return shade(l ? [88, 88, 92] : [140, 140, 146], r, 22); },
    copper_ore: ore([217, 126, 70]),
    // พืชตัดขอบ : คืน null = พิกเซลโปร่งใส
    grass_tuft: (x, y, r) => {
      for (const [bx, h] of [[2, 9], [5, 13], [8, 10], [11, 14], [13, 8]])
        if (y >= 16 - h && (x === bx || (y > 12 && Math.abs(x - bx) === 1 && y > 16 - h * 0.6))) return shade(y < 16 - h + 2 ? [120, 190, 80] : [70, 140, 50], r, 20);
      return null;
    },
    fiber_grass: (x, y, r) => {
      for (const [bx, h] of [[2, 12], [4, 15], [6, 11], [8, 14], [10, 12], [12, 15], [14, 10]])
        if (y >= 16 - h && (x === bx || (y > 10 && x === bx + 1))) return shade(y < 16 - h + 3 ? [225, 225, 140] : [168, 188, 86], r, 18);
      return null;
    },
    fern: (x, y, r) => {
      const t = 15 - y;
      if (t < 13 && Math.abs(x - 7.5) <= 1 + t * 0.5 && (x + y) % 2 === 0) return shade(t > 9 ? [70, 150, 70] : [36, 100, 46], r, 16);
      return null;
    },
    bench1_top: (x, y, r) => y % 5 === 0 ? shade([96, 66, 36], r, 8) : shade([156, 116, 70], r, 12),
    bench1_side: (x, y, r) => (y < 3 || x < 2 || x > 13) ? shade([96, 66, 36], r, 8) : (y >= 7 && y <= 8) ? shade([112, 80, 46], r, 8) : shade([150, 110, 64], r, 10),
    bench2_top: (x, y, r) => y % 5 === 0 ? shade([66, 72, 88], r, 8) : shade([118, 128, 146], r, 12),
    bench2_side: (x, y, r) => (y < 3 || x < 2 || x > 13) ? shade([66, 72, 88], r, 8) : (y >= 7 && y <= 8) ? shade([90, 98, 116], r, 8) : shade([112, 122, 140], r, 10)
  };

  const canvas = document.createElement('canvas');
  canvas.width = canvas.height = TILE * COLS;
  const ctx = canvas.getContext('2d');
  const rand = rng(1337);
  names.forEach((n, i) => {
    const ox = (i % COLS) * TILE, oy = Math.floor(i / COLS) * TILE;
    for (let y = 0; y < TILE; y++) for (let x = 0; x < TILE; x++) {
      const c = painters[n](x, y, rand);
      if (!c) continue;                                  // โปร่งใส
      ctx.fillStyle = 'rgb(' + (c[0] | 0) + ',' + (c[1] | 0) + ',' + (c[2] | 0) + ')';
      ctx.fillRect(ox + x, oy + y, 1, 1);
    }
  });

  const texture = new THREE.CanvasTexture(canvas);
  texture.magFilter = THREE.NearestFilter;
  texture.minFilter = THREE.NearestFilter;
  texture.generateMipmaps = false;

  function uv(name) {
    const i = names.indexOf(name);
    if (i < 0) throw new Error('Unknown texture: ' + name);
    const e = 0.0005, s = 1 / COLS;
    const u0 = (i % COLS) * s, v1 = 1 - Math.floor(i / COLS) * s;
    return [u0 + e, v1 - s + e, u0 + s - e, v1 - e];
  }
  function rect(name) { const i = names.indexOf(name); return [(i % COLS) * TILE, Math.floor(i / COLS) * TILE]; }
  const avg = {};
  function avgColor(name) {                          // สีเฉลี่ยของ tile (ใช้กับอนุภาคตอนขุดบล็อก)
    if (avg[name]) return avg[name];
    const r = rect(name), d = ctx.getImageData(r[0], r[1], TILE, TILE).data;
    let R = 0, G = 0, B = 0;
    let cnt = 0;
    for (let i = 0; i < d.length; i += 4) { if (d[i + 3] === 0) continue; R += d[i]; G += d[i + 1]; B += d[i + 2]; cnt++; }
    const n = Math.max(1, cnt) * 255;
    return (avg[name] = [R / n, G / n, B / n]);
  }
  return { texture, uv, names, canvas, rect, TILE, avgColor };
})();
