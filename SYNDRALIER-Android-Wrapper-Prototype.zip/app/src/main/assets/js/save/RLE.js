// RLE : บีบอัดข้อมูล chunk (บล็อกส่วนใหญ่ซ้ำกันเป็นแถวยาว) เก็บเป็น [ค่า, จำนวนต่ำ, จำนวนสูง] ทีละชุด
VX.RLE = {
  encode(u8) {
    const out = [];
    let i = 0;
    while (i < u8.length) {
      const v = u8[i];
      let j = i + 1;
      while (j < u8.length && u8[j] === v && j - i < 65535) j++;
      const n = j - i;
      out.push(v, n & 255, n >> 8);
      i = j;
    }
    return Uint8Array.from(out);
  },
  decode(rle, len) {
    const out = new Uint8Array(len);
    let p = 0;
    for (let i = 0; i < rle.length; i += 3) {
      const n = rle[i + 1] | (rle[i + 2] << 8);
      if (p + n > len) throw new Error('RLE overflow');
      out.fill(rle[i], p, p + n);
      p += n;
    }
    if (p !== len) throw new Error('RLE length mismatch');
    return out;
  },
  toBase64(u8) {
    let s = '';
    for (let i = 0; i < u8.length; i += 8192) s += String.fromCharCode.apply(null, u8.subarray(i, i + 8192));
    return btoa(s);
  },
  fromBase64(str) {
    const s = atob(str), u8 = new Uint8Array(s.length);
    for (let i = 0; i < s.length; i++) u8[i] = s.charCodeAt(i);
    return u8;
  }
};
