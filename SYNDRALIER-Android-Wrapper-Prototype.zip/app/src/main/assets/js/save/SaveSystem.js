// SaveSystem : รวบรวมสถานะเกมเป็นข้อมูลเซฟ / นำกลับมาใช้ / จัดการรายการโลก
// หลักการ : บันทึกเฉพาะ chunk ที่ผู้เล่นแก้ไข (บีบอัด RLE) ส่วน chunk อื่นสร้างซ้ำจาก seed ได้เหมือนเดิมทุกครั้ง
VX.SaveSystem = class {
  constructor() { this.backend = null; this.saving = false; this.lastSaved = 0; this.lastError = null; }

  async init() { this.backend = await VX.Storage.open(); return this.backend; }
  newId() { return 'w' + Date.now().toString(36) + Math.floor(Math.random() * 1e6).toString(36); }

  async list() {
    const l = await this.backend.listWorlds();
    return l.filter(Boolean).sort((a, b) => (b.savedAt || b.created) - (a.savedAt || a.created));
  }
  async create(name, seed) {
    const meta = { id: this.newId(), name: name || 'โลกใหม่', seed, created: Date.now(), savedAt: 0, playTime: 0, day: 1, version: VX.SaveSystem.VERSION };
    await this.backend.putWorld(meta.id, { meta });
    return meta;
  }
  async remove(id) { await this.backend.deleteWorld(id); }

  // คืน { state, chunks: Map(key -> Uint8Array ที่คลายแล้ว) }
  async load(id) {
    const state = await this.backend.getWorld(id);
    if (!state) throw new Error('ไม่พบข้อมูลโลก');
    if ((state.meta.version || 1) > VX.SaveSystem.VERSION) throw new Error('เซฟนี้มาจากเกมเวอร์ชันใหม่กว่า');
    const len = VX.Config.CHUNK_SIZE * VX.Config.CHUNK_HEIGHT * VX.Config.CHUNK_SIZE, chunks = new Map();
    for (const e of await this.backend.getChunks(id)) {
      try { chunks.set(e.k, VX.RLE.decode(e.data, len)); } catch (err) { console.warn('ข้าม chunk ที่เสีย', e.k); }
    }
    return { state, chunks };
  }

  // game = { world, player, inventory, dn, crafting, blueprints, items, playTime }
  collect(game, meta) {
    const p = game.player, inv = game.inventory;
    const pack = (s) => s ? [s.id, s.count, s.dur || 0] : null;
    meta.savedAt = Date.now(); meta.day = game.dn.day; meta.playTime = Math.round(game.playTime || 0);
    meta.version = VX.SaveSystem.VERSION;
    return {
      meta,
      player: { x: p.pos.x, y: p.pos.y, z: p.pos.z, yaw: p.yaw, pitch: p.pitch, health: p.health, hunger: p.hunger, sat: p.sat,
                exhaust: p.exhaust, selected: inv.selected, spawn: { x: p.spawnPoint.x, y: p.spawnPoint.y, z: p.spawnPoint.z } },
      inv: { slots: inv.slots.map(pack), cursor: pack(inv.cursor) },
      time: game.dn.serialize(),
      crafting: game.crafting.serialize(),
      blueprints: game.blueprints.serialize(),
      ground: game.items.items.map((e) => ({ id: e.id, count: e.count, dur: e.dur, x: e.pos.x, y: e.pos.y, z: e.pos.z, age: e.age, life: e.life })),
      settings: { renderDistance: game.world.renderDistance }
    };
  }

  async save(game, meta) {
    if (this.saving) return { ok: false, reason: 'busy' };
    this.saving = true;
    const { entries, keys } = game.world.takeSaveChunks();
    try {
      const state = this.collect(game, meta);
      await this.backend.putChunks(meta.id, entries.map((e) => ({ k: e.k, data: VX.RLE.encode(e.data) })));   // chunk ก่อน แล้วค่อยบันทึกสถานะ
      await this.backend.putWorld(meta.id, state);
      this.lastSaved = Date.now(); this.lastError = null;
      return { ok: true, chunks: entries.length };
    } catch (e) {
      game.world.restoreSaveDirty(keys);             // เซฟไม่สำเร็จ : ให้รอบหน้าลองใหม่
      this.lastError = e;
      return { ok: false, reason: (e && e.message) || String(e) };
    } finally { this.saving = false; }
  }

  // นำสถานะที่บันทึกกลับเข้าเกม (เรียกหลังสร้าง game แล้ว และ player อยู่ใน chunk ที่โหลดแล้ว)
  restore(game, state) {
    const p = game.player, inv = game.inventory, S = state.player;
    const unpack = (a) => (a && VX.Items.get(a[0])) ? { id: a[0], count: a[1], dur: a[2] || 0 } : null;
    if (state.inv) {
      state.inv.slots.forEach((a, i) => { if (i < inv.size) inv.slots[i] = unpack(a); });
      inv.cursor = unpack(state.inv.cursor);
    }
    if (S) {
      inv.selected = Math.max(0, Math.min(8, S.selected | 0));
      p.hunger = S.hunger; p.sat = S.sat; p.exhaust = S.exhaust || 0;
      if (S.health > 0) p.health = Math.min(p.maxHealth, S.health);
      p.yaw = S.yaw || 0; p.pitch = S.pitch || 0;
    }
    inv.touch();
    if (state.crafting) game.crafting.deserialize(state.crafting);
    if (state.blueprints) game.blueprints.deserialize(state.blueprints);
    if (state.time) game.dn.deserialize(state.time);
    for (const g of state.ground || []) {
      if (!VX.Items.get(g.id)) continue;
      const e = game.items.spawn(g.id, g.count, g.x, g.y + 0.14, g.z, 0, 0, 0, 0, g.dur, g.life);
      if (e) e.age = g.age || 0;
    }
  }
};
VX.SaveSystem.VERSION = 1;
