// Storage : ที่เก็บข้อมูลเซฟ — ลอง IndexedDB ก่อน, ถ้าใช้ไม่ได้ใช้ localStorage, สุดท้ายใช้หน่วยความจำ (ไม่ถาวร)
// ทุก backend มี API เดียวกัน: listWorlds, getWorld, putWorld, putChunks, getChunks, deleteWorld
VX.Storage = (function () {
  const req = (r) => new Promise((res, rej) => { r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
  const done = (tx) => new Promise((res, rej) => {
    tx.oncomplete = () => res(); tx.onerror = () => rej(tx.error); tx.onabort = () => rej(tx.error || new Error('aborted'));
  });

  class IDBBackend {
    constructor(db) { this.db = db; this.kind = 'indexeddb'; this.persistent = true; }
    async listWorlds() { return (await req(this.db.transaction('worlds').objectStore('worlds').getAll())).map((w) => w.meta); }
    getWorld(id) { return req(this.db.transaction('worlds').objectStore('worlds').get(id)); }
    async putWorld(id, state) { const tx = this.db.transaction('worlds', 'readwrite'); tx.objectStore('worlds').put(state); await done(tx); }
    async putChunks(id, entries) {
      if (!entries.length) return;
      const tx = this.db.transaction('chunks', 'readwrite'), st = tx.objectStore('chunks');
      for (const e of entries) st.put(e.data, id + '|' + e.k);
      await done(tx);
    }
    getChunks(id) {
      return new Promise((res, rej) => {
        const out = [], c = this.db.transaction('chunks').objectStore('chunks').openCursor(IDBKeyRange.bound(id + '|', id + '|\uffff'));
        c.onsuccess = () => {
          const cur = c.result;
          if (cur) { out.push({ k: cur.key.slice(id.length + 1), data: cur.value }); cur.continue(); } else res(out);
        };
        c.onerror = () => rej(c.error);
      });
    }
    async deleteWorld(id) {
      const tx = this.db.transaction(['worlds', 'chunks'], 'readwrite');
      tx.objectStore('worlds').delete(id);
      tx.objectStore('chunks').delete(IDBKeyRange.bound(id + '|', id + '|\uffff'));
      await done(tx);
    }
  }

  class LocalBackend {
    constructor() { this.kind = 'localstorage'; this.persistent = true; }
    async listWorlds() {
      const out = [];
      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i);
        if (k.indexOf('vx:w:') === 0) { try { out.push(JSON.parse(localStorage.getItem(k)).meta); } catch (e) { /* ข้ามเซฟเสีย */ } }
      }
      return out;
    }
    async getWorld(id) { const s = localStorage.getItem('vx:w:' + id); return s ? JSON.parse(s) : undefined; }
    async putWorld(id, state) { localStorage.setItem('vx:w:' + id, JSON.stringify(state)); }
    async putChunks(id, entries) { for (const e of entries) localStorage.setItem('vx:c:' + id + ':' + e.k, VX.RLE.toBase64(e.data)); }
    async getChunks(id) {
      const p = 'vx:c:' + id + ':', out = [];
      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i);
        if (k.indexOf(p) === 0) out.push({ k: k.slice(p.length), data: VX.RLE.fromBase64(localStorage.getItem(k)) });
      }
      return out;
    }
    async deleteWorld(id) {
      const p = 'vx:c:' + id + ':', del = ['vx:w:' + id];
      for (let i = 0; i < localStorage.length; i++) if (localStorage.key(i).indexOf(p) === 0) del.push(localStorage.key(i));
      del.forEach((k) => localStorage.removeItem(k));
    }
  }

  class MemoryBackend {
    constructor() { this.kind = 'memory'; this.persistent = false; this.w = new Map(); this.c = new Map(); }
    async listWorlds() { return Array.from(this.w.values()).map((s) => s.meta); }
    async getWorld(id) { return this.w.get(id); }
    async putWorld(id, state) { this.w.set(id, JSON.parse(JSON.stringify(state))); }
    async putChunks(id, entries) { for (const e of entries) this.c.set(id + '|' + e.k, e.data.slice()); }
    async getChunks(id) {
      const out = [];
      for (const [k, v] of this.c) if (k.indexOf(id + '|') === 0) out.push({ k: k.slice(id.length + 1), data: v.slice() });
      return out;
    }
    async deleteWorld(id) {
      this.w.delete(id);
      for (const k of Array.from(this.c.keys())) if (k.indexOf(id + '|') === 0) this.c.delete(k);
    }
  }

  function idbOpen() {
    return new Promise((res, rej) => {
      const r = indexedDB.open('aetheria-voxel', 1);   // ชื่อฐานข้อมูลภายใน คงไว้เหมือนเดิมเพื่อไม่ให้เซฟเก่าหาย (ไม่เกี่ยวกับชื่อเกมที่แสดง)
      r.onupgradeneeded = () => { r.result.createObjectStore('worlds', { keyPath: 'meta.id' }); r.result.createObjectStore('chunks'); };
      r.onsuccess = () => res(r.result);
      r.onerror = () => rej(r.error || new Error('idb error'));
      r.onblocked = () => rej(new Error('idb blocked'));
      setTimeout(() => rej(new Error('idb timeout')), 2500);
    });
  }

  async function open() {
    try {
      if (typeof indexedDB !== 'undefined' && indexedDB) {
        const b = new IDBBackend(await idbOpen());
        await b.listWorlds();                        // ลองอ่านจริง 1 ครั้ง (บางเบราว์เซอร์เปิดได้แต่ใช้ไม่ได้)
        return b;
      }
    } catch (e) { console.warn('IndexedDB unavailable:', e && e.message); }
    try {
      localStorage.setItem('vx:probe', '1'); localStorage.removeItem('vx:probe');
      return new LocalBackend();
    } catch (e) { console.warn('localStorage unavailable:', e && e.message); }
    return new MemoryBackend();
  }

  return { open, IDBBackend, LocalBackend, MemoryBackend };
})();
