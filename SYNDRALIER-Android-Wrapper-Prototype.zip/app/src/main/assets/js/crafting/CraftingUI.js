// CraftingUI : หน้าจอ Crafting สำหรับมือถือ (หมวด -> รายการสูตร -> รายละเอียด + ปุ่ม CRAFT)
// อ่านข้อมูลทั้งหมดจาก RecipeRegistry/CraftingSystem ไม่มีสูตรฝังในไฟล์นี้
VX.CraftingUI = class {
  constructor(sys, bps, reg, input, hooks) {
    this.sys = sys; this.bps = bps; this.reg = reg; this.input = input; this.hooks = hooks;
    this.isOpen = false; this.other = null;
    this.cat = null; this.sel = {}; this.benchTier = 0; this.acc = 0; this.ver = -1; this.msg = '';
    this.root = document.getElementById('craft-screen');
    this.root.innerHTML =
      '<div id="craft-panel"><div id="craft-head"><b id="craft-title"></b><button id="craft-close">ปิด</button></div>' +
      '<div id="craft-tabs"></div><div id="craft-list"></div><div id="craft-detail"></div></div>';
    this.tabs = document.getElementById('craft-tabs');
    this.list = document.getElementById('craft-list');
    this.detail = document.getElementById('craft-detail');
    this.title = document.getElementById('craft-title');

    document.getElementById('craft-close').addEventListener('click', () => this.close());
    this.tabs.addEventListener('click', (e) => {
      const t = e.target.closest('.tab');
      if (t) { this.cat = t.dataset.cat; this.msg = ''; this.render(); }
    });
    this.list.addEventListener('click', (e) => {
      const r = e.target.closest('.rrow');
      if (r) { this.sel[this.cat] = r.dataset.id; this.msg = ''; this.render(); }
    });
    this.detail.addEventListener('click', (e) => {
      const b = e.target.closest('button');
      if (!b || b.disabled) return;
      if (b.id === 'do-craft') this.doCraft(); else if (b.id === 'do-learn') this.doLearn();
    });
    window.addEventListener('keydown', (e) => { if (e.code === 'Escape' && this.isOpen) this.close(); });
  }

  ctx() { return { benchTier: this.benchTier }; }
  toggle() { if (this.isOpen) this.close(); else this.open(); }

  open() {
    if (this.other && this.other.isOpen) this.other.close(true);
    this.isOpen = true;
    this.root.style.display = 'flex';
    const i = this.input;
    i.stick.x = i.stick.y = 0; i.touchBreak = false; i.mouseBreak = false; i.touchJump = false; i.placeQueued = false;
    if (i.releaseAll) i.releaseAll();
    if (document.pointerLockElement && document.exitPointerLock) document.exitPointerLock();
    this.benchTier = this.hooks.getBenchTier();
    this.msg = '';
    this.render();
  }

  close(skipLock) {
    this.isOpen = false;
    this.root.style.display = 'none';
    if (!skipLock && (!this.input.isTouch || this.input.mode === 'mouse') && !this.input.freeLook) {
      const canvas = this.hooks.canvas;
      canvas.requestPointerLock();
      setTimeout(() => { if (!this.isOpen && document.pointerLockElement !== canvas) this.hooks.onLockFailed(); }, 400);
    }
  }

  update(dt) {
    if (!this.isOpen) return;
    this.acc += dt;
    let dirty = this.ver !== this.sys.inv.version;
    if (this.acc > 0.4) {                      // เช็ค Work Bench ใกล้ตัวเป็นระยะ
      this.acc = 0;
      const t = this.hooks.getBenchTier();
      if (t !== this.benchTier) { this.benchTier = t; dirty = true; }
    }
    if (dirty) this.render();
  }

  doCraft() {
    const id = this.sel[this.cat];
    const res = this.sys.craft(id, this.ctx());
    const why = { locked: 'ยังไม่ปลดล็อก', bench: 'ต้องอยู่ใกล้ Work Bench ระดับที่กำหนด', materials: 'วัตถุดิบไม่พอ', full: 'กระเป๋าเต็ม' };
    this.msg = res.ok ? '✔ สร้าง ' + res.recipe.outputItem.label + ' ×' + res.recipe.output.count : '✖ ' + (why[res.reason] || res.reason);
    this.render();
  }
  doLearn() {
    const id = this.sel.__bp;
    const res = this.bps.learnFromInventory(this.sys.inv, id, this.benchTier);
    const why = { bench: 'ต้องอยู่ใกล้ Work Bench ระดับที่กำหนด', missing: 'ไม่มี Blueprint ในกระเป๋า', learned: 'เรียนรู้แล้ว' };
    this.msg = res.ok ? '✔ เรียนรู้ Blueprint: ' + res.blueprint.name + ' แล้ว' : '✖ ' + (why[res.reason] || res.reason);
    this.render();
  }

  icon(item) { return '<img src="' + VX.Icons.url(item.id) + '" alt="">'; }

  render() {
    const sys = this.sys, reg = this.reg;
    sys.sync();
    this.ver = sys.inv.version;
    this.title.textContent = 'CRAFTING  ·  ' + (this.benchTier ? 'Work Bench Tier ' + this.benchTier : 'Hand (ไม่มี Work Bench)');

    const cats = reg.categories().filter((c) => reg.byCategory(c.id).length);
    const tabs = cats.map((c) => ({ id: c.id, label: c.label })).concat([{ id: '__bp', label: 'Blueprint' }]);
    if (!tabs.some((t) => t.id === this.cat)) this.cat = tabs[0].id;
    this.tabs.innerHTML = tabs.map((t) =>
      '<div class="tab' + (t.id === this.cat ? ' on' : '') + '" data-cat="' + t.id + '">' + t.label + '</div>').join('');

    if (this.cat === '__bp') this.renderBlueprints(); else this.renderRecipes();
  }

  renderRecipes() {
    const rows = this.sys.list(this.cat, this.ctx());
    if (!rows.some((x) => x.recipe.id === this.sel[this.cat])) this.sel[this.cat] = rows[0].recipe.id;
    const selId = this.sel[this.cat];
    this.list.innerHTML = rows.map((x) => {
      const r = x.recipe, s = x.status;
      const cls = 'rrow' + (r.id === selId ? ' sel' : '') + (s.canCraft ? ' can' : '') + (!s.unlocked ? ' locked' : '');
      const mark = !s.unlocked ? '🔒' : s.canCraft ? '✔' : '';
      return '<div class="' + cls + '" data-id="' + r.id + '">' + this.icon(r.outputItem) +
        '<span>' + r.outputItem.label + '</span><small>' + mark + '</small></div>';
    }).join('');

    const sel = rows.find((x) => x.recipe.id === selId), r = sel.recipe, s = sel.status;
    const mats = s.rows.map((m) => '<div class="mat ' + (m.have >= m.need ? 'ok' : 'no') + '">' + this.icon(m.item) +
      '<span>' + m.label + '</span><b>' + m.have + ' / ' + m.need + '</b></div>').join('');
    const reqTxt = r.benchTier ? 'Work Bench Tier ' + r.benchTier : 'ไม่ต้องใช้ Work Bench (คราฟต์ด้วยมือ)';
    this.detail.innerHTML =
      '<div class="d-title">' + this.icon(r.outputItem) + '<span>' + r.outputItem.label.toUpperCase() + ' ×' + r.output.count + '</span></div>' +
      '<div class="d-mats">' + mats + '</div>' +
      '<div class="d-req ' + (s.benchOk ? 'ok' : 'no') + '">Required: ' + reqTxt + '</div>' +
      '<div class="d-lock ' + (s.unlocked ? 'ok' : 'no') + '">' + (s.unlocked ? '✔ Unlocked' : '🔒 Locked — ' + s.lockReason) + '</div>' +
      '<button id="do-craft"' + (s.canCraft ? '' : ' disabled') + '>CRAFT</button>' +
      '<div class="d-msg">' + this.msg + '</div>';
  }

  renderBlueprints() {
    const list = this.reg.blueprints(), inv = this.sys.inv;
    if (!list.some((b) => b.id === this.sel.__bp)) this.sel.__bp = list[0].id;
    const selId = this.sel.__bp;
    const info = (b) => {
      const item = VX.Items.byName(b.item), learned = this.bps.has(b.id), have = inv.count(item.id);
      return { item, learned, have };
    };
    this.list.innerHTML = list.map((b) => {
      const i = info(b);
      const mark = i.learned ? '✔ เรียนแล้ว' : i.have ? 'มี ×' + i.have : '';
      return '<div class="rrow' + (b.id === selId ? ' sel' : '') + (i.learned ? ' can' : i.have ? '' : ' locked') + '" data-id="' + b.id + '">' +
        this.icon(i.item) + '<span>' + b.name + '</span><small>' + mark + '</small></div>';
    }).join('');

    const b = this.reg.blueprint(selId), i = info(b);
    const benchOk = this.benchTier >= b.benchTier;
    const canLearn = !i.learned && i.have > 0 && benchOk;
    const status = i.learned ? '✔ เรียนรู้แล้ว (ปลดล็อกถาวร)' : i.have ? 'มี Blueprint ในกระเป๋า ×' + i.have : 'ยังไม่พบ Blueprint — ลองขุดแร่/สำรวจโลก';
    this.detail.innerHTML =
      '<div class="d-title">' + this.icon(i.item) + '<span>' + b.name.toUpperCase() + '</span></div>' +
      '<div class="d-mats"><div class="mat ok"><span>ปลดล็อกสูตร</span><b>' + b.description + '</b></div></div>' +
      '<div class="d-req ' + (benchOk ? 'ok' : 'no') + '">เรียนรู้ที่: Work Bench Tier ' + b.benchTier + '</div>' +
      '<div class="d-lock ' + (i.learned || i.have ? 'ok' : 'no') + '">' + status + '</div>' +
      '<button id="do-learn"' + (canLearn ? '' : ' disabled') + '>LEARN</button>' +
      '<div class="d-msg">' + this.msg + '</div>';
  }
};
