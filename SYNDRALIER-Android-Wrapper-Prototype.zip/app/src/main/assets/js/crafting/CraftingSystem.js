// CraftingSystem : ตรรกะการคราฟต์ล้วน ๆ (ไม่แตะ DOM/UI) — UI แค่เรียก status() และ craft()
//   สถานะการปลดล็อกประเมินจาก "เงื่อนไข" (conditions) ที่ลงทะเบียนไว้ เพิ่มชนิดใหม่ได้ด้วย addCondition()
VX.CraftingSystem = class {
  constructor(inventory, registry, blueprints) {
    this.inv = inventory; this.reg = registry; this.bp = blueprints;
    this.discovered = new Set();   // ชื่อไอเทมที่ผู้เล่นเคยครอบครอง (เงื่อนไข "discover")
    this.flags = new Set();        // ธง progression อื่น ๆ
    this.listeners = [];
    this._ver = -1;
    inventory.onAdd = (id) => this.discovered.add(VX.Items.get(id).name);
    this.conditions = {};
    this.addCondition('blueprint', (v) => this.bp.has(v),
      (v) => 'Blueprint: ' + ((this.reg.blueprint(v) || {}).name || v));
    this.addCondition('discover', (v) => this.discovered.has(v),
      (v) => 'ต้องค้นพบ ' + VX.Items.byName(v).label + ' ก่อน');
    this.addCondition('flag', (v) => this.flags.has(v), (v) => 'Progression: ' + v);
  }

  addCondition(type, test, describe) { this.conditions[type] = { test, describe }; }
  on(fn) { this.listeners.push(fn); }

  // อัปเดตรายการ "เคยครอบครอง" เมื่อ inventory เปลี่ยน
  sync() {
    if (this.inv.version === this._ver) return;
    this._ver = this.inv.version;
    const note = (s) => { if (s) this.discovered.add(VX.Items.get(s.id).name); };
    this.inv.slots.forEach(note); note(this.inv.cursor);
  }

  // เหตุผลที่ยังล็อก (null = ปลดล็อกแล้ว)
  lockReason(r) {
    for (const c of r.unlock) {
      const h = this.conditions[c.type];
      if (!h) return 'Unknown condition: ' + c.type;
      if (!h.test(c.value)) return h.describe(c.value);
    }
    return null;
  }
  isUnlocked(r) { return this.lockReason(r) === null; }

  // ctx = { benchTier } : Work Bench ที่อยู่ใกล้ผู้เล่น (0 = ไม่มี)
  status(r, ctx) {
    const benchTier = (ctx && ctx.benchTier) || 0;
    const lock = this.lockReason(r);
    const rows = r.ingredients.map((g) => {
      const it = VX.Items.byName(g.item);
      return { item: it, label: it.label, need: g.count, have: this.inv.count(it.id) };
    });
    const hasAll = rows.every((x) => x.have >= x.need);
    const benchOk = benchTier >= r.benchTier;
    const reason = lock ? 'locked' : !benchOk ? 'bench' : !hasAll ? 'materials' : null;
    return { unlocked: !lock, lockReason: lock, benchOk, benchNeeded: r.benchTier, rows, hasAll, canCraft: !reason, reason };
  }

  // คราฟต์ 1 ครั้ง : หักวัตถุดิบ แล้วใส่ผลลัพธ์เข้า Inventory (ถ้ากระเป๋าเต็มจะยกเลิกและคืนของเดิมทั้งหมด)
  craft(id, ctx) {
    const r = this.reg.get(id);
    if (!r) return { ok: false, reason: 'unknown' };
    const st = this.status(r, ctx);
    if (!st.canCraft) return { ok: false, reason: st.reason };
    const snap = this.inv.snapshot(), outName = r.output.item, had = this.discovered.has(outName);
    for (const g of r.ingredients) this.inv.remove(VX.Items.byName(g.item).id, g.count);
    const left = this.inv.add(r.outputItem.id, r.output.count);
    if (left > 0) { this.inv.restore(snap); if (!had) this.discovered.delete(outName); return { ok: false, reason: 'full' }; }
    this.listeners.forEach((fn) => fn(r));
    return { ok: true, recipe: r };
  }

  // รายการสูตรในหมวด : คราฟต์ได้ก่อน -> ปลดล็อกแล้ว -> ยังล็อก (คงลำดับเดิมในกลุ่มเดียวกัน)
  list(categoryId, ctx) {
    const rank = (s) => (s.canCraft ? 0 : s.unlocked ? 1 : 2);
    return this.reg.byCategory(categoryId)
      .map((r, i) => ({ recipe: r, status: this.status(r, ctx), i }))
      .sort((a, b) => rank(a.status) - rank(b.status) || a.i - b.i);
  }

  // Work Bench ระดับสูงสุดที่อยู่ใกล้ตำแหน่ง pos (สแกนบล็อกรอบตัว)
  static nearbyBenchTier(world, pos, radius) {
    const R = radius || VX.Config.CRAFT_RADIUS;
    const x0 = Math.floor(pos.x), y0 = Math.floor(pos.y), z0 = Math.floor(pos.z);
    let best = 0;
    for (let y = y0 - 2; y <= y0 + 3; y++) for (let z = z0 - R; z <= z0 + R; z++) for (let x = x0 - R; x <= x0 + R; x++) {
      const t = VX.Blocks.get(world.getBlock(x, y, z)).benchTier;
      if (t > best) best = t;
    }
    return best;
  }

  serialize() { return { discovered: Array.from(this.discovered), flags: Array.from(this.flags) }; }
  deserialize(d) { this.discovered = new Set(d.discovered || []); this.flags = new Set(d.flags || []); this._ver = -1; }
};
