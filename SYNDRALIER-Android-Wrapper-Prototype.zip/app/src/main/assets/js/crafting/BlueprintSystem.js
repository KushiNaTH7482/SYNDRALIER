// BlueprintSystem : สถานะ Blueprint ที่ผู้เล่นเรียนรู้แล้ว (ถาวร) + กฎได้ Blueprint จากการขุด
// Blueprint ไม่ใช่วัตถุดิบ : ใช้ไอเทม Blueprint 1 ชิ้นเพื่อ "เรียนรู้" ครั้งเดียว แล้วสูตรปลดล็อกถาวร
VX.BlueprintSystem = class {
  constructor(registry) {
    this.reg = registry;
    this.learned = new Set();
    this.firstHarvest = new Set();
    this.listeners = [];
  }
  on(fn) { this.listeners.push(fn); }
  has(id) { return this.learned.has(id); }

  learn(id) {
    if (!this.reg.blueprint(id) || this.learned.has(id)) return false;
    this.learned.add(id);
    this.listeners.forEach((fn) => fn(id));
    return true;
  }

  // เรียนรู้จากไอเทม Blueprint ในกระเป๋า (ต้องมี Work Bench ระดับพอ)
  learnFromInventory(inv, id, benchTier) {
    const bp = this.reg.blueprint(id);
    if (!bp) return { ok: false, reason: 'unknown' };
    if (this.has(id)) return { ok: false, reason: 'learned' };
    if (benchTier < bp.benchTier) return { ok: false, reason: 'bench' };
    const item = VX.Items.byName(bp.item);
    if (inv.count(item.id) < 1) return { ok: false, reason: 'missing' };
    inv.remove(item.id, 1);
    this.learn(id);
    return { ok: true, blueprint: bp };
  }

  // คืนรายชื่อไอเทม Blueprint ที่ควรดรอปเมื่อเก็บเกี่ยวบล็อกชนิดนี้
  rollDiscovery(blockName, rand) {
    rand = rand || Math.random;
    const out = [];
    for (const rule of this.reg.discoveryRules(blockName)) {
      if (this.has(rule.blueprint)) continue;
      const key = rule.block + ':' + rule.blueprint;
      const bp = this.reg.blueprint(rule.blueprint);
      if (rule.first && !this.firstHarvest.has(key)) { this.firstHarvest.add(key); out.push(bp.item); }
      else if (rule.chance && rand() < rule.chance) out.push(bp.item);
    }
    return out;
  }

  serialize() { return { learned: Array.from(this.learned), firstHarvest: Array.from(this.firstHarvest) }; }
  deserialize(d) {
    this.learned = new Set(d.learned || []);
    this.firstHarvest = new Set(d.firstHarvest || []);
  }
};
