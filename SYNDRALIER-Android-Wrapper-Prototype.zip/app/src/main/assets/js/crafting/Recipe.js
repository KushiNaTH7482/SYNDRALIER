// Recipe : ข้อมูลสูตร 1 สูตร (ตรวจความถูกต้องตอนสร้าง เพื่อให้ข้อมูลผิดพังทันที ไม่ใช่ตอนเล่น)
//   id, output {item,count}, ingredients [{item,count}], category,
//   benchTier (0 = คราฟต์ด้วยมือ), blueprint (id หรือ null), unlock [{type,value}] เงื่อนไขเพิ่มเติม
VX.Recipe = class {
  constructor(def) {
    const bad = (m) => { throw new Error('Recipe "' + def.id + '": ' + m); };
    if (!def.id) throw new Error('Recipe without id');
    if (!def.category) bad('missing category');
    if (!def.output || !VX.Items.byName(def.output.item)) bad('unknown output item ' + (def.output && def.output.item));
    if (!def.ingredients || !def.ingredients.length) bad('no ingredients');
    for (const g of def.ingredients) {
      if (!VX.Items.byName(g.item)) bad('unknown ingredient ' + g.item);
      if (!(g.count > 0)) bad('bad count for ' + g.item);
    }
    this.id = def.id;
    this.category = def.category;
    this.output = { item: def.output.item, count: def.output.count || 1 };
    this.ingredients = def.ingredients.map((g) => ({ item: g.item, count: g.count }));
    this.benchTier = def.benchTier || 0;
    this.blueprint = def.blueprint || null;
    this.unlock = (def.unlock || []).slice();
    if (this.blueprint) this.unlock.unshift({ type: 'blueprint', value: this.blueprint });
  }
  get outputItem() { return VX.Items.byName(this.output.item); }
};
