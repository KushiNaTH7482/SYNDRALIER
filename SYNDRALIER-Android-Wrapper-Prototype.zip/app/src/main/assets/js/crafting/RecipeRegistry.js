// RecipeRegistry : ที่เก็บ Recipe / Category / Blueprint / กฎ Discovery (ข้อมูลล้วน ไม่ผูกกับ UI)
// เพิ่มสูตรหรือหมวดใหม่ได้โดยไม่ต้องแก้ CraftingSystem
VX.RecipeRegistry = (function () {
  const recipes = new Map(), cats = new Map(), blueprints = new Map(), discovery = [];

  return {
    registerCategory(c) { cats.set(c.id, Object.assign({ order: cats.size }, c)); },
    categories() { return Array.from(cats.values()).sort((a, b) => a.order - b.order); },

    registerBlueprint(b) {
      if (!VX.Items.byName(b.item)) throw new Error('Blueprint item missing: ' + b.item);
      blueprints.set(b.id, Object.assign({ benchTier: 1, description: '' }, b));
    },
    blueprint(id) { return blueprints.get(id); },
    blueprints() { return Array.from(blueprints.values()); },

    // กฎ Discovery : ขุดบล็อก X แล้วอาจได้ Blueprint (first = รับประกันครั้งแรก, chance = โอกาสครั้งต่อ ๆ ไป)
    registerDiscovery(rule) {
      if (!blueprints.has(rule.blueprint)) throw new Error('Unknown blueprint in discovery: ' + rule.blueprint);
      discovery.push(rule);
    },
    discoveryRules(block) { return discovery.filter((r) => r.block === block); },

    addRecipe(def) {
      const r = def instanceof VX.Recipe ? def : new VX.Recipe(def);
      if (!cats.has(r.category)) throw new Error('Recipe "' + r.id + '": unknown category ' + r.category);
      if (r.blueprint && !blueprints.has(r.blueprint)) throw new Error('Recipe "' + r.id + '": unknown blueprint ' + r.blueprint);
      if (recipes.has(r.id)) throw new Error('Duplicate recipe ' + r.id);
      recipes.set(r.id, r);
      return r;
    },
    get(id) { return recipes.get(id); },
    all() { return Array.from(recipes.values()); },
    byCategory(id) { return this.all().filter((r) => r.category === id); }
  };
})();
