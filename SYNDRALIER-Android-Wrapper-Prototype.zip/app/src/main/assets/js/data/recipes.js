// ข้อมูล Crafting ทั้งหมดของ Aetheria (หมวด, Blueprint, กฎ Discovery, สูตร)
// เพิ่มสูตรใหม่ = เพิ่มบรรทัดในไฟล์นี้ ไม่ต้องแก้ระบบ Crafting และ UI
(function () {
  const R = VX.RecipeRegistry, I = VX.Items;

  // ---- หมวดหมู่ (หมวดที่ยังไม่มีสูตรจะไม่แสดงใน UI เพิ่มสูตรเมื่อไรก็ขึ้นเอง) ----
  [['tools', 'Tools'], ['weapons', 'Weapons'], ['armor', 'Armor'], ['materials', 'Materials'],
   ['workbench', 'Work Bench'], ['food', 'Food'], ['utility', 'Utility'], ['decoration', 'Decoration'],
   ['enhancement', 'Enhancement']].forEach((c, i) => R.registerCategory({ id: c[0], label: c[1], order: i }));

  // ---- Blueprint : [id, ชื่อ, Work Bench tier ที่ใช้เรียนรู้, คำอธิบาย] ----
  [['copper_tools', 'Copper Tools', 1, 'Copper Pickaxe, Axe, Shovel'],
   ['copper_sword', 'Copper Sword', 1, 'Copper Sword'],
   ['iron_tools', 'Iron Tools', 2, 'Iron Pickaxe, Axe, Shovel'],
   ['iron_sword', 'Iron Sword', 2, 'Iron Sword'],
   ['steelworking', 'Steelworking', 2, 'Steel Ingot'],
   ['steel_tools', 'Steel Tools', 2, 'Steel Pickaxe, Axe, Shovel'],
   ['steel_sword', 'Steel Sword', 2, 'Steel Sword']].forEach((b, i) => {
    I.register({ id: 300 + i, name: 'bp_' + b[0], label: 'Blueprint: ' + b[1], stackSize: 16, category: 'blueprint' });
    R.registerBlueprint({ id: b[0], name: b[1], item: 'bp_' + b[0], benchTier: b[2], description: b[3] });
  });

  // ---- Discovery : ขุดบล็อกแล้วได้ Blueprint (first = ครั้งแรกรับประกัน, chance = โอกาสครั้งต่อไป) ----
  [['copper_ore', 'copper_tools', true, 0.08], ['copper_ore', 'copper_sword', false, 0.12],
   ['iron_ore', 'iron_tools', true, 0.08], ['iron_ore', 'iron_sword', false, 0.12], ['iron_ore', 'steelworking', false, 0.12],
   ['gold_ore', 'steel_tools', false, 0.25], ['gold_ore', 'steel_sword', false, 0.25],
   ['diamond_ore', 'steel_tools', false, 0.25], ['diamond_ore', 'steel_sword', false, 0.25]]
    .forEach((d) => R.registerDiscovery({ block: d[0], blueprint: d[1], first: d[2], chance: d[3] }));

  // ---- สูตร ----
  function add(id, cat, out, ing, opt) {
    opt = opt || {};
    R.addRecipe({
      id, category: cat, output: { item: out[0], count: out[1] },
      ingredients: ing.map((x) => ({ item: x[0], count: x[1] })),
      benchTier: opt.bench || 0, blueprint: opt.bp || null, unlock: opt.unlock || []
    });
  }

  // มือเปล่า (Tier 0) : ทรัพยากรจากสิ่งแวดล้อม -> เครื่องมือพื้นฐาน -> Work Bench
  // กิ่งไม้ได้จากใบไม้เท่านั้น (ไม่มีสูตรแปลงจากไม้ซุง)
  add('stone_knife', 'tools', ['stone_knife', 1], [['stick', 1], ['stone_chunk', 1]]);
  add('rope', 'materials', ['rope', 1], [['fiber', 3]]);
  add('stone_axe', 'tools', ['stone_axe', 1], [['stone_chunk', 3], ['stick', 1], ['rope', 1]]);
  add('stone_pickaxe', 'tools', ['stone_pickaxe', 1], [['stone_chunk', 3], ['stick', 2], ['rope', 1]]);
  add('stone_shovel', 'tools', ['stone_shovel', 1], [['stone_chunk', 1], ['stick', 2], ['rope', 1]]);
  add('stone_sword', 'weapons', ['stone_sword', 1], [['stone_chunk', 2], ['stick', 1], ['rope', 1]]);
  add('dried_meat', 'food', ['dried_meat', 1], [['meat', 2]]);
  add('cobblestone', 'decoration', ['cobblestone', 1], [['stone_chunk', 4]]);
  add('work_bench_1', 'workbench', ['work_bench_1', 1], [['wood', 4], ['stone_chunk', 4], ['fiber', 4]]);

  // Work Bench Tier 1 : Copper
  add('work_bench_2', 'workbench', ['work_bench_2', 1], [['copper', 8], ['stone_chunk', 6], ['stick', 4]],
      { bench: 1, unlock: [{ type: 'discover', value: 'copper' }] });
  add('copper_pickaxe', 'tools', ['copper_pickaxe', 1], [['copper', 3], ['stick', 2], ['fiber', 1]], { bench: 1, bp: 'copper_tools' });
  add('copper_axe', 'tools', ['copper_axe', 1], [['copper', 3], ['stick', 2], ['fiber', 1]], { bench: 1, bp: 'copper_tools' });
  add('copper_shovel', 'tools', ['copper_shovel', 1], [['copper', 1], ['stick', 2], ['fiber', 1]], { bench: 1, bp: 'copper_tools' });
  add('copper_sword', 'weapons', ['copper_sword', 1], [['copper', 2], ['stick', 1], ['fiber', 1]], { bench: 1, bp: 'copper_sword' });

  // Work Bench Tier 2 : Iron -> Steel
  add('iron_pickaxe', 'tools', ['iron_pickaxe', 1], [['iron', 3], ['stick', 2], ['fiber', 1]], { bench: 2, bp: 'iron_tools' });
  add('iron_axe', 'tools', ['iron_axe', 1], [['iron', 3], ['stick', 2], ['fiber', 1]], { bench: 2, bp: 'iron_tools' });
  add('iron_shovel', 'tools', ['iron_shovel', 1], [['iron', 1], ['stick', 2], ['fiber', 1]], { bench: 2, bp: 'iron_tools' });
  add('iron_sword', 'weapons', ['iron_sword', 1], [['iron', 2], ['stick', 1], ['fiber', 1]], { bench: 2, bp: 'iron_sword' });
  add('steel_ingot', 'materials', ['steel', 1], [['iron', 3], ['coal', 2]], { bench: 2, bp: 'steelworking' });
  add('steel_pickaxe', 'tools', ['steel_pickaxe', 1], [['steel', 3], ['stick', 2], ['fiber', 1]], { bench: 2, bp: 'steel_tools' });
  add('steel_axe', 'tools', ['steel_axe', 1], [['steel', 3], ['stick', 2], ['fiber', 1]], { bench: 2, bp: 'steel_tools' });
  add('steel_shovel', 'tools', ['steel_shovel', 1], [['steel', 1], ['stick', 2], ['fiber', 1]], { bench: 2, bp: 'steel_tools' });
  add('steel_sword', 'weapons', ['steel_sword', 1], [['steel', 2], ['stick', 1], ['fiber', 1]], { bench: 2, bp: 'steel_sword' });
})();
