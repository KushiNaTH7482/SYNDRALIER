// Icons : สร้างไอคอนไอเทมแบบ procedural (บล็อก = ลูกบาศก์ isometric จาก atlas)
VX.Icons = (function () {
  const SIZE = 32, cache = {};
  const SHAPES = {
    lump: ['..........', '...aabb...', '..abbbbb..', '.abbcbbba.', '.abbbbbba.', '.abbbcbba.', '..abbbba..', '...aaaa...'],
    ingot: ['..........', '..........', '...cccccc.', '..cbbbbbba', '.cbbbbbba.', '.aaaaaaa..', '..........', '..........'],
    gem: ['..........', '...cccc...', '..cbbbbb..', '.cbbccbba.', '..bbbbba..', '...bbba...', '....ba....', '..........'],
    stick: ['.........a', '........ab', '.......ab.', '......ab..', '.....ab...', '....ab....', '...ab.....', '..ab......'],
    fiber: ['..b..b....', '..b..c.b..', '.cb..b.b..', '..b.cb.b..', '.bb..b.cb.', '.b..cb..b.', '.b..b...b.', '..b.b.....'],
    rope: ['..........', '...bbbb...', '..bcbcbb..', '.bcb..bcb.', '.bb....bb.', '.bcb..bcb.', '..bbcbcb..', '...bbbb...'],
    sapling: ['..........', '....b.....', '...bbb....', '..bbcbb...', '...bbb....', '....a.....', '....a.....', '...aaa....'],
    paper: ['.aaaaaaaa.', '.abbbbbba.', '.abccccba.', '.abbbbbba.', '.abccccba.', '.abbbbbba.', '.abccbbba.', '.aaaaaaaa.']
  };
  const SPRITES = {
    coal: ['lump', '#15151a', '#2b2b33', '#4a4a55'],
    iron: ['ingot', '#8a7466', '#d8c8b8', '#f4ece4'],
    gold: ['ingot', '#b8860b', '#f2c230', '#fff0a0'],
    diamond: ['gem', '#1fb5b5', '#4eeaea', '#c9ffff'],
    stone_chunk: ['lump', '#4a4a4e', '#8a8a90', '#b5b5bb'],
    copper: ['ingot', '#7a3a1c', '#d9763a', '#ffb27a'],
    steel: ['ingot', '#3f4d5c', '#8fa3b8', '#d6e3f0'],
    stick: ['stick', '#5a3d1e', '#8b6030', '#8b6030'],
    fiber: ['fiber', '#3d6b2a', '#7cc04a', '#b6e57a'],
    blueprint: ['paper', '#1c3d7a', '#3b6fd4', '#cfe3ff'],
    rope: ['rope', '#6b5a33', '#b79a5e', '#e0c88a'],
    sapling: ['sapling', '#5a3d1e', '#4fa23a', '#8fdc64'],
    meat: ['lump', '#5a1515', '#c0392b', '#e8685a'],
    dried_meat: ['ingot', '#4a2a14', '#8a5a34', '#b88458'],
    hide: ['paper', '#5a3a22', '#9a6a40', '#c89868'],
    bone: ['stick', '#b8b4a0', '#f2eedc', '#f2eedc']
  };

  function blockIcon(g, def) {
    const A = VX.TextureAtlas, t = def.tex;
    const top = A.rect(t.top || t.side), side = A.rect(t.side || t.top);
    g.setTransform(14 / 16, 7 / 16, -14 / 16, 7 / 16, 16, 2);
    g.drawImage(A.canvas, top[0], top[1], 16, 16, 0, 0, 16, 16);
    g.setTransform(14 / 16, 7 / 16, 0, 14 / 16, 2, 9);
    g.drawImage(A.canvas, side[0], side[1], 16, 16, 0, 0, 16, 16);
    g.fillStyle = 'rgba(0,0,0,0.25)'; g.fillRect(0, 0, 16, 16);
    g.setTransform(14 / 16, -7 / 16, 0, 14 / 16, 16, 16);
    g.drawImage(A.canvas, side[0], side[1], 16, 16, 0, 0, 16, 16);
    g.fillStyle = 'rgba(0,0,0,0.45)'; g.fillRect(0, 0, 16, 16);
    g.setTransform(1, 0, 0, 1, 0, 0);
  }
  function spriteIcon(g, name) {
    const s = SPRITES[name], rows = SHAPES[s[0]], pal = { a: s[1], b: s[2], c: s[3] };
    rows.forEach((row, y) => { for (let x = 0; x < row.length; x++) {
      const ch = row[x]; if (ch === '.') continue;
      g.fillStyle = pal[ch]; g.fillRect(x * 3, y * 3 + 4, 3, 3);
    } });
  }

  const TOOLS = {
    pickaxe: ['..dhhhhd..', '.dh.ss.hd.', '.h..ss..h.', '....ss....', '....ss....', '....ss....', '....ss....', '....ss....'],
    axe: ['...dhhh...', '..dhhhhs..', '..hhhhss..', '...hhss...', '.....ss...', '.....ss...', '.....ss...', '.....ss...'],
    shovel: ['....dhh...', '...dhhhh..', '...hhhhh..', '....hhh...', '.....ss...', '.....ss...', '.....ss...', '.....ss...'],
    knife: ['..........', '.......hh.', '......hhd.', '.....hhd..', '....hhd...', '..sshd....', '.ss.......', 'ss........'],
    sword: ['........hh', '.......hhd', '......hhd.', '.....hhd..', '..s.hhd...', '...shd....', '..ss......', '.ss.......']
  };
  const HEADS = { 0: ['#8d8d92', '#5a5a60'], 1: ['#d9763a', '#8a4520'], 2: ['#d8d8dc', '#8c8c94'], 3: ['#8fb4e8', '#4f6f9c'] };
  function toolIcon(g, it) {
    const rows = TOOLS[it.tool.type], pal = HEADS[it.tool.tier];
    rows.forEach((row, y) => { for (let x = 0; x < row.length; x++) {
      const ch = row[x]; if (ch === '.') continue;
      g.fillStyle = ch === 'h' ? pal[0] : ch === 'd' ? pal[1] : '#7a5a34';
      g.fillRect(x * 3, y * 3 + 4, 3, 3);
    } });
  }

  // คืน canvas ของไอคอน (cache ไว้)
  function canvas(itemId) {
    if (cache[itemId]) return cache[itemId];
    const it = VX.Items.get(itemId), c = document.createElement('canvas');
    c.width = c.height = SIZE;
    const g = c.getContext('2d');
    g.imageSmoothingEnabled = false;
    if (it.blockId) blockIcon(g, VX.Blocks.get(it.blockId));
    else if (it.tool) toolIcon(g, it);
    else spriteIcon(g, it.category === 'blueprint' ? 'blueprint' : it.name);
    return (cache[itemId] = c);
  }
  const urls = {};
  return { canvas, url: (id) => urls[id] || (urls[id] = canvas(id).toDataURL()) };
})();
