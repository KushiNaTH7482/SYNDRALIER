// ItemManager : ไอเทมที่ตกอยู่ในโลก (physics, ดูดเข้าหาผู้เล่น, เก็บเข้า inventory, รวมกอง, despawn)
VX.ItemManager = class {
  constructor(scene, world, player) {
    this.scene = scene; this.world = world; this.player = player;
    this.inventory = null;
    this.items = [];
    this.mergeT = 0;
    this.geo = {}; this.spriteMat = {};
    this.MAX = VX.Config.MAX_DROPS; this.LIFETIME = VX.Config.DROP_LIFETIME;
  }

  cubeGeo(def) {
    if (this.geo[def.id]) return this.geo[def.id];
    const pos = [], uvs = [], col = [], nor = [], ind = [], s = 0.3;
    let v = 0;
    for (const f of VX.Chunk.FACES) {
      const u = def.faceUV[f.part];
      for (let k = 0; k < 4; k++) {
        pos.push((f.c[k][0] - 0.5) * s, (f.c[k][1] - 0.5) * s, (f.c[k][2] - 0.5) * s);
        nor.push(f.dir[0], f.dir[1], f.dir[2]);
        const cu = VX.Chunk.CORNER_UV[k];
        uvs.push(cu[0] ? u[2] : u[0], cu[1] ? u[3] : u[1]);
        col.push(f.shade, 1, 0);
      }
      ind.push(v, v + 1, v + 2, v, v + 2, v + 3); v += 4;
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    g.setAttribute('normal', new THREE.Float32BufferAttribute(nor, 3));
    g.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
    g.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
    g.setIndex(ind);
    return (this.geo[def.id] = g);
  }
  makeMesh(item) {
    if (item.blockId) return new THREE.Mesh(this.cubeGeo(VX.Blocks.get(item.blockId)), this.world.mats.opaque);
    let m = this.spriteMat[item.id];
    if (!m) {
      const t = new THREE.CanvasTexture(VX.Icons.canvas(item.id));
      t.magFilter = t.minFilter = THREE.NearestFilter;
      m = this.spriteMat[item.id] = new THREE.SpriteMaterial({ map: t, transparent: true });
    }
    const sp = new THREE.Sprite(m);
    sp.scale.set(0.45, 0.45, 1);
    return sp;
  }

  spawn(id, count, x, y, z, vx, vy, vz, delay, dur, life) {
    const item = VX.Items.get(id);
    if (!item || count <= 0) return;
    const mesh = this.makeMesh(item);
    this.scene.add(mesh);
    this.items.push({
      id, count, dur: dur || 0, item, mesh, spin: !!item.blockId,
      pos: new THREE.Vector3(x, y - 0.14, z), vel: new THREE.Vector3(vx || 0, vy || 0, vz || 0),
      age: 0, life: life || this.LIFETIME, delay: delay === undefined ? 0.5 : delay, phase: Math.random() * 6.28
    });
    if (this.items.length > this.MAX) this.remove(0);
    return this.items[this.items.length - 1];
  }
  remove(i) {
    const e = this.items[i];
    this.scene.remove(e.mesh);
    this.items.splice(i, 1);
  }

  solid(x, y, z) { return this.world.isSolid(x, y, z); }

  physics(e, dt) {
    const w = this.world, p = e.pos, v = e.vel;
    const inWater = VX.Blocks.get(w.getBlock(p.x, p.y + 0.14, p.z)).liquid;
    const steps = Math.max(1, Math.ceil(dt / (1 / 60))), sdt = dt / steps;
    for (let i = 0; i < steps; i++) {
      if (inWater) { v.y = Math.min(1.5, v.y * (1 - 2 * sdt) + 5 * sdt); v.x *= 1 - 3 * sdt; v.z *= 1 - 3 * sdt; }
      else v.y = Math.max(-30, v.y - 20 * sdt);
      const nx = p.x + v.x * sdt;
      if (this.solid(nx, p.y + 0.14, p.z)) v.x *= -0.3; else p.x = nx;
      const nz = p.z + v.z * sdt;
      if (this.solid(p.x, p.y + 0.14, nz)) v.z *= -0.3; else p.z = nz;
      const ny = p.y + v.y * sdt;
      if (this.solid(p.x, v.y < 0 ? ny : ny + 0.28, p.z)) {
        if (v.y < 0) { p.y = Math.floor(ny) + 1; e.ground = true; v.x *= Math.max(0, 1 - 12 * sdt); v.z *= Math.max(0, 1 - 12 * sdt); }
        v.y = 0;
      } else { p.y = ny; e.ground = false; }
    }
    if (this.solid(p.x, p.y + 0.14, p.z)) p.y += 3 * dt;   // ถูกบล็อกวางทับ : ดันขึ้น
  }

  update(dt) {
    const R = VX.Config.PICKUP_RADIUS, ED2 = VX.Config.ENTITY_DISTANCE * VX.Config.ENTITY_DISTANCE;
    const pl = this.player.pos, px = pl.x, py = pl.y + 0.9, pz = pl.z, inv = this.inventory;
    this.mergeT += dt;
    for (let i = this.items.length - 1; i >= 0; i--) {
      const e = this.items[i];
      e.age += dt; e.delay -= dt;
      if (e.age > e.life) { this.remove(i); continue; }
      if (this.world.isLoadedAt(e.pos.x, e.pos.z)) this.physics(e, dt);

      const bob = Math.sin(e.age * 2 + e.phase) * 0.04;
      e.mesh.position.set(e.pos.x, e.pos.y + 0.18 + bob, e.pos.z);
      if (e.spin) e.mesh.rotation.y = e.age * 1.0 + e.phase;

      const dx = px - e.pos.x, dy = py - (e.pos.y + 0.14), dz = pz - e.pos.z, d2 = dx * dx + dy * dy + dz * dz;
      e.mesh.visible = d2 < ED2;
      if (e.delay <= 0 && d2 < 4 * R * R && inv.canAccept(e.id)) {
        if (d2 < R * R * 0.6) {
          const left = inv.add(e.id, e.count, e.dur);
          if (left < e.count) VX.sfx('pickup', { pos: e.pos });
          if (left <= 0) { this.remove(i); continue; }
          e.count = left;
        } else {
          const d = Math.sqrt(d2);
          e.vel.x += dx / d * 45 * dt; e.vel.z += dz / d * 45 * dt; e.vel.y += dy / d * 45 * dt;
        }
      }
    }
    if (this.mergeT > 0.5) { this.mergeT = 0; this.mergeNearby(); }
  }

  // รวมกองไอเทมชนิดเดียวกันที่อยู่ใกล้กัน เพื่อลดจำนวน entity (กัน lag)
  mergeNearby() {
    const a = this.items;
    for (let i = 0; i < a.length; i++) {
      const A = a[i];
      if (!A || A.item.stackSize <= 1) continue;
      for (let j = a.length - 1; j > i; j--) {
        const B = a[j];
        if (B.id !== A.id || A.count + B.count > A.item.stackSize) continue;
        const dx = A.pos.x - B.pos.x, dy = A.pos.y - B.pos.y, dz = A.pos.z - B.pos.z;
        if (dx * dx + dy * dy + dz * dz < 0.8) { A.count += B.count; A.age = Math.min(A.age, B.age); this.remove(j); }
      }
    }
  }
};
