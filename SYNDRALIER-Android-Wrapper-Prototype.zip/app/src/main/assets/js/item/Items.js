// Item Registry : ทุกบล็อกมี item ของตัวเอง + วัสดุ + เครื่องมือ (เพิ่มชนิดใหม่ด้วย register())
// durability = 0 หมายถึงไม่มีความทนทาน
VX.Items = (function () {
  const byId = [], byName = {};
  const title = (s) => s.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());

  function register(def) {
    const it = Object.assign({ id: 0, name: '', label: null, stackSize: 64, durability: 0, category: 'misc', blockId: 0, tool: null, food: null }, def);
    if (byId[it.id]) throw new Error('Duplicate item id ' + it.id);
    if (byName[it.name]) throw new Error('Duplicate item name ' + it.name);
    it.label = it.label || title(it.name);
    byId[it.id] = it; byName[it.name] = it;
    return it;
  }

  for (const b of VX.Blocks.list()) if (!b.noItem) register({ id: b.id, name: b.name, label: b.label, category: 'block', blockId: b.id });

  // วัสดุ (Material)
  register({ id: 100, name: 'coal', category: 'material' });
  register({ id: 101, name: 'iron', category: 'material' });
  register({ id: 102, name: 'gold', category: 'material' });
  register({ id: 103, name: 'diamond', category: 'material' });
  register({ id: 104, name: 'stick', category: 'material' });
  register({ id: 105, name: 'fiber', category: 'material' });
  register({ id: 106, name: 'stone_chunk', label: 'Stone', category: 'material' });
  register({ id: 107, name: 'copper', category: 'material' });
  register({ id: 108, name: 'steel', category: 'material' });
  register({ id: 109, name: 'hide', category: 'material' });
  register({ id: 110, name: 'bone', category: 'material' });
  register({ id: 111, name: 'meat', label: 'Raw Meat', category: 'food', food: { hunger: 3, sat: 1.8 } });
  register({ id: 113, name: 'sapling', category: 'material' });
  register({ id: 114, name: 'rope', category: 'material' });
  register({ id: 112, name: 'dried_meat', label: 'Dried Meat', category: 'food', food: { hunger: 6, sat: 6 } });

  // เครื่องมือ/อาวุธ ตามสายวัสดุหลัก Stone -> Copper -> Iron -> Steel : [ชื่อ, tier, ความเร็วขุด, durability]
  const TIERS = [['stone', 0, 2, 60], ['copper', 1, 3.5, 130], ['iron', 2, 5, 250], ['steel', 3, 7, 600]];
  const TYPES = ['pickaxe', 'axe', 'shovel', 'sword'];
  const DAMAGE = { sword: [4, 5, 6, 8], axe: [3, 4, 5, 6], pickaxe: [2, 3, 4, 5], shovel: [2, 2, 3, 4] };   // ดาเมจต่อการโจมตี
  TIERS.forEach((t, ti) => TYPES.forEach((ty, yi) => register({
    id: 200 + ti * 10 + yi, name: t[0] + '_' + ty, stackSize: 1, durability: t[3],
    category: ty === 'sword' ? 'weapon' : 'tool',
    tool: { type: ty, tier: t[1], speed: t[2], damage: DAMAGE[ty][ti] }
  })));

  register({ id: 250, name: 'stone_knife', label: 'Stone Knife', stackSize: 1, durability: 60, category: 'tool', tool: { type: 'knife', tier: 0, speed: 2, damage: 2 } });

  // สถิติการต่อสู้ตามชนิดอาวุธ : cd = คูลดาวน์(วิ), reach = ระยะโจมตี, kb = แรงกระเด็น
  const COMBAT = {
    sword: { cd: 0.45, reach: 3.6, kb: 7 }, axe: { cd: 0.95, reach: 3.3, kb: 9 },
    knife: { cd: 0.35, reach: 3.0, kb: 4 }, pickaxe: { cd: 0.7, reach: 3.2, kb: 6 }, shovel: { cd: 0.7, reach: 3.2, kb: 6 }, hand: { cd: 0.4, reach: 3.0, kb: 5 }
  };

  return { COMBAT, register, get: (id) => byId[id], byName: (n) => byName[n], list: () => byId.filter(Boolean) };
})();
