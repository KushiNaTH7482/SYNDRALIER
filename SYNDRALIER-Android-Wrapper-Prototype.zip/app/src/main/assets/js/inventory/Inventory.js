// Inventory : 36 ช่อง (0-8 = Hotbar, 9-35 = กระเป๋า) + cursor stack สำหรับ drag/drop
VX.Inventory = class {
  constructor() {
    this.size = 36;
    this.slots = new Array(this.size).fill(null);   // { id, count, dur }
    this.cursor = null;                              // stack ที่ถือค้างอยู่ใต้นิ้ว/เมาส์
    this.selected = 0;
    this.onAdd = null;
    this.version = 0;                                // เพิ่มทุกครั้งที่เปลี่ยน ให้ UI วาดใหม่
  }
  touch() { this.version++; }
  select(i) { if (i >= 0 && i < 9) { this.selected = i; this.touch(); } }
  cycle(d) { this.select((this.selected + d + 9) % 9); }
  selectedStack() { return this.slots[this.selected]; }

  canAccept(id) {
    const max = VX.Items.get(id).stackSize;
    for (const s of this.slots) if (!s || (s.id === id && s.count < max)) return true;
    return false;
  }
  // เก็บเข้า inventory : รวม stack เดิมก่อน แล้วค่อยลงช่องว่าง คืนจำนวนที่เหลือ (เก็บไม่ลง)
  add(id, count, dur) {
    const it = VX.Items.get(id), max = it.stackSize, orig = count;
    if (max > 1) for (let i = 0; i < this.size && count > 0; i++) {
      const s = this.slots[i];
      if (s && s.id === id && s.count < max) { const n = Math.min(max - s.count, count); s.count += n; count -= n; }
    }
    for (let i = 0; i < this.size && count > 0; i++) if (!this.slots[i]) {
      const n = Math.min(max, count);
      this.slots[i] = { id, count: n, dur: it.durability ? (dur || it.durability) : 0 };
      count -= n;
    }
    if (this.onAdd && count < orig) this.onAdd(id);   // แจ้งระบบอื่น (เช่น Discovery) ว่ามีไอเทมชนิดนี้เข้ากระเป๋า
    this.touch();
    return count;
  }
  takeFromSlot(i, n) {
    const s = this.slots[i];
    if (!s) return null;
    n = Math.min(n, s.count);
    const out = { id: s.id, count: n, dur: s.dur };
    s.count -= n;
    if (s.count <= 0) this.slots[i] = null;
    this.touch();
    return out;
  }

  count(id) { let n = 0; for (const s of this.slots) if (s && s.id === id) n += s.count; return n; }
  // หักไอเทมออกจากกระเป๋า (เอาจากช่องท้าย ๆ ก่อน เพื่อให้ Hotbar อยู่ครบ) คืนจำนวนที่หักได้จริง
  remove(id, n) {
    let left = n;
    for (let i = this.size - 1; i >= 0 && left > 0; i--) {
      const s = this.slots[i];
      if (!s || s.id !== id) continue;
      const t = Math.min(left, s.count);
      s.count -= t; left -= t;
      if (s.count <= 0) this.slots[i] = null;
    }
    this.touch();
    return n - left;
  }
  snapshot() { return this.slots.map((s) => s && { id: s.id, count: s.count, dur: s.dur }); }
  restore(snap) { this.slots = snap.map((s) => s && { id: s.id, count: s.count, dur: s.dur }); this.touch(); }

  // คลิกซ้าย : หยิบ / วาง / รวม / สลับ
  click(i) {
    const s = this.slots[i], c = this.cursor;
    if (!c) { if (s) { this.cursor = s; this.slots[i] = null; } }
    else if (!s) { this.slots[i] = c; this.cursor = null; }
    else {
      const max = VX.Items.get(s.id).stackSize;
      if (s.id === c.id && max > 1 && s.count < max) {          // merge stack
        const n = Math.min(max - s.count, c.count);
        s.count += n; c.count -= n;
        if (c.count <= 0) this.cursor = null;
      } else { this.slots[i] = c; this.cursor = s; }              // swap
    }
    this.touch();
  }
  // คลิกขวา : หยิบครึ่ง (split stack) / วางทีละ 1
  rightClick(i) {
    const s = this.slots[i], c = this.cursor;
    if (!c) {
      if (!s) return;
      if (s.count > 1) {
        const half = Math.ceil(s.count / 2);
        this.cursor = { id: s.id, count: half, dur: s.dur };
        s.count -= half;
      } else { this.cursor = s; this.slots[i] = null; }
    } else {
      const max = VX.Items.get(c.id).stackSize;
      if (!s) { this.slots[i] = { id: c.id, count: 1, dur: c.dur }; c.count--; }
      else if (s.id === c.id && s.count < max) { s.count++; c.count--; }
      else return;
      if (c.count <= 0) this.cursor = null;
    }
    this.touch();
  }
};
