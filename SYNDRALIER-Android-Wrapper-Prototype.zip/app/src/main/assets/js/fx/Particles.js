// Particles : อนุภาคเบา ๆ (Points ชุดเดียว วนใช้ซ้ำ ไม่สร้าง object ใหม่) — ปรับปริมาณด้วย VX.Config.PARTICLE_SCALE
VX.Particles = class {
  constructor(scene) {
    this.max = 160; this.n = 0;
    this.pos = new Float32Array(this.max * 3); this.col = new Float32Array(this.max * 3);
    this.vel = new Float32Array(this.max * 3); this.life = new Float32Array(this.max);
    const g = new THREE.BufferGeometry();
    this.posAttr = new THREE.BufferAttribute(this.pos, 3); this.colAttr = new THREE.BufferAttribute(this.col, 3);
    g.setAttribute('position', this.posAttr); g.setAttribute('color', this.colAttr);
    g.setDrawRange(0, 0);
    this.geo = g;
    this.points = new THREE.Points(g, new THREE.PointsMaterial({ size: 6, sizeAttenuation: false, vertexColors: true, transparent: true, opacity: 0.95, depthWrite: false }));
    this.points.frustumCulled = false;
    scene.add(this.points);
  }

  emit(x, y, z, count, rgb, speed, life, up) {
    count = Math.round(count * VX.Config.PARTICLE_SCALE);
    for (let i = 0; i < count && this.n < this.max; i++) {
      const k = this.n++, a = Math.random() * Math.PI * 2, s = speed * (0.4 + Math.random() * 0.8);
      this.pos[k * 3] = x; this.pos[k * 3 + 1] = y; this.pos[k * 3 + 2] = z;
      this.vel[k * 3] = Math.cos(a) * s; this.vel[k * 3 + 1] = (up || 0) + Math.random() * speed; this.vel[k * 3 + 2] = Math.sin(a) * s;
      const sh = 0.75 + Math.random() * 0.25;
      this.col[k * 3] = rgb[0] * sh; this.col[k * 3 + 1] = rgb[1] * sh; this.col[k * 3 + 2] = rgb[2] * sh;
      this.life[k] = life * (0.6 + Math.random() * 0.4);
    }
  }
  hit(x, y, z, crit) { this.emit(x, y, z, crit ? 14 : 7, crit ? [1, 0.88, 0.3] : [0.95, 0.15, 0.15], crit ? 4 : 3, 0.45, 2); }
  puff(x, y, z) { this.emit(x, y, z, 16, [0.75, 0.75, 0.78], 2.5, 0.7, 1.5); }
  chips(x, y, z, rgb) { this.emit(x, y, z, 9, rgb, 2.6, 0.55, 1.5); }

  update(dt) {
    for (let i = this.n - 1; i >= 0; i--) {
      this.life[i] -= dt;
      if (this.life[i] <= 0) {                           // เอาตัวท้ายมาแทนที่ตัวที่หมดอายุ
        const l = --this.n;
        if (i !== l) for (let c = 0; c < 3; c++) { this.pos[i * 3 + c] = this.pos[l * 3 + c]; this.col[i * 3 + c] = this.col[l * 3 + c]; this.vel[i * 3 + c] = this.vel[l * 3 + c]; }
        this.life[i] = this.life[l];
        continue;
      }
      this.vel[i * 3 + 1] -= 14 * dt;
      this.pos[i * 3] += this.vel[i * 3] * dt; this.pos[i * 3 + 1] += this.vel[i * 3 + 1] * dt; this.pos[i * 3 + 2] += this.vel[i * 3 + 2] * dt;
    }
    this.geo.setDrawRange(0, this.n);
    this.posAttr.needsUpdate = true; this.colAttr.needsUpdate = true;
  }
};
