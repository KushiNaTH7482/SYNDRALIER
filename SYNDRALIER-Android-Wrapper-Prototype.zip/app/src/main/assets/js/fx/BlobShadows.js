// BlobShadows : เงากลมใต้มอนและไอเทม (ไม่ใช้ shadow map เพื่อให้เบาบนมือถือ) — เปิด/ปิดที่ Settings > เงา
VX.BlobShadows = class {
  constructor(scene, world) {
    this.world = world;
    const c = document.createElement('canvas'); c.width = c.height = 64;
    const g = c.getContext('2d'), grad = g.createRadialGradient(32, 32, 4, 32, 32, 30);
    grad.addColorStop(0, 'rgba(0,0,0,0.9)'); grad.addColorStop(1, 'rgba(0,0,0,0)');
    g.fillStyle = grad; g.fillRect(0, 0, 64, 64);
    const tex = new THREE.CanvasTexture(c);
    const geo = new THREE.PlaneGeometry(1, 1); geo.rotateX(-Math.PI / 2);
    this.pool = [];
    for (let i = 0; i < 40; i++) {
      const m = new THREE.Mesh(geo, new THREE.MeshBasicMaterial({ map: tex, transparent: true, depthWrite: false, opacity: 0 }));
      m.visible = false; m.renderOrder = 2; scene.add(m); this.pool.push(m);
    }
    this.used = 0;
  }
  ground(x, y, z) {                                   // y ของผิวพื้นใต้ตำแหน่งนี้ (ลงไปไม่เกิน 8 บล็อก)
    const yf = Math.floor(y + 0.1);
    for (let k = 0; k < 8; k++) if (this.world.isSolid(x, yf - k, z)) return yf - k + 1;
    return null;
  }
  update(mobs, items, pp, enabled) {
    let n = 0;
    if (enabled) {
      const put = (x, y, z, size) => {
        if (n >= this.pool.length) return;
        const gy = this.ground(x, y, z);
        if (gy === null || y - gy > 5) return;
        const m = this.pool[n++];
        m.position.set(x, gy + 0.02, z); m.scale.set(size, 1, size);
        m.material.opacity = 0.55 * (1 - Math.max(0, y - gy) / 5); m.visible = true;
      };
      for (const m of mobs) if (!m.dead && m.model.group.visible && Math.abs(m.pos.x - pp.x) < 24 && Math.abs(m.pos.z - pp.z) < 24) put(m.pos.x, m.pos.y, m.pos.z, Math.max(m.w * 1.5, 0.7));
      for (const e of items) if (Math.abs(e.pos.x - pp.x) < 10 && Math.abs(e.pos.z - pp.z) < 10) put(e.pos.x, e.pos.y, e.pos.z, 0.45);
    }
    for (let i = n; i < this.used; i++) this.pool[i].visible = false;
    this.used = n;
  }
};
