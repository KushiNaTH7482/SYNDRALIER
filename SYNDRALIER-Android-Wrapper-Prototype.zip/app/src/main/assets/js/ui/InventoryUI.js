// InventoryUI : Hotbar (HUD) + หน้าจอ Inventory แบบ Grid
// รองรับ drag & drop, คลิกหยิบ/วาง, split stack (คลิกขวา หรือปุ่ม "แบ่งครึ่ง" บนมือถือ), ทิ้งไอเทมนอกกรอบ
VX.InventoryUI = class {
  constructor(inv, input, hooks) {
    this.inv = inv; this.input = input; this.hooks = hooks;
    this.other = null;
    this.isOpen = false; this.split = false; this.drag = null; this.ver = -1;
    this.hud = document.getElementById('hotbar');
    this.screen = document.getElementById('inv-screen');
    this.cur = document.getElementById('cursor-item');
    this.hudEls = []; this.invEls = [];

    const mk = (i) => {
      const d = document.createElement('div');
      d.className = 'slot'; d.dataset.i = i;
      d.innerHTML = '<img draggable="false" alt=""><span class="cnt"></span><div class="dur"><div></div></div>';
      return d;
    };
    for (let i = 0; i < 9; i++) { const el = mk(i); this.hud.appendChild(el); this.hudEls.push(el); }

    this.screen.innerHTML =
      '<div id="inv-panel"><div id="inv-head"><b>กระเป๋า</b><span><button id="inv-save">บันทึก</button> <button id="inv-time">เวลา: เช้า</button> <button id="inv-split">แบ่งครึ่ง: ปิด</button> ' +
      '<button id="inv-close">ปิด</button></span></div><div id="inv-main" class="grid"></div><div id="inv-hot" class="grid"></div></div>';
    const main = document.getElementById('inv-main'), hot = document.getElementById('inv-hot');
    for (let i = 9; i < 36; i++) { const el = mk(i); main.appendChild(el); this.invEls[i] = el; }
    for (let i = 0; i < 9; i++) { const el = mk(i); hot.appendChild(el); this.invEls[i] = el; }

    // Hotbar : แตะเพื่อเลือกช่อง
    this.hud.addEventListener('pointerdown', (e) => {
      const el = e.target.closest('.slot');
      if (el) { inv.select(+el.dataset.i); e.preventDefault(); e.stopPropagation(); }
    });

    this.screen.addEventListener('contextmenu', (e) => e.preventDefault());
    this.screen.addEventListener('pointerdown', (e) => {
      e.preventDefault();
      const right = e.button === 2 || this.split;
      if (e.target.id === 'inv-close') { this.close(); return; }
      if (e.target.id === 'inv-save') { if (hooks.onSave) hooks.onSave(); return; }
      if (e.target.id === 'inv-time') { if (hooks.onTime) e.target.textContent = 'เวลา: ' + hooks.onTime(); return; }
      if (e.target.id === 'inv-split') {
        this.split = !this.split;
        e.target.textContent = 'แบ่งครึ่ง: ' + (this.split ? 'เปิด' : 'ปิด');
        return;
      }
      const el = e.target.closest('.slot');
      if (el) {
        const i = +el.dataset.i;
        if (right) inv.rightClick(i); else inv.click(i);
        this.drag = { x: e.clientX, y: e.clientY, moved: false };
      } else if (e.target === this.screen && inv.cursor) {          // คลิกนอกกรอบ = ทิ้งลงโลก
        const c = inv.cursor;
        let out;
        if (right) { out = { id: c.id, count: 1, dur: c.dur }; c.count--; if (c.count <= 0) inv.cursor = null; }
        else { out = c; inv.cursor = null; }
        inv.touch();
        hooks.onDrop(out);
      }
      this.moveCursor(e.clientX, e.clientY);
      this.render();
    });
    document.addEventListener('pointermove', (e) => {
      if (!this.isOpen) return;
      this.moveCursor(e.clientX, e.clientY);
      if (this.drag && Math.hypot(e.clientX - this.drag.x, e.clientY - this.drag.y) > 10) this.drag.moved = true;
    });
    document.addEventListener('pointerup', (e) => {
      if (!this.isOpen || !this.drag) return;
      if (this.drag.moved && inv.cursor) {                          // ปล่อยหลังลาก = วางลงช่องที่อยู่ใต้นิ้ว
        const el = document.elementFromPoint(e.clientX, e.clientY);
        const s = el && el.closest && el.closest('#inv-screen .slot');
        if (s) inv.click(+s.dataset.i);
      }
      this.drag = null;
      this.render();
    });
    window.addEventListener('keydown', (e) => { if (e.code === 'Escape' && this.isOpen) this.close(); });     // ปุ่มเปิด/ปิดกระเป๋า (ตั้งค่าได้) จัดการโดย Input
    input.onInventory = () => { if (this.isOpen || hooks.canToggle()) this.toggle(); };
    this.render();
  }

  toggle() { if (this.isOpen) this.close(); else this.open(); }

  open() {
    if (this.other && this.other.isOpen) this.other.close(true);
    this.isOpen = true;
    this.screen.style.display = 'flex';
    const i = this.input;
    i.stick.x = i.stick.y = 0; i.touchBreak = false; i.mouseBreak = false; i.touchJump = false; i.placeQueued = false;
    if (i.releaseAll) i.releaseAll();
    if (document.pointerLockElement && document.exitPointerLock) document.exitPointerLock();
    this.render();
  }

  close(skipLock) {
    const inv = this.inv;
    if (inv.cursor) {                                               // คืนของที่ถืออยู่เข้ากระเป๋า ที่เก็บไม่ลงให้ตกลงพื้น
      const c = inv.cursor; inv.cursor = null;
      const left = inv.add(c.id, c.count, c.dur);
      if (left > 0) this.hooks.onDrop({ id: c.id, count: left, dur: c.dur });
    }
    this.isOpen = false; this.drag = null;
    this.screen.style.display = 'none';
    this.cur.style.display = 'none';
    if (!skipLock && (!this.input.isTouch || this.input.mode === 'mouse') && !this.input.freeLook) {
      const canvas = this.hooks.canvas;
      canvas.requestPointerLock();
      setTimeout(() => { if (!this.isOpen && document.pointerLockElement !== canvas) this.hooks.onLockFailed(); }, 400);
    }
    this.render();
  }

  moveCursor(x, y) { this.cur.style.transform = 'translate(' + (x - 16) + 'px,' + (y - 16) + 'px)'; }

  update() { if (this.ver !== this.inv.version) { this.ver = this.inv.version; this.render(); } }

  paint(el, s) {
    const img = el.children[0], cnt = el.children[1], dur = el.children[2];
    if (!s) { img.style.visibility = 'hidden'; el._k = 0; cnt.textContent = ''; dur.style.display = 'none'; return; }
    if (el._k !== s.id) { img.src = VX.Icons.url(s.id); img.style.visibility = 'visible'; el._k = s.id; }
    cnt.textContent = s.count > 1 ? s.count : '';
    const it = VX.Items.get(s.id);
    if (it.durability && s.dur < it.durability) {
      dur.style.display = 'block'; dur.firstChild.style.width = (100 * s.dur / it.durability) + '%';
    } else dur.style.display = 'none';
  }

  render() {
    const inv = this.inv;
    for (let i = 0; i < 9; i++) {
      this.paint(this.hudEls[i], inv.slots[i]);
      this.hudEls[i].classList.toggle('sel', i === inv.selected);
    }
    if (this.isOpen) for (let i = 0; i < 36; i++) {
      this.paint(this.invEls[i], inv.slots[i]);
      this.invEls[i].classList.toggle('sel', i === inv.selected);
    }
    const c = inv.cursor;
    if (c && this.isOpen) {
      this.cur.style.display = 'block';
      const img = this.cur.children[0];
      if (this.cur._k !== c.id) { img.src = VX.Icons.url(c.id); this.cur._k = c.id; }
      this.cur.children[1].textContent = c.count > 1 ? c.count : '';
    } else this.cur.style.display = 'none';
  }
};
