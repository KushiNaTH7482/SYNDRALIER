// SettingsUI : สร้างหน้าตั้งค่าอัตโนมัติจากตาราง VX.Settings.schema (เพิ่มตัวเลือกใหม่ไม่ต้องแก้ไฟล์นี้)
VX.SettingsUI = class {
  constructor(container) {
    this.c = container; this.ctrl = {};
    for (const d of VX.Settings.schema) {
      const row = document.createElement('div'); row.className = 'srow';
      const label = document.createElement('label'); label.textContent = d.label;
      let el, val = null;
      if (d.type === 'select') {
        el = document.createElement('select');
        el.innerHTML = d.options.map((o) => '<option value="' + o[0] + '">' + o[1] + '</option>').join('');
        el.addEventListener('change', () => VX.Settings.set(d.key, d.options.find((o) => String(o[0]) === el.value)[0]));
      } else if (d.type === 'range') {
        el = document.createElement('input'); el.type = 'range'; el.min = d.min; el.max = d.max; el.step = d.step;
        val = document.createElement('span'); val.className = 'sval';
        el.addEventListener('input', () => { val.textContent = d.fmt(+el.value); });
        el.addEventListener('change', () => VX.Settings.set(d.key, +el.value));
      } else if (d.type === 'button') {
        el = document.createElement('button'); el.className = 'sbtn'; el.textContent = 'ตั้งค่า';
        el.addEventListener('click', () => { if (VX.Settings.actions[d.action]) VX.Settings.actions[d.action](); });
      } else {
        el = document.createElement('input'); el.type = 'checkbox';
        el.addEventListener('change', () => VX.Settings.set(d.key, el.checked));
      }
      row.appendChild(label); row.appendChild(el); if (val) row.appendChild(val);
      this.c.appendChild(row);
      this.ctrl[d.key] = { el, val, def: d };
    }
    VX.Settings.onChange(() => this.refresh());
    this.refresh();
  }
  refresh() {
    for (const k in this.ctrl) {
      const { el, val, def } = this.ctrl[k], v = VX.Settings.get(k);
      if (def.type === 'button') continue;
      if (def.type === 'toggle') el.checked = !!v; else el.value = String(v);
      if (val) val.textContent = def.fmt(v);
    }
  }
};
