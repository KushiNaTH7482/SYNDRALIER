// HealthHUD : หัวใจ (20 HP = 10 ดวง), แสงแดงเมื่อโดนตี, หน้าจอตาย
VX.HealthHUD = class {
  constructor() {
    this.el = document.getElementById('health');
    this.hurt = document.getElementById('hurt');
    this.death = document.getElementById('death');
    this.hel = document.getElementById('hunger');
    this.last = -1; this.lastH = -1; this.flash = 0;
  }
  onHurt() { this.flash = 0.35; }
  update(player, dt) {
    if (player.health !== this.last) {
      this.last = player.health;
      let h = '';
      for (let i = 0; i < player.maxHealth / 2; i++) {
        const v = player.health - i * 2;
        h += '<i class="' + (v >= 2 ? 'f' : v >= 1 ? 'h' : 'e') + '">♥</i>';
      }
      this.el.innerHTML = h;
    }
    if (player.hunger !== this.lastH) {
      this.lastH = player.hunger;
      let h = '';
      for (let i = 0; i < player.maxHunger / 2; i++) {
        const v = player.hunger - i * 2;
        h += '<i class="' + (v >= 2 ? 'f' : v >= 1 ? 'h' : 'e') + '">●</i>';
      }
      this.hel.innerHTML = h;
    }
    this.flash = Math.max(0, this.flash - dt);
    this.hurt.style.opacity = player.dead ? 0.6 : this.flash / 0.35 * 0.5;
    this.death.style.display = player.dead ? 'flex' : 'none';
  }
};
