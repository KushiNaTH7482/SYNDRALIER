// MobileControls : จอยสติ๊กลอย (ซ้าย), ลากหมุนกล้อง (ขวา), ปุ่ม Jump / Sprint / Crouch
VX.MobileControls = class {
  constructor(input) {
    const $ = (id) => document.getElementById(id);
    const R = 56;
    const zone = $('stick-zone'), base = $('stick-base'), knob = $('stick-knob'), look = $('look-zone');

    // จอยสติ๊ก
    let sid = null, ox = 0, oy = 0;
    zone.addEventListener('pointerdown', (e) => {
      if (e.pointerType === 'mouse' || sid !== null) return;      // เมาส์จริงไม่ใช้จอยสติ๊กบนจอ
      sid = e.pointerId; zone.setPointerCapture(sid);
      ox = e.clientX; oy = e.clientY;
      base.style.left = ox + 'px'; base.style.top = oy + 'px'; base.style.display = 'block';
      knob.style.transform = 'translate(-50%,-50%)';
      e.preventDefault();
    });
    zone.addEventListener('pointermove', (e) => {
      if (e.pointerId !== sid) return;
      let dx = e.clientX - ox, dy = e.clientY - oy;
      const d = Math.hypot(dx, dy);
      if (d > R) { dx *= R / d; dy *= R / d; }
      knob.style.transform = 'translate(calc(-50% + ' + dx + 'px), calc(-50% + ' + dy + 'px))';
      input.stick.x = dx / R; input.stick.y = -dy / R;
    });
    const endStick = (e) => {
      if (e.pointerId !== sid) return;
      sid = null; base.style.display = 'none'; input.stick.x = input.stick.y = 0;
    };
    zone.addEventListener('pointerup', endStick);
    zone.addEventListener('pointercancel', endStick);

    // หมุนกล้อง
    let lid = null, lx = 0, ly = 0;
    look.addEventListener('pointerdown', (e) => {
      if (e.pointerType === 'mouse' || lid !== null) return;
      lid = e.pointerId; look.setPointerCapture(lid); lx = e.clientX; ly = e.clientY; e.preventDefault();
    });
    look.addEventListener('pointermove', (e) => {
      if (e.pointerId !== lid) return;
      input.addLook((e.clientX - lx) * VX.Config.LOOK_SENS_TOUCH, (e.clientY - ly) * VX.Config.LOOK_SENS_TOUCH);
      lx = e.clientX; ly = e.clientY;
    });
    const endLook = (e) => { if (e.pointerId === lid) lid = null; };
    look.addEventListener('pointerup', endLook);
    look.addEventListener('pointercancel', endLook);

    // ปุ่ม
    const jump = $('btn-jump'), sprint = $('btn-sprint'), crouch = $('btn-crouch');
    const jumpOff = () => { input.touchJump = false; jump.classList.remove('on'); };
    jump.addEventListener('pointerdown', (e) => { input.touchJump = true; jump.classList.add('on'); e.preventDefault(); });
    jump.addEventListener('pointerup', jumpOff);
    jump.addEventListener('pointercancel', jumpOff);
    jump.addEventListener('pointerleave', jumpOff);

    const brk = $('btn-break'), place = $('btn-place');
    const brkOff = () => { input.touchBreak = false; brk.classList.remove('on'); };
    brk.addEventListener('pointerdown', (e) => { input.touchBreak = true; brk.classList.add('on'); e.preventDefault(); });
    brk.addEventListener('pointerup', brkOff);
    brk.addEventListener('pointercancel', brkOff);
    brk.addEventListener('pointerleave', brkOff);
    place.addEventListener('pointerdown', (e) => { input.placeQueued = true; e.preventDefault(); });

    const tap = (id, fn) => $(id).addEventListener('pointerdown', (e) => { fn(); e.preventDefault(); e.stopPropagation(); });
    tap('btn-inv', () => input.onInventory && input.onInventory());
    tap('btn-pause', () => input.onPause && input.onPause());
    tap('btn-craft', () => input.onCraft && input.onCraft());
    tap('btn-drop', () => input.onDrop && input.onDrop());

    sprint.addEventListener('pointerdown', (e) => {
      input.sprintToggle = !input.sprintToggle;
      sprint.classList.toggle('on', input.sprintToggle); e.preventDefault();
    });
    input.onSprintChange = (v) => sprint.classList.toggle('on', v);

    crouch.addEventListener('pointerdown', (e) => {
      input.touchCrouch = !input.touchCrouch;
      crouch.classList.toggle('on', input.touchCrouch); e.preventDefault();
    });
  }
};
