// Overlay : เมนูหลัก (เล่น / สร้างโลกใหม่ / ตั้งค่า / ออก), หน้าพักเกม, toast, debug HUD
VX.Overlay = class {
  constructor(input, canvas) {
    this.input = input; this.canvas = canvas;
    this.running = false; this.started = false; this.ui = null;
    this.save = null; this.list = [];
    this.onLaunch = null; this.onPause = null; this.onSave = null;
    const $ = (id) => document.getElementById(id);
    this.el = $('overlay'); this.dbg = $('debug');
    this.saves = $('saves'); this.note = $('storage-note'); this.toastEl = $('toast');
    this.screens = ['screen-main', 'screen-play', 'screen-create', 'screen-settings', 'screen-controls', 'screen-log', 'pausebox'].map((id) => $(id));
    this.settingsFrom = 'screen-main';
    this.fps = 0; this._f = 0; this._t = 0;

    $('help').textContent = input.isTouch
      ? 'ซ้าย: จอยสติ๊ก  |  ขวา: ลากหมุนกล้อง  |  ขุด/ตี (กดค้าง) / วาง-กิน / ทิ้ง  |  ปุ่มมุมขวาบน: กระเป๋า / คราฟต์  |  ⏸ พัก/ตั้งค่า'
      : 'WASD เดิน  |  Space กระโดด/ว่ายขึ้น  |  Ctrl วิ่ง  |  Shift ย่อ  |  คลิกซ้ายค้าง ขุด/โจมตี  |  คลิกขวา วาง/กิน  |  1-9 / ล้อเมาส์ เลือกช่อง  |  E กระเป๋า  |  C คราฟต์  |  Q ทิ้งไอเทม  |  Esc พัก/ตั้งค่า';

    $('btn-play').addEventListener('click', async () => { this.show('screen-play'); await this.refresh(); });
    $('btn-new').addEventListener('click', () => this.show('screen-create'));
    $('btn-settings').addEventListener('click', () => this.openSettings('screen-main'));
    $('btn-pause-settings').addEventListener('click', () => this.openSettings('pausebox'));
    $('btn-quit').addEventListener('click', () => {
      window.close();                                                      // ใช้ได้เฉพาะหน้าที่เปิดด้วยสคริปต์/แอป
      setTimeout(() => this.toast('ปิดแท็บหรือแอปนี้ได้เลย'), 250);
    });
    $('settings-back').addEventListener('click', () => this.show(this.settingsFrom));
    for (const b of document.querySelectorAll('.back[data-to]')) b.addEventListener('click', () => this.show(b.dataset.to));
    $('start').addEventListener('click', () => this.resume());
    $('btn-create').addEventListener('click', () => this.createWorld());
    $('btn-save').addEventListener('click', async () => { if (this.onSave) await this.onSave(); });
    $('btn-exit').addEventListener('click', async () => { if (this.onSave) await this.onSave(); window.__vxLeaving = true; location.reload(); });
    this.saves.addEventListener('click', (e) => {
      const card = e.target.closest('.card');
      if (!card) return;
      const meta = this.list.find((m) => m.id === card.dataset.id);
      if (e.target.dataset.act === 'play') this.play(meta);
      else if (e.target.dataset.act === 'del' && confirm('ลบโลก "' + meta.name + '" ถาวร?')) this.remove(meta);
    });
    document.addEventListener('pointerlockchange', () => {
      if (!this.started) return;
      if (document.pointerLockElement === canvas) {                      // ได้ pointer lock : โหมดเมาส์ FPS ปกติ
        input.freeLook = false; this._lockTries = 0; document.body.classList.remove('free-cursor'); this.setRunning(true);
      } else if (input.freeLook || (input.isTouch && input.mode !== 'mouse')) return;     // โหมดเมาส์อิสระ/โหมดสัมผัส ไม่ใช้ lock
      else if (!(this.ui && this.ui.isOpen)) this.setRunning(false);     // Esc ออกจาก lock = พักเกม (เปิดกระเป๋าอยู่ไม่ต้องพัก)
    });
    document.addEventListener('pointerlockerror', () => { input.lockErr = 'pointerlockerror'; if (this.started && !this.running) this.enterFree(); });

    // ปุ่มพิเศษของ Input Layer
    input.onEscape = () => { if (this.running) this.setRunning(false); };                    // โหมดเมาส์อิสระไม่มี lock จึงต้องจับ Esc เอง
    input.onModeChange = (m) => {
      if (!this.started) return;
      if (m === 'mouse' && this.running && document.pointerLockElement !== canvas && !input.freeLook) this.enterFree(true);   // เสียบเมาส์ระหว่างเล่นบนมือถือ
      else if (m === 'touch' && input.freeLook && input.isTouch) { input.freeLook = false; document.body.classList.remove('free-cursor'); }
    };
    input.onMouseDown = (e) => {         // ขอ pointer lock ใหม่เฉพาะ "คลิกซ้าย" ตอนอยู่โหมดเมาส์อิสระ (สูงสุด 5 ครั้ง) — คลิกขวา/กลาง/ปุ่มข้าง ไม่แตะ lock เลย
      if (e && e.button !== 0) return;
      if (this.running && input.freeLook && document.pointerLockElement !== canvas && (this._lockTries || 0) < 5 && canvas.requestPointerLock) {
        this._lockTries = (this._lockTries || 0) + 1;
        try { this.lockRequest(canvas); } catch (e) { /* ใช้โหมดเมาส์อิสระต่อ */ }
      }
    };
    VX.Settings.actions.controls = () => this.show('screen-controls');
    VX.Settings.actions.inlog = () => {
      const pre = document.getElementById('log-body'), prev = VX.InputLog.previous(), cur = VX.InputLog.current();
      pre.textContent = '== ครั้งก่อนที่เปิดเกม ==\n' + (prev.join('\n') || '(ว่าง)') + '\n\n== ครั้งนี้ ==\n' + cur.join('\n');
      this.show('screen-log');
    };
    input.onBackSwallowed = () => { if (this.running && performance.now() - (this._bt === undefined ? -1e9 : this._bt) > 2500) { this._bt = performance.now(); this.toast('ปุ่ม Back ถูกกัน (เกมไม่ออก)'); } };
    this.show('screen-main');
  }

  static parseSeed(s) {
    s = (s || '').trim();
    if (!s) return 1 + Math.floor(Math.random() * 2147483646);
    if (/^-?\d+$/.test(s)) return 1 + (Math.abs(parseInt(s, 10)) % 2147483646);
    let h = 2166136261;
    for (let i = 0; i < s.length; i++) h = Math.imul(h ^ s.charCodeAt(i), 16777619);
    return 1 + ((h >>> 0) % 2147483646);
  }

  show(id) {
    for (const s of this.screens) s.style.display = s.id === id ? (s.dataset.display || 'flex') : 'none';
    this.el.classList.toggle('compact', id === 'screen-settings' || id === 'screen-controls' || id === 'screen-log' || id === 'screen-play' || id === 'screen-create');
    this.cur = id;
  }
  openSettings(from) { this.settingsFrom = from; this.show('screen-settings'); }

  // ---- โลก ----
  async showMenu() {
    const b = this.save.backend;
    this.note.textContent = b.persistent ? 'ที่เก็บเซฟ: ' + b.kind : '⚠ เบราว์เซอร์นี้เก็บเซฟถาวรไม่ได้ ข้อมูลจะหายเมื่อปิดหน้านี้';
  }
  async refresh() {
    this.list = await this.save.list();
    const fmt = (t) => t ? new Date(t).toLocaleString('th-TH', { dateStyle: 'short', timeStyle: 'short' }) : 'ยังไม่เคยบันทึก';
    const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
    this.saves.innerHTML = this.list.length ? this.list.map((m) =>
      '<div class="card" data-id="' + m.id + '"><div class="ci"><b>' + esc(m.name) + '</b><span>seed ' + m.seed + ' · วันที่ ' + (m.day || 1) +
      ' · เล่น ' + Math.floor((m.playTime || 0) / 60) + ' นาที<br>' + fmt(m.savedAt) + '</span></div>' +
      '<button data-act="play">เล่น</button><button data-act="del" class="del">ลบ</button></div>').join('')
      : '<div class="empty">ยังไม่มีโลก — กด "สร้างโลกใหม่" ที่เมนูหลัก</div>';
  }
  async createWorld() {
    const meta = await this.save.create(document.getElementById('wname').value.trim(), VX.Overlay.parseSeed(document.getElementById('seed').value));
    await this.play(meta);
  }
  async remove(meta) { await this.save.remove(meta.id); await this.refresh(); }
  async play(meta) {
    this.saves.innerHTML = '<div class="empty">กำลังโหลดโลก…</div>';
    this.show('screen-play');
    try { await this.onLaunch(meta); }
    catch (e) { console.error(e); this.saves.innerHTML = '<div class="empty err">โหลดไม่สำเร็จ: ' + (e.message || e) + '</div>'; return; }
    this.started = true;
    this.show('pausebox');
    this.resume();
  }

  // ---- เล่น/พัก ----
  resume() {
    if (VX.Audio) VX.Audio.resume();                 // เบราว์เซอร์ต้องการ gesture ก่อนเปิดเสียง
    this.input.armBackGuard();                       // (เฉพาะเมื่อเปิด "กันปุ่ม Back") ใส่ประวัติหลอกไว้ตอนมี gesture
    if (this.input.isTouch && this.input.mode !== 'mouse') {
      this.setRunning(true);
      const de = document.documentElement;
      if (de.requestFullscreen && !document.fullscreenElement) de.requestFullscreen().then(() => {
        if (screen.orientation && screen.orientation.lock) screen.orientation.lock('landscape').catch(() => {});
      }).catch(() => {});
    } else {
      this._lockTries = 0;
      this.lockOrFree();                                         // ขอ lock ก่อน (ต้องใช้ gesture) แล้วค่อยขอเต็มจอ
      const de = document.documentElement;
      if (this.input.isTouch && de.requestFullscreen && !document.fullscreenElement) {      // มือถือ + เมาส์ : เต็มจอช่วยให้ lock/ซ่อนแถบได้ในบางเบราว์เซอร์
        try { const p = de.requestFullscreen(); if (p && p.catch) p.catch(() => {}); } catch (e) { /* ignore */ }
      }
    }
  }
  // ขอ pointer lock แบบธรรมดา (ไม่ส่ง option ใด ๆ เพื่อให้ทำงานได้กับทุกเบราว์เซอร์/WebView)
  lockRequest(c) {
    const p = c.requestPointerLock();
    if (p && p.catch) p.catch((err) => { this.input.lockErr = (err && err.name) || 'error'; });
    return p;
  }
  // ขอ pointer lock ถ้าไม่ได้ (ไม่รองรับ/โดนบล็อก เช่น Chrome บน Android, iframe) -> โหมดเมาส์อิสระ
  lockOrFree() {
    const c = this.canvas;
    clearTimeout(this._lt);
    const fail = () => { if (document.pointerLockElement !== c) this.enterFree(); };
    if (!c.requestPointerLock) { this.enterFree(); return; }
    try { const p = this.lockRequest(c); if (p && p.catch) p.catch(fail); } catch (e) { fail(); return; }
    this._lt = setTimeout(() => { if (!this.running) fail(); }, 700);
  }
  enterFree(quiet) {
    this.input.freeLook = true;
    document.body.classList.add('free-cursor');
    this.setRunning(true);
    if (!quiet && !this._freeToast) {
      this._freeToast = true;
      this.toast(this.canvas.requestPointerLock ? 'เบราว์เซอร์ไม่ยอมให้ล็อกเมาส์ — โหมดเมาส์อิสระ: ถ้าเมาส์ชนขอบจอ ให้ค้าง Z แล้วเลื่อนเมาส์กลับกลางจอ (กล้องไม่หมุน) / คลิกซ้ายเพื่อขอล็อกใหม่ / Esc = พัก' : 'เบราว์เซอร์นี้ไม่มี Pointer Lock — โหมดเมาส์อิสระ: ถ้าเมาส์ชนขอบจอ ให้ค้าง Z แล้วเลื่อนเมาส์กลับกลางจอ (กล้องไม่หมุน) / Esc = พัก');
    }
  }
  setRunning(v) {
    const was = this.running;
    this.running = v;
    this.el.style.display = v ? 'none' : 'flex';
    if (!v && this.started) this.show('pausebox');
    if (!v && was && this.onPause) this.onPause();   // พักเกมเมื่อไหร่ บันทึกอัตโนมัติเมื่อนั้น
  }

  toast(msg) {
    this.toastEl.textContent = msg; this.toastEl.style.opacity = 1;
    clearTimeout(this._tt); this._tt = setTimeout(() => { this.toastEl.style.opacity = 0; }, 1800);
  }

  updateDebug(dt, player, world, dn, mobs, saveInfo, gfx) {
    this._f++; this._t += dt;
    if (this._t >= 0.5) { this.fps = Math.round(this._f / this._t); this._f = 0; this._t = 0; }
    const p = player.pos, info = world.gen.columnInfo(Math.floor(p.x), Math.floor(p.z));
    this.dbg.textContent =
      'FPS ' + this.fps + '   seed ' + world.seed + '\n' +
      'XYZ ' + p.x.toFixed(1) + ' ' + p.y.toFixed(1) + ' ' + p.z.toFixed(1) + '   ' + info.biome + '\n' +
      'ground ' + player.onGround + '  swim ' + player.swimming + '  crouch ' + player.crouching + '  sprint ' + player.sprinting + '\n' +
      'time ' + dn.clock() + '  day ' + dn.day + '  ' + dn.phase + '\n' +
      'mobs ' + mobs.count() + ' (hostile ' + mobs.count('hostile') + ')  hp ' + player.health + '  food ' + player.hunger + '\n' +
      'chunks ' + world.chunks.size + '  queue ' + world.queue.length + (world.worker ? '  worker ' + (world.worker.ok ? 'on' : 'off') : '  main-thread') + '\n' +
      gfx + '\n' + saveInfo;
  }
};
