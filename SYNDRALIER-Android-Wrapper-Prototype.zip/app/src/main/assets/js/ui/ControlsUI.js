// ControlsUI : หน้าตั้งค่าปุ่ม — กดช่อง แล้วกดปุ่มคีย์บอร์ดหรือคลิกเมาส์ปุ่มที่ต้องการ (Esc ยกเลิก, Backspace ล้างช่องสำรอง)
VX.ControlsUI = class {
  constructor(container, toast) {
    this.c = container; this.toast = toast || (() => {}); this.cap = null; this.doneAt = 0;
    this.build();
    container.addEventListener('click', (e) => {
      if (performance.now() - this.doneAt < 300) return;                 // คลิกที่ใช้ผูกปุ่มเมื่อกี้ ไม่นับเป็นการเริ่มใหม่
      const b = e.target.closest('button[data-a]');
      if (b) this.start(b.dataset.a, +b.dataset.s, b);
      else if (e.target.id === 'ctl-reset') { VX.Bindings.reset(); this.refresh(); this.toast('คืนค่าปุ่มเริ่มต้นแล้ว'); }
    });
    window.addEventListener('keydown', (e) => {
      if (!this.cap) return;
      e.preventDefault(); e.stopPropagation();
      const code = VX.Bindings.normalize(e);
      if (code === 'Escape') this.cancel();
      else if (code === 'Backspace' || code === 'Delete') { if (!VX.Bindings.clear(this.cap.a, this.cap.s)) this.toast('ต้องเหลืออย่างน้อย 1 ปุ่ม'); this.finish(); }
      else this.assign(code);
    }, true);
    document.addEventListener('pointerdown', (e) => {
      if (!this.cap || e.pointerType !== 'mouse') return;
      e.preventDefault(); e.stopPropagation();
      this.assign('Mouse' + e.button);
    }, true);
  }
  build() {
    this.c.innerHTML = '';
    for (const a of VX.Bindings.ACTIONS) {
      const row = document.createElement('div'); row.className = 'srow ctl';
      row.innerHTML = '<label>' + a.label + '</label><button data-a="' + a.id + '" data-s="0"></button><button data-a="' + a.id + '" data-s="1"></button>';
      this.c.appendChild(row);
    }
    const foot = document.createElement('div'); foot.className = 'ctl-foot';
    foot.innerHTML = '<small>ช่องที่ 2 เป็นปุ่มสำรอง (Backspace = ล้าง) | Esc และเลข 1-9 (เลือกช่อง Hotbar) แก้ไม่ได้</small><button id="ctl-reset">คืนค่าเริ่มต้น</button>';
    this.c.appendChild(foot);
    this.refresh();
  }
  refresh() {
    for (const b of this.c.querySelectorAll('button[data-a]')) {
      b.textContent = VX.Bindings.label(VX.Bindings.get(b.dataset.a)[+b.dataset.s]);
      b.classList.remove('cap');
    }
  }
  start(a, s, el) {
    this.cancel();
    this.cap = { a, s, el }; VX.Bindings.capturing = true;
    el.textContent = 'กดปุ่ม…'; el.classList.add('cap');
  }
  assign(code) {
    const r = VX.Bindings.bind(this.cap.a, this.cap.s, code);
    if (!r.ok) this.toast('ปุ่มนี้ใช้ไม่ได้ (Esc และเลข 1-9 สงวนไว้)');
    else if (r.moved.length) this.toast('ย้ายปุ่ม ' + VX.Bindings.label(code) + ' มาจากคำสั่งอื่นแล้ว');
    this.finish();
  }
  cancel() { if (this.cap) this.finish(); }
  finish() { this.cap = null; VX.Bindings.capturing = false; this.doneAt = performance.now(); this.refresh(); }
};
