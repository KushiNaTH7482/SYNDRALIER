// main : ประกอบทุกโมดูลเข้าด้วยกัน + game loop
(function () {
  const C = VX.Config;
  const canvas = document.getElementById('game');
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: false, powerPreference: 'high-performance' });
  const basePR = Math.min(window.devicePixelRatio || 1, C.PIXEL_RATIO_MAX);
  renderer.setPixelRatio(basePR);

  const SKY = 0x87ceeb, DEEP = 0x1a4d99;
  const scene = new THREE.Scene();
  scene.background = new THREE.Color(SKY);
  scene.fog = new THREE.Fog(SKY, 40, 90);

  const camera = new THREE.PerspectiveCamera(C.FOV, 1, 0.05, 250);
  function resize() {
    renderer.setSize(window.innerWidth, window.innerHeight);
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
  }
  window.addEventListener('resize', resize);
  resize();

  const input = new VX.Input(canvas);
  if (input.isTouch) { document.body.classList.add('touch'); new VX.MobileControls(input); }

  const UW = new THREE.Color(), DEEP_C = new THREE.Color(DEEP);
  let game = null, fogNear = 40, fogFar = 90, underwater = false;
  VX.Settings.init(input.isTouch);
  const perf = new VX.Perf.Adaptive();
  let lastRender = 0;

  // ระยะมองเปลี่ยน -> อัปเดต chunk ที่โหลด + ระยะหมอก
  function applyView() {
    if (!game) return;
    const w = game.world;
    w.setRenderDistance(VX.Settings.get('renderDistance'));
    const far = w.renderDistance * C.CHUNK_SIZE;
    fogNear = far * 0.55; fogFar = far * 0.95;
    if (!underwater) { scene.fog.near = fogNear; scene.fog.far = fogFar; }
  }
  VX.Settings.bind({ renderer, camera, basePR, resize, getGame: () => game, onView: applyView });

  const save = new VX.SaveSystem();
  let currentMeta = null, autoT = 0;

  // saved/chunks = ข้อมูลจากเซฟ (null = โลกใหม่)
  function createGame(meta, saved, chunks, worker) {
    const world = new VX.World(scene, meta.seed);
    world.renderDistance = VX.Settings.get('renderDistance');
    world.loadExtra = VX.Settings.get('loadExtra');
    const far = world.renderDistance * C.CHUNK_SIZE;
    fogNear = far * 0.55; fogFar = far * 0.95;
    scene.fog.near = fogNear; scene.fog.far = fogFar;
    if (worker) world.attachWorker(worker);              // สร้าง chunk ที่เหลือใน Web Worker
    if (chunks) world.restoreModified(chunks);          // chunk ที่เคยแก้ไข จะถูกใช้แทนการสร้างใหม่

    const dn = new VX.DayNight(scene, camera);
    const sp = world.gen.spawnPoint();
    const S = saved && saved.player;
    const alive = S && S.health > 0;
    const start = alive ? { x: S.x, y: S.y, z: S.z } : (S && S.spawn) || sp;
    world.preload(start.x, start.z, 2);
    const player = new VX.Player(world, camera, input);
    player.spawn(start);
    player.spawnPoint = (S && S.spawn) || sp;           // จุดเกิดใหม่ตอนตาย
    const inventory = new VX.Inventory();
    const items = new VX.ItemManager(scene, world, player);
    items.inventory = inventory;
    const blueprints = new VX.BlueprintSystem(VX.RecipeRegistry);
    const crafting = new VX.CraftingSystem(inventory, VX.RecipeRegistry, blueprints);
    const mobs = new VX.MobManager(scene, world, player, items, dn);
    mobs.baseCap = input.isTouch ? C.MOB_CAP_MOBILE : C.MOB_CAP_DESKTOP;
    const health = new VX.HealthHUD();
    player.onHurt = () => { health.onHurt(); VX.sfx('playerHurt'); };
    player.onDeath = (pos) => {                         // ตาย : ไอเทมทั้งหมดตกที่จุดตาย (อยู่ได้ 15 นาที)
      const drop = (s) => { if (s) items.spawn(s.id, s.count, pos.x, pos.y + 0.6, pos.z, (Math.random() - 0.5) * 3, 3, (Math.random() - 0.5) * 3, 1.5, s.dur, 900); };
      inventory.slots.forEach(drop); drop(inventory.cursor);
      inventory.slots.fill(null); inventory.cursor = null; inventory.touch();
    };
    const particles = new VX.Particles(scene);
    const view = new VX.ViewModel(scene, camera, inventory, items);
    mobs.onDeath = (m) => particles.puff(m.pos.x, m.pos.y + m.h * 0.5, m.pos.z);
    VX.Audio.setListener(() => player.pos);
    const interaction = new VX.Interaction(world, player, camera, input, scene, inventory, items, blueprints, mobs, { particles, view });
    const ui = new VX.InventoryUI(inventory, input, {
      canvas,
      canToggle: () => overlay.running,
      onTime: () => dn.cyclePreset(),
      onSave: () => saveNow(false),
      onDrop: (stack) => interaction.dropStack(stack),
      onLockFailed: () => overlay.enterFree()
    });
    const craftUI = new VX.CraftingUI(crafting, blueprints, VX.RecipeRegistry, input, {
      canvas,
      canToggle: () => overlay.running,
      getBenchTier: () => VX.CraftingSystem.nearbyBenchTier(world, player.pos),
      onLockFailed: () => overlay.enterFree()
    });
    ui.other = craftUI; craftUI.other = ui;
    interaction.onStation = () => craftUI.open();
    input.onCraft = () => { if (craftUI.isOpen || overlay.running) craftUI.toggle(); };
    input.onPause = () => { if (overlay.running) overlay.setRunning(false); };
    input.canPlay = () => overlay.running && !ui.isOpen && !craftUI.isOpen;
    overlay.ui = { get isOpen() { return ui.isOpen || craftUI.isOpen; } };

    game = { world, player, interaction, items, ui, craftUI, crafting, blueprints, dn, mobs, health, particles, view, inventory, shadows: new VX.BlobShadows(scene, world), playTime: meta.playTime || 0 };
    if (saved) save.restore(game, saved);               // คืนค่า inventory / เวลา / หิว / ความคืบหน้า ฯลฯ
    currentMeta = meta;
    autoT = 0;
    perf.reset();
    VX.Settings.applyAll();                             // ใช้ค่าตั้งค่ากับ world/กล้อง/เสียง ที่เพิ่งสร้าง
  }

  async function launch(meta) {
    const { state, chunks } = await save.load(meta.id);
    const worker = await VX.ChunkWorker.create(meta.seed);   // null ถ้าสภาพแวดล้อมไม่รองรับ -> สร้างบนเธรดหลักแทน
    createGame(meta, state.player ? state : null, chunks, worker);
  }

  async function saveNow(quiet) {
    if (!game || !currentMeta || save.saving) return null;
    const r = await save.save(game, currentMeta);
    if (r.ok) { if (!quiet) overlay.toast('บันทึกแล้ว ✓'); }
    else if (r.reason !== 'busy') overlay.toast('บันทึกไม่สำเร็จ: ' + r.reason);
    return r;
  }

  const overlay = new VX.Overlay(input, canvas);
  input.guardActive = () => overlay.started;
  new VX.ControlsUI(document.getElementById('controls-body'), (m) => overlay.toast(m));
  new VX.SettingsUI(document.getElementById('settings-body'));
  overlay.save = save;
  overlay.onLaunch = launch;
  overlay.onPause = () => saveNow(true);
  overlay.onSave = () => saveNow(false);
  save.init().then(() => overlay.showMenu()).catch((e) => { console.error(e); document.getElementById('saves').innerHTML = '<div class="empty err">เปิดระบบบันทึกไม่ได้: ' + e.message + '</div>'; });
  document.addEventListener('visibilitychange', () => { if (document.hidden) saveNow(true); });
  window.addEventListener('pagehide', () => saveNow(true));

  let last = performance.now();
  let lastNativeRunning = null;
  function loop(now) {
    requestAnimationFrame(loop);
    // Keep the native wrapper informed so it can release pointer capture when menus open.
    if (lastNativeRunning !== overlay.running) {
      lastNativeRunning = overlay.running;
      if (window.SyndralierNative) {
        try { window.SyndralierNative.setGameStarted(!!overlay.running); } catch (_) { /* optional wrapper */ }
        if (!overlay.running) {
          try { window.SyndralierNative.releaseCapture(); } catch (_) { /* optional wrapper */ }
        }
      }
    }
    if (!VX.Perf.shouldRender(now, lastRender, VX.Settings.get('fpsLimit'))) return;     // ตัวจำกัด FPS (ประหยัดแบต)
    lastRender = now;
    const dt = Math.min((now - last) / 1000, 0.1);
    last = now;
    if (game) {
      const { world, player, interaction, items, ui, craftUI, crafting, dn, mobs, health, particles, view, shadows } = game;
      dn.update(overlay.running ? dt : 0);
      if (overlay.running) {
        game.playTime += dt;
        autoT += dt;
        if (autoT > 30) { autoT = 0; saveNow(true); }   // บันทึกอัตโนมัติทุก 30 วินาที
        if (!ui.isOpen && !craftUI.isOpen) { player.update(dt); interaction.update(dt); }
        items.update(dt);
        mobs.update(dt);
        particles.update(dt);
        view.update(dt, { moving: Math.hypot(player.vel.x, player.vel.z) > 0.5 && player.onGround, mining: interaction.mining, dead: player.dead });
        health.update(player, dt);
        crafting.sync();
        ui.update();
        craftUI.update(dt);
      }
      world.update(player.pos.x, player.pos.z);
      shadows.update(mobs.mobs, items.items, player.pos, C.SHADOWS);
      if (overlay.running) perf.update(dt, VX.Settings.get('autoQuality'), VX.Settings.get('fpsLimit'), (fps) => {
        const rd = VX.Settings.get('renderDistance'), rs = VX.Settings.get('renderScale');      // FPS ตก : ลดระยะมองก่อน ถ้าถึงขั้นต่ำแล้วลดความละเอียดภาพ
        if (rd > 2) VX.Settings.set('renderDistance', rd - 1);
        else if (rs > 0.6) VX.Settings.set('renderScale', rs > 0.8 ? 0.8 : 0.6);
        else return;
        overlay.toast('FPS ต่ำ (' + Math.round(fps) + ') ลดคุณภาพอัตโนมัติ');
      });

      const uw = VX.Blocks.get(world.getBlock(camera.position.x, camera.position.y, camera.position.z)).liquid;
      if (uw !== underwater) {
        underwater = uw;
        scene.fog.near = uw ? 0.1 : fogNear;
        scene.fog.far = uw ? 18 : fogFar;
      }
      const col = uw ? UW.copy(DEEP_C).multiplyScalar(0.25 + 0.75 * dn.daylight) : dn.sky;   // ท้องฟ้า/หมอก ตามเวลา
      scene.background.copy(col); scene.fog.color.copy(col);
      document.body.classList.toggle('hide-cursor', input.freeLook && input.canPlay() && !input.isDown('clutch'));    // เล่นอยู่ในโหมดเมาส์อิสระ : ซ่อน cursor ทุกจุด (รวมทับ Hotbar) / เปิด UI แล้วโชว์ cursor
      const ri = renderer.info.render;
      overlay.updateDebug(dt, player, world, dn, mobs,
        'save ' + save.backend.kind + (save.lastSaved ? '  saved ' + Math.round((Date.now() - save.lastSaved) / 1000) + 's ago' : '  (ยังไม่บันทึก)') + (save.lastError ? '  ERROR' : ''),
        'draw ' + ri.calls + '  tris ' + ri.triangles + '  res ' + Math.round(VX.Settings.get('renderScale') * 100) + '%' + '\n' + input.debugLine());
    }
    renderer.render(scene, camera);
  }
  requestAnimationFrame(loop);
})();
