package com.syndralier.game.th

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.view.KeyEvent
import android.view.MotionEvent
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.OnBackPressedCallback

class MainActivity : Activity() {
    private lateinit var gameView: MouseWebView
    @Volatile private var gameStarted = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = (
            android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            android.view.View.SYSTEM_UI_FLAG_FULLSCREEN or
            android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        )

        gameView = MouseWebView()
        gameView.isFocusable = true
        gameView.isFocusableInTouchMode = true
        gameView.setBackgroundColor(android.graphics.Color.BLACK)
        gameView.settings.javaScriptEnabled = true
        gameView.settings.domStorageEnabled = true
        gameView.settings.databaseEnabled = true
        gameView.settings.allowFileAccess = true
        gameView.settings.allowContentAccess = true
        gameView.settings.cacheMode = WebSettings.LOAD_DEFAULT
        gameView.settings.mediaPlaybackRequiresUserGesture = true
        gameView.webChromeClient = WebChromeClient()
        gameView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                gameView.evaluateJavascript(
                    "window.__syndralierAndroidWrapper = true; window.dispatchEvent(new Event('syndralier-wrapper-ready'));",
                    null
                )
            }
        }
        gameView.addJavascriptInterface(NativeMouseBridge(), "SyndralierNative")
        setContentView(FrameLayout(this).apply {
            addView(gameView, FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            ))
        })
        gameView.loadUrl("file:///android_asset/index.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                // Do not let Android Back accidentally close the game during a mouse session.
                // Send Escape to the game's input layer; the game decides how to handle it.
                gameView.evaluateJavascript(
                    "window.__syndralierNativeKey && window.__syndralierNativeKey('Escape', true); " +
                    "window.__syndralierNativeKey && window.__syndralierNativeKey('Escape', false);",
                    null
                )
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) gameView.releasePointerCapture()
            }
        })
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            window.decorView.systemUiVisibility = (
                android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                android.view.View.SYSTEM_UI_FLAG_FULLSCREEN or
                android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            )
        } else {
            gameView.releaseAllNativeButtons()
        }
    }

    private inner class NativeMouseBridge {
        @JavascriptInterface
        fun requestCapture() {
            runOnUiThread {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && gameView.isAttachedToWindow) {
                    gameView.requestFocus()
                    gameView.requestPointerCapture()
                }
            }
        }

        @JavascriptInterface
        fun releaseCapture() {
            runOnUiThread {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) gameView.releasePointerCapture()
                gameView.releaseAllNativeButtons()
            }
        }

        @JavascriptInterface
        fun setGameStarted(started: Boolean) {
            gameStarted = started
            if (!started) runOnUiThread {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) gameView.releasePointerCapture()
                gameView.releaseAllNativeButtons()
            }
        }
    }

    private inner class MouseWebView : WebView(this@MainActivity) {
        private val nativeButtons = mutableSetOf<Int>()

        private fun sendJs(script: String) {
            post { evaluateJavascript(script, null) }
        }

        private fun sendMove(dx: Float, dy: Float) {
            if (dx == 0f && dy == 0f) return
            sendJs("window.__syndralierNativeMouseMove && window.__syndralierNativeMouseMove(${dx},${dy});")
        }

        private fun buttonNumber(buttonState: Int): Int = when (buttonState) {
            MotionEvent.BUTTON_PRIMARY -> 0
            MotionEvent.BUTTON_TERTIARY -> 1
            MotionEvent.BUTTON_SECONDARY -> 2
            MotionEvent.BUTTON_BACK -> 3
            MotionEvent.BUTTON_FORWARD -> 4
            else -> -1
        }

        private fun sendButton(button: Int, down: Boolean) {
            if (button !in 0..4) return
            if (down) nativeButtons.add(button) else nativeButtons.remove(button)
            sendJs("window.__syndralierNativeMouseButton && window.__syndralierNativeMouseButton($button,${down});")
        }

        fun releaseAllNativeButtons() {
            val held = nativeButtons.toList()
            nativeButtons.clear()
            held.forEach { b -> sendJs("window.__syndralierNativeMouseButton && window.__syndralierNativeMouseButton($b,false);") }
        }

        override fun onCapturedPointerEvent(event: MotionEvent): Boolean {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return false
            when (event.actionMasked) {
                MotionEvent.ACTION_HOVER_MOVE, MotionEvent.ACTION_MOVE -> {
                    sendMove(event.getAxisValue(MotionEvent.AXIS_RELATIVE_X), event.getAxisValue(MotionEvent.AXIS_RELATIVE_Y))
                    // On some device/Android combinations relative axes can be zero on MOVE.
                    if (event.actionMasked == MotionEvent.ACTION_MOVE && event.historySize > 0) {
                        // The latest relative delta above remains the preferred source.
                    }
                }
                MotionEvent.ACTION_BUTTON_PRESS -> {
                    val button = buttonNumber(event.actionButton)
                    sendButton(button, true)
                }
                MotionEvent.ACTION_BUTTON_RELEASE -> {
                    val button = buttonNumber(event.actionButton)
                    sendButton(button, false)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> releaseAllNativeButtons()
            }
            return true
        }

        override fun dispatchGenericMotionEvent(event: MotionEvent): Boolean {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && hasPointerCapture()) {
                if (event.actionMasked == MotionEvent.ACTION_HOVER_MOVE) {
                    sendMove(event.getAxisValue(MotionEvent.AXIS_RELATIVE_X), event.getAxisValue(MotionEvent.AXIS_RELATIVE_Y))
                    return true
                }
                if (event.actionMasked == MotionEvent.ACTION_BUTTON_PRESS || event.actionMasked == MotionEvent.ACTION_BUTTON_RELEASE) {
                    val button = buttonNumber(event.actionButton)
                    sendButton(button, event.actionMasked == MotionEvent.ACTION_BUTTON_PRESS)
                    return true
                }
            }
            // Suppress Android/WebView's secondary-button context menu/back interpretation while playing.
            if (gameStarted && event.actionMasked == MotionEvent.ACTION_BUTTON_PRESS && event.actionButton == MotionEvent.BUTTON_SECONDARY) {
                sendButton(2, true)
                return true
            }
            if (gameStarted && event.actionMasked == MotionEvent.ACTION_BUTTON_RELEASE && event.actionButton == MotionEvent.BUTTON_SECONDARY) {
                sendButton(2, false)
                return true
            }
            return super.dispatchGenericMotionEvent(event)
        }

        override fun onHoverEvent(event: MotionEvent): Boolean {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && hasPointerCapture()) {
                sendMove(event.getAxisValue(MotionEvent.AXIS_RELATIVE_X), event.getAxisValue(MotionEvent.AXIS_RELATIVE_Y))
                return true
            }
            return super.onHoverEvent(event)
        }

        override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
            val key = when (keyCode) {
                KeyEvent.KEYCODE_ESCAPE -> "Escape"
                KeyEvent.KEYCODE_W -> "KeyW"
                KeyEvent.KEYCODE_A -> "KeyA"
                KeyEvent.KEYCODE_S -> "KeyS"
                KeyEvent.KEYCODE_D -> "KeyD"
                KeyEvent.KEYCODE_SPACE -> "Space"
                KeyEvent.KEYCODE_SHIFT_LEFT, KeyEvent.KEYCODE_SHIFT_RIGHT -> "ShiftLeft"
                KeyEvent.KEYCODE_CTRL_LEFT, KeyEvent.KEYCODE_CTRL_RIGHT -> "ControlLeft"
                KeyEvent.KEYCODE_1 -> "Digit1"
                KeyEvent.KEYCODE_2 -> "Digit2"
                KeyEvent.KEYCODE_3 -> "Digit3"
                KeyEvent.KEYCODE_4 -> "Digit4"
                KeyEvent.KEYCODE_5 -> "Digit5"
                KeyEvent.KEYCODE_6 -> "Digit6"
                KeyEvent.KEYCODE_7 -> "Digit7"
                KeyEvent.KEYCODE_8 -> "Digit8"
                KeyEvent.KEYCODE_9 -> "Digit9"
                else -> null
            }
            if (key != null) {
                sendJs("window.__syndralierNativeKey && window.__syndralierNativeKey('$key',true);")
                return true
            }
            return super.onKeyDown(keyCode, event)
        }

        override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
            val key = when (keyCode) {
                KeyEvent.KEYCODE_ESCAPE -> "Escape"
                KeyEvent.KEYCODE_W -> "KeyW"
                KeyEvent.KEYCODE_A -> "KeyA"
                KeyEvent.KEYCODE_S -> "KeyS"
                KeyEvent.KEYCODE_D -> "KeyD"
                KeyEvent.KEYCODE_SPACE -> "Space"
                KeyEvent.KEYCODE_SHIFT_LEFT, KeyEvent.KEYCODE_SHIFT_RIGHT -> "ShiftLeft"
                KeyEvent.KEYCODE_CTRL_LEFT, KeyEvent.KEYCODE_CTRL_RIGHT -> "ControlLeft"
                KeyEvent.KEYCODE_1 -> "Digit1"
                KeyEvent.KEYCODE_2 -> "Digit2"
                KeyEvent.KEYCODE_3 -> "Digit3"
                KeyEvent.KEYCODE_4 -> "Digit4"
                KeyEvent.KEYCODE_5 -> "Digit5"
                KeyEvent.KEYCODE_6 -> "Digit6"
                KeyEvent.KEYCODE_7 -> "Digit7"
                KeyEvent.KEYCODE_8 -> "Digit8"
                KeyEvent.KEYCODE_9 -> "Digit9"
                else -> null
            }
            if (key != null) {
                sendJs("window.__syndralierNativeKey && window.__syndralierNativeKey('$key',false);")
                return true
            }
            return super.onKeyUp(keyCode, event)
        }
    }
}
